/**
 * ====================================================================================
 * @file     protocol.h
 * @brief    串口通信协议模块 - ASCII助记符指令 + XOR校验
 * ====================================================================================
 *
 * 帧格式:
 *   请求: #01XX<CMD>[DATA]\r<CKSUM>
 *   响应: *01XX<DATA>\r\n<CKSUM>
 *
 *   CKSUM = XOR(帧头..\r前一个字节) , 2 ASCII hex 大写字符, 放在帧尾
 *
 * 指令码:
 *   读指令: 2 ASCII 字符 (ST, VG, P3, T3, H3, F5, SN, FS, BR, PR)
 *   写指令: 3 ASCII 字符 (ACC, ADR, EWO, PPI, PAA, PMB, TPC), ID 为 2 字符
 * ====================================================================================
 */

#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include "gd32f30x.h"

/* ====================================================================================
 * 常量定义
 * ==================================================================================== */
#define PROTO_RX_BUF_SIZE      64       /* 接收缓冲(含帧头+\r+校验和) */
#define PROTO_TX_BUF_SIZE      128      /* 发送缓冲 */
#define PROTO_DEV_ADDR         0x01     /* 本机设备地址 */
#define PROTO_FW_VERSION       "XSTK-GQY03-2026.01"   /* 固件默认版本号 */

/* Flash 版本号存储 (W25Q64 最后一个扇区, 4KB) */
#define FLASH_STORE_SECTOR      2047                    /* 扇区号 2047 → 地址 0x7FF000 */
#define FLASH_STORE_ADDR        (FLASH_STORE_SECTOR * 4096UL)
#define FLASH_STORE_MAGIC       0xA5F3                  /* 魔数, 标识有效配置 */

/* Flash 站号独立存储 (扇区 2045, 独立于运行参数) */
#define FLASH_STATION_SECTOR    2045                    /* 扇区号 2045 → 地址 0x7FD000 */
#define FLASH_STATION_ADDR      (FLASH_STATION_SECTOR * 4096UL)

/* Flash 分辨率独立存储 (扇区 2044, 独立于运行参数) */
#define FLASH_RESOLUTION_SECTOR 2044                    /* 扇区号 2044 → 地址 0x7FC000 */
#define FLASH_RESOLUTION_ADDR   (FLASH_RESOLUTION_SECTOR * 4096UL)
#define FLASH_RESOLUTION_MAGIC  0xA5F3                  /* 魔数, 标识有效记录 */

/* Flash 运行参数存储 (扇区 2046, 独立于版本号) */
#define FLASH_CFG_SECTOR        2046                    /* 扇区号 2046 → 地址 0x7FE000 */
#define FLASH_CFG_ADDR          (FLASH_CFG_SECTOR * 4096UL)
#define FLASH_CFG_MAGIC         0xA5F3                  /* 魔数, 与版本号共用 */

/* 配置区内偏移 */
#define FLASH_CFG_OFF_BAUD      3                       /* 波特率 uint32_t */
#define FLASH_CFG_OFF_STATION   7                       /* 站号 uint8_t   */
#define FLASH_CFG_OFF_PARITY    8                       /* 校验位 uint8_t (0=无 1=奇 2=偶) */
#define FLASH_CFG_OFF_DATA_BITS 9                       /* 数据位 uint8_t (0=8bit 1=9bit) */
#define FLASH_CFG_OFF_STOP_BITS 10                      /* 停止位 uint8_t (0=1bit 1=2bit) */
#define FLASH_CFG_RECORD_SIZE   32                      /* 每条记录 32 字节 */
#define FLASH_CFG_MAX_RECORDS   (4096 / FLASH_CFG_RECORD_SIZE)  /* 每扇区 128 条 */

/* 校验位常量 */
#define PROTO_PARITY_NONE       0
#define PROTO_PARITY_ODD        1
#define PROTO_PARITY_EVEN       2

/* 数据位常量 */
#define PROTO_DATA_BITS_8       0
#define PROTO_DATA_BITS_9       1

/* 停止位常量 */
#define PROTO_STOP_BITS_1       0
#define PROTO_STOP_BITS_2       1

/* ====================================================================================
 * 指令类型枚举
 * ==================================================================================== */
typedef enum {
    CMD_TYPE_READ_2  = 0,   /* 2字符读指令 */
    CMD_TYPE_WRITE_2 = 1,   /* 2字符写指令 (仅 ID) */
    CMD_TYPE_WRITE_3 = 2,   /* 3字符写指令 */
} proto_cmd_type_t;

/* ====================================================================================
 * 指令表条目结构
 * ==================================================================================== */
typedef struct {
    const char     *code;           /* 指令字符串 (2或3字符) */
    uint8_t         len;            /* 指令长度: 2 或 3 */
    proto_cmd_type_t type;          /* 读/写类型 */
    void          (*handler)(uint8_t station, const char *data, uint8_t data_len);
                                    /* 处理函数: 站号 + 数据指针 + 数据长度 */
} proto_cmd_entry_t;

/* ====================================================================================
 * ISR 接口变量 (由 usart.c 中断服务程序操作)
 * ==================================================================================== */
extern volatile uint8_t  g_proto_rx_buf[PROTO_RX_BUF_SIZE];   /* 协议帧接收缓冲 */
extern volatile uint8_t  g_proto_rx_idx;                       /* 缓冲写入索引 */
extern volatile uint8_t  g_proto_rx_mode;                      /* 1=正在接收协议帧 */
extern volatile uint8_t  g_proto_rx_need_cksum;                /* \r后还需收的字节数(0/2) */
extern volatile uint8_t  g_proto_frame_ready;                  /* 1=完整帧就绪 */

/* ====================================================================================
 * 公共函数声明
 * ==================================================================================== */
void protocol_init(void);              /* 模块初始化 */
void protocol_process(void);           /* 主循环调用: 解析帧→执行→发送响应 */

/* ====================================================================================
 * 辅助函数 (供内部使用, 也可外部调用)
 * ==================================================================================== */
uint8_t proto_xor_checksum(const uint8_t *buf, uint8_t len);  /* 计算XOR校验和 */
void    proto_send_response(const char *data);                 /* 发送响应帧 */
void    proto_send_str(const char *str);                       /* 裸发字符串(不带帧包装) */

/* Flash 版本号存储 */
void        flash_store_init(void);          /* 上电初始化: 从Flash读版本, 首次写默认 */
const char* flash_store_version(void);       /* 返回当前版本号 */

/* Flash 运行参数存储 */
void        flash_cfg_init(void);            /* 上电加载配置; 首次写默认; 并切换波特率 */
uint32_t    flash_cfg_get_baud(void);        /* 返回已保存的波特率 */
uint8_t     flash_cfg_get_parity(void);      /* 返回已保存的校验位 */
uint8_t     flash_cfg_get_data_bits(void);   /* 返回已保存的数据位 */
uint8_t     flash_cfg_get_stop_bits(void);   /* 返回已保存的停止位 */

/* Flash 站号独立存储 */
void        flash_station_init(void);         /* 上电加载站号 */
void        flash_station_save(void);         /* 保存站号到独立扇区 */

/* Flash 分辨率独立存储 */
void        flash_resolution_init(void);       /* 上电加载分辨率 → 更新 g_target_ref_count */
void        flash_resolution_save(void);       /* 保存分辨率到独立扇区 */
uint8_t     flash_resolution_get_idx(void);    /* 返回当前分辨率索引 (0~9) */

#endif /* __PROTOCOL_H__ */
