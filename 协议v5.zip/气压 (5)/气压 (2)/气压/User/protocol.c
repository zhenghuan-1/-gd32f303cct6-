/* ====================================================================================
 * 文件: protocol.c
 * 描述: 串口通信协议模块 - ASCII助记符指令解析 + XOR校验 + 响应构建
 * ====================================================================================
 *
 * 帧格式:
 *   请求: #01XX<CMD>[DATA]\r<CKSUM>     (CKSUM=XOR(#..\r前), 2hex)
 *   响应: *01XX<DATA>\r\n<CKSUM>        (CKSUM=XOR(*..\r\n前), 2hex)
 *
 * 指令表: 16 条读指令 + 8 条写指令
 * ==================================================================================== */

#include "protocol.h"
#include "usart.h"
#include "freq_measure.h"
#include "pressure_calc.h"

/* 主循环缓存的频率值 (避免 re-calculate 拿到已清零的数据) */
extern uint32_t g_freq_ch1_x1000;
extern uint32_t g_freq_ch2_x1000;
#include "adc.h"
#include "dac.h"
#include "norflash.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ====================================================================================
 * ISR 接口变量定义
 * ==================================================================================== */
volatile uint8_t  g_proto_rx_buf[PROTO_RX_BUF_SIZE];
volatile uint8_t  g_proto_rx_idx        = 0;
volatile uint8_t  g_proto_rx_mode       = 0;
volatile uint8_t  g_proto_rx_need_cksum = 0;
volatile uint8_t  g_proto_frame_ready   = 0;

/* ====================================================================================
 * 模块内部变量
 * ==================================================================================== */
static uint8_t   s_station      = 0;      /* 当前设备站号 */
static char      s_serial[16]   = "24505322";  /* 序列号 */
static char      s_tx_buf[PROTO_TX_BUF_SIZE];   /* 发送缓冲 */

/* Flash 版本号存储 */
static char      s_fw_version[24] = PROTO_FW_VERSION;  /* 当前版本号 */

/* Flash 运行参数 */
static uint32_t  s_baud_rate    = 9600;   /* 波特率 (默认9600) */
static uint8_t   s_parity       = PROTO_PARITY_NONE; /* 校验位 (默认无) */
static uint8_t   s_data_bits    = PROTO_DATA_BITS_8;  /* 数据位 (默认8) */
static uint8_t   s_stop_bits    = PROTO_STOP_BITS_1;  /* 停止位 (默认1) */

/* 允许的波特率列表 */
static const uint32_t s_baud_table[] = {2400, 4800, 9600, 19200, 38400, 57600, 115200};
#define BAUD_TABLE_SIZE  (sizeof(s_baud_table) / sizeof(s_baud_table[0]))

/* 写指令存储(暂存,后续可存Flash) */
static float     s_calib_adder  = 0.0f;   /* 加法器校准 PAA */
static float     s_calib_mult   = 1.0f;   /* 乘法器校准 PMB */
static float     s_range_low    = 0.0f;   /* 量程下限 */
static float     s_range_high   = 1000.0f;/* 量程上限 */
/* ---- 分辨率查表 (PR/PPI 指令) ---- */
#define RESOLUTION_IDX_DEFAULT   6           /* 默认索引: "1" (100ms) */
#define RESOLUTION_TABLE_SIZE    10

/* 分辨率字符串 (协议展示) */
static const char *s_resolution_names[RESOLUTION_TABLE_SIZE] = {
    "1/100", "1/50", "1/20", "1/10", "1/5", "1/2", "1", "2", "5", "10"
};

/* 对应闸门参考计数值 (倍数 × 12000000 = 100ms基准) */
static const uint32_t s_resolution_ref_counts[RESOLUTION_TABLE_SIZE] = {
       120000UL,    /* 1/100 → 1ms   */
       240000UL,    /* 1/50  → 2ms   */
       600000UL,    /* 1/20  → 5ms   */
      1200000UL,    /* 1/10  → 10ms  */
      2400000UL,    /* 1/5   → 20ms  */
      6000000UL,    /* 1/2   → 50ms  */
     12000000UL,    /* 1     → 100ms */
     24000000UL,    /* 2     → 200ms */
     60000000UL,    /* 5     → 500ms */
    120000000UL,    /* 10    → 1s    */
};

static uint8_t  s_resolution_idx = RESOLUTION_IDX_DEFAULT;  /* 分辨率索引 */
static float     s_accuracy     = 0.1f;   /* 精度 */
static uint8_t   s_eeprom_en    = 0;      /* EEPROM写使能 */

/* ====================================================================================
 * 静态函数声明(前向)
 * ==================================================================================== */
static void handler_st (uint8_t station, const char *data, uint8_t data_len);
static void handler_vg (uint8_t station, const char *data, uint8_t data_len);
static void handler_p3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_h3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_f5 (uint8_t station, const char *data, uint8_t data_len);
static void handler_sn_read (uint8_t station, const char *data, uint8_t data_len);
static void handler_fs (uint8_t station, const char *data, uint8_t data_len);
static void handler_dr (uint8_t station, const char *data, uint8_t data_len);
static void handler_br (uint8_t station, const char *data, uint8_t data_len);
static void handler_pt (uint8_t station, const char *data, uint8_t data_len);
static void handler_bt (uint8_t station, const char *data, uint8_t data_len);
static void handler_sb (uint8_t station, const char *data, uint8_t data_len);
static void handler_p1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_pr (uint8_t station, const char *data, uint8_t data_len);
static void handler_acc (uint8_t station, const char *data, uint8_t data_len);
static void handler_adr (uint8_t station, const char *data, uint8_t data_len);
static void handler_ewo (uint8_t station, const char *data, uint8_t data_len);
static void handler_ppi (uint8_t station, const char *data, uint8_t data_len);
static void handler_paa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pmb (uint8_t station, const char *data, uint8_t data_len);
static void handler_tpc (uint8_t station, const char *data, uint8_t data_len);
static void handler_wvr (uint8_t station, const char *data, uint8_t data_len);
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len);

/* ====================================================================================
 * 指令表 (按长度降序排列: 3字符在前, 2字符在后)
 * ==================================================================================== */
static const proto_cmd_entry_t s_cmd_table[] = {
    /* ---- 3字符写指令 ---- */
    { "ACC", 3, CMD_TYPE_WRITE_3, handler_acc },
    { "ADR", 3, CMD_TYPE_WRITE_3, handler_adr },
    { "EWO", 3, CMD_TYPE_WRITE_3, handler_ewo },
    { "PPI", 3, CMD_TYPE_WRITE_3, handler_ppi },
    { "PAA", 3, CMD_TYPE_WRITE_3, handler_paa },
    { "PMB", 3, CMD_TYPE_WRITE_3, handler_pmb },
    { "TPC", 3, CMD_TYPE_WRITE_3, handler_tpc },
    { "WVR", 3, CMD_TYPE_WRITE_3, handler_wvr },

    /* ---- 2字符读指令 ---- */
    { "ST", 2, CMD_TYPE_READ_2,  handler_st },
    { "VG", 2, CMD_TYPE_READ_2,  handler_vg },
    { "P3", 2, CMD_TYPE_READ_2,  handler_p3 },
    { "T3", 2, CMD_TYPE_READ_2,  handler_t3 },
    { "H3", 2, CMD_TYPE_READ_2,  handler_h3 },
    { "F5", 2, CMD_TYPE_READ_2,  handler_f5 },
    { "SN", 2, CMD_TYPE_READ_2,  handler_sn_read },
    { "FS", 2, CMD_TYPE_READ_2,  handler_fs },
    { "BR", 2, CMD_TYPE_READ_2,  handler_br },
    { "DR", 2, CMD_TYPE_READ_2,  handler_dr },
    { "PT", 2, CMD_TYPE_READ_2,  handler_pt },
    { "BT", 2, CMD_TYPE_READ_2,  handler_bt },
    { "SB", 2, CMD_TYPE_READ_2,  handler_sb },
    { "P1", 2, CMD_TYPE_READ_2,  handler_p1 },
    { "T1", 2, CMD_TYPE_READ_2,  handler_t1 },
    { "PR", 2, CMD_TYPE_READ_2,  handler_pr },

    /* ---- 2字符写指令 (仅 ID) ---- */
    { "ID", 2, CMD_TYPE_WRITE_2, handler_id_write },
};

#define CMD_TABLE_SIZE  (sizeof(s_cmd_table) / sizeof(s_cmd_table[0]))

/* ====================================================================================
 * 公共函数: 模块初始化
 * ==================================================================================== */
void protocol_init(void)
{
    uint8_t i;

    flash_station_init();     /* 独立加载站号 (扇区 2045) */
    flash_resolution_init(); /* 独立加载分辨率 (扇区 2044), 同步 g_target_ref_count */

    for (i = 0; i < PROTO_RX_BUF_SIZE; i++)
        g_proto_rx_buf[i] = 0;
    g_proto_rx_idx        = 0;
    g_proto_rx_mode       = 0;
    g_proto_rx_need_cksum = 0;
    g_proto_frame_ready   = 0;
    /* s_station 由 flash_station_init 加载, 不清零 */
}

/* ====================================================================================
 * Flash 版本号存储
 *
 * 存储格式 (地址 0x7FF000, W25Q64 最后一个扇区):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 版本字符串长度
 *   偏移3~: 版本字符串 (ASCII, 以\0结尾)
 * ==================================================================================== */
void flash_store_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    NORFLASH_Read(buf, FLASH_STORE_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_STORE_MAGIC)
    {
        /* Flash 中有有效版本号, 加载 */
        len = buf[2];
        if (len > 23) len = 23;
        for (i = 0; i < len && i < 23; i++)
            s_fw_version[i] = (char)buf[3 + i];
        s_fw_version[len] = '\0';
    }
    else
    {
        /* 首次上电或Flash为空, 写入默认版本号 */
        len = 0;
        while (PROTO_FW_VERSION[len] && len < 23) len++;

        /* 擦除扇区后写入 */
        NORFLASH_Erase_Sector(FLASH_STORE_SECTOR);

        buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);   /* 魔数高位 */
        buf[1] = (uint8_t)(FLASH_STORE_MAGIC);         /* 魔数低位 */
        buf[2] = len;                                   /* 版本长度 */
        for (i = 0; i < len; i++)
            buf[3 + i] = (uint8_t)PROTO_FW_VERSION[i];
        for (; i < 29; i++)
            buf[3 + i] = 0xFF;                          /* 剩余填 0xFF */

        NORFLASH_Write(buf, FLASH_STORE_ADDR, 32);
    }
}

const char* flash_store_version(void)
{
    return s_fw_version;
}

/* ====================================================================================
 * Flash 配置区存储 (扇区 2046, 独立于版本号)
 *
 * 写入策略: 扇区内顺序追加 (磨损均衡)
 *   扇区 4KB ÷ 每条32B = 128条记录
 *   改配置时追加写入, 不擦除; 扇区满才擦一次
 *   寿命: 100,000 × 128 = 1,280万次
 *
 * 存储格式 (每条记录 32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 波特率 uint32_t (little-endian)
 *   偏移  7: 保留 (站号已迁至扇区 2045)
 *   偏移  8: 校验位 uint8_t
 *   偏移  9: 数据位 uint8_t
 *   偏移 10: 停止位 uint8_t
 *   偏移11~31: 填充 0xFF (预留)
 * ==================================================================================== */

/* 前向声明 (usart.c) */
extern void usart_baud_set(uint32_t baud);

static void flash_cfg_save(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];
    uint8_t  i;
    int16_t  last_slot = -1;      /* 最后一条有效记录的槽号 */
    int16_t  next_slot;
    uint16_t magic;
    uint32_t addr;

    /* ---- 打包数据 ---- */
    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);
    buf[2] = 0x01;

    buf[3] = (uint8_t)(s_baud_rate);
    buf[4] = (uint8_t)(s_baud_rate >> 8);
    buf[5] = (uint8_t)(s_baud_rate >> 16);
    buf[6] = (uint8_t)(s_baud_rate >> 24);

    buf[7] = 0xFF;        /* 站号已迁至独立扇区 2045 */
    buf[8] = s_parity;
    buf[9] = s_data_bits;
    buf[10] = s_stop_bits;

    for (i = 11; i < FLASH_CFG_RECORD_SIZE; i++)
        buf[i] = 0xFF;

    /* ---- 找最后一条有效记录的位置 ---- */
    {
        uint8_t magic_buf[2];
        for (i = 0; i < FLASH_CFG_MAX_RECORDS; i++)
        {
            addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
            NORFLASH_Read(magic_buf, addr, 2);  /* 独立 buffer, 不破坏打包数据 */
            magic = ((uint16_t)magic_buf[0] << 8) | magic_buf[1];
            if (magic == FLASH_CFG_MAGIC)
                last_slot = (int16_t)i;
        }
    }

    next_slot = last_slot + 1;

    /* ---- 扇区满了 → 擦除, 从槽0重新开始 ---- */
    if (next_slot >= (int16_t)FLASH_CFG_MAX_RECORDS)
    {
        NORFLASH_Erase_Sector(FLASH_CFG_SECTOR);
        next_slot = 0;
    }

    /* ---- 追加写入 (不擦除, NOR Write 要求目标为 0xFF) ---- */
    addr = FLASH_CFG_ADDR + (uint32_t)next_slot * FLASH_CFG_RECORD_SIZE;
    NORFLASH_Write(buf, addr, FLASH_CFG_RECORD_SIZE);
}

void flash_cfg_init(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];
    uint16_t magic;
    uint8_t  need_save = 0;
    int16_t  i;

    /* ---- 从后往前扫, 找最新一条有效记录 ---- */
    for (i = (int16_t)(FLASH_CFG_MAX_RECORDS - 1); i >= 0; i--)
    {
        uint32_t addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
        NORFLASH_Read(buf, addr, FLASH_CFG_RECORD_SIZE);
        magic = ((uint16_t)buf[0] << 8) | buf[1];

        if (magic == FLASH_CFG_MAGIC)
        {
            /* 找到! 加载配置 */
            s_baud_rate = (uint32_t)buf[3]
                        | ((uint32_t)buf[4] << 8)
                        | ((uint32_t)buf[5] << 16)
                        | ((uint32_t)buf[6] << 24);

            /* 合法性检查: 必须在允许列表中 */
            {
                uint8_t j, valid = 0;
                for (j = 0; j < BAUD_TABLE_SIZE; j++)
                {
                    if (s_baud_rate == s_baud_table[j]) { valid = 1; break; }
                }
                if (!valid)
                {
                    s_baud_rate = 9600;
                    need_save = 1;
                }
            }

            /* 加载校验位 */
            s_parity = buf[8];
            if (s_parity > PROTO_PARITY_EVEN)
            {
                s_parity = PROTO_PARITY_NONE;
                need_save = 1;
            }

            /* 加载数据位 */
            s_data_bits = buf[9];
            if (s_data_bits > PROTO_DATA_BITS_9)
            {
                s_data_bits = PROTO_DATA_BITS_8;
                need_save = 1;
            }

            /* 加载停止位 */
            s_stop_bits = buf[10];
            if (s_stop_bits > PROTO_STOP_BITS_2)
            {
                s_stop_bits = PROTO_STOP_BITS_1;
                need_save = 1;
            }

            /* 站号由 flash_station_init() 独立加载, 不从这里读取 */

            if (need_save)
            {
                flash_cfg_save();
            }
            /* UART 尚未初始化 */
            return;
        }
    }

    /* 扇区全空或全无效 → 首次上电 */
    s_baud_rate = 9600;
    s_parity    = PROTO_PARITY_NONE;
    s_data_bits = PROTO_DATA_BITS_8;
    s_stop_bits = PROTO_STOP_BITS_1;
    /* 站号由 flash_station_init() 独立初始化 */
    flash_cfg_save();
}

uint32_t flash_cfg_get_baud(void)
{
    return s_baud_rate;
}

uint8_t flash_cfg_get_parity(void)
{
    return s_parity;
}

uint8_t flash_cfg_get_data_bits(void)
{
    return s_data_bits;
}

uint8_t flash_cfg_get_stop_bits(void)
{
    return s_stop_bits;
}

/* ====================================================================================
 * Flash 站号独立存储 (扇区 2045)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 站号 uint8_t
 *   偏移4~31: 填充 0xFF
 *
 * 站号极少变更, 不使用追加磨损均衡, 每次擦除后单条写入
 * ==================================================================================== */
void flash_station_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    NORFLASH_Read(buf, FLASH_STATION_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_CFG_MAGIC)
    {
        /* 有效记录 → 加载站号 */
        s_station = buf[3];
    }
    else
    {
        /* 首次上电 → 默认站号 0x01, 写入 Flash */
        s_station = 0x01;
        flash_station_save();
    }
}

void flash_station_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    NORFLASH_Erase_Sector(FLASH_STATION_SECTOR);

    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);
    buf[2] = 0x01;
    buf[3] = s_station;

    for (i = 4; i < 32; i++)
        buf[i] = 0xFF;

    NORFLASH_Write(buf, FLASH_STATION_ADDR, 32);
}

/* ---- Flash 分辨率存储 (扇区 2044) ---- */
void flash_resolution_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    NORFLASH_Read(buf, FLASH_RESOLUTION_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_RESOLUTION_MAGIC && buf[2] < RESOLUTION_TABLE_SIZE)
    {
        /* 有效记录 → 加载分辨率 */
        s_resolution_idx = buf[2];
    }
    else
    {
        /* 首次上电 → 默认分辨率 "1" (100ms), 写入 Flash */
        s_resolution_idx = RESOLUTION_IDX_DEFAULT;
        flash_resolution_save();
    }

    /* 同步到频率测量模块的闸门目标 */
    g_target_ref_count = s_resolution_ref_counts[s_resolution_idx];
    /* 同步信号计数闸门目标: signal = ref × est_freq / 120MHz */
    g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);
    g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);
}

void flash_resolution_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    NORFLASH_Erase_Sector(FLASH_RESOLUTION_SECTOR);

    buf[0] = (uint8_t)(FLASH_RESOLUTION_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_RESOLUTION_MAGIC);
    buf[2] = s_resolution_idx;

    for (i = 3; i < 32; i++)
        buf[i] = 0xFF;

    NORFLASH_Write(buf, FLASH_RESOLUTION_ADDR, 32);
}

uint8_t flash_resolution_get_idx(void)
{
    return s_resolution_idx;
}

/* ====================================================================================
 * 辅助函数: 计算 XOR 校验和
 *   buf: 待校验数据
 *   len: 字节数
 *   返回: XOR 结果 (0x00~0xFF)
 * ==================================================================================== */
uint8_t proto_xor_checksum(const uint8_t *buf, uint8_t len)
{
    uint8_t ck = 0;
    uint8_t i;
    for (i = 0; i < len; i++)
    {
        ck ^= buf[i];
    }
    return ck;
}

/* ====================================================================================
 * 辅助函数: 构建并发送响应帧
 *   自动计算校验和, 组装为 *01XX<data>\r\n<CK>
 *   data: 响应数据字符串 (不含帧头帧尾校验和)
 * ==================================================================================== */
void proto_send_response(const char *data)
{
    uint8_t  frame[PROTO_TX_BUF_SIZE];
    uint8_t  idx = 0;
    uint8_t  i;
    uint8_t  ck;

    /* ---------- 构建帧 ---------- */
    frame[idx++] = '*';                     /* 帧头 */
    frame[idx++] = '0';                     /* 地址高位 */
    frame[idx++] = '0' + PROTO_DEV_ADDR;    /* 地址低位: '1' */
    frame[idx++] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];  /* 站号高位 */
    frame[idx++] = "0123456789ABCDEF"[s_station & 0x0F];         /* 站号低位 */

    /* 数据部分 */
    if (data != NULL)
    {
        while (*data && idx < PROTO_TX_BUF_SIZE - 6)
        {
            frame[idx++] = (uint8_t)(*data++);
        }
    }

    /* 帧尾 \r\n */
    frame[idx++] = 0x0D;
    frame[idx++] = 0x0A;

    /* 校验和 (范围: 帧头 '*' 到 \r\n 前, 即 idx-2 个字节) */
    ck = proto_xor_checksum(frame, idx - 2);
    frame[idx++] = "0123456789ABCDEF"[(ck >> 4) & 0x0F];
    frame[idx++] = "0123456789ABCDEF"[ck & 0x0F];

    /* ---------- DMA 发送 ---------- */
    usart_dma_send(frame, idx);
}

/* ====================================================================================
 * 辅助函数: 发错误响应
 * ==================================================================================== */
static void proto_send_error(const char *err_msg)
{
    proto_send_response(err_msg);
}

/* ====================================================================================
 * 辅助函数: 2位 hex 字符 → uint8
 *   hex: 指向2个ASCII hex字符的指针
 *   返回: 0x00~0xFF
 * ==================================================================================== */
static uint8_t hex2u8(const char *hex)
{
    uint8_t val = 0;
    uint8_t i;
    for (i = 0; i < 2; i++)
    {
        val <<= 4;
        if (hex[i] >= '0' && hex[i] <= '9')
            val |= hex[i] - '0';
        else if (hex[i] >= 'A' && hex[i] <= 'F')
            val |= hex[i] - 'A' + 10;
        else if (hex[i] >= 'a' && hex[i] <= 'f')
            val |= hex[i] - 'a' + 10;
    }
    return val;
}

/* ====================================================================================
 * 核心函数: 协议帧解析与处理 (主循环中调用)
 * ==================================================================================== */
void protocol_process(void)
{
    uint8_t  frame_len;
    uint8_t  data_end;       /* \r 的位置 (数据部分结束) */
    uint8_t  payload_start;  /* 指令码起始位置 = 5 */
    uint8_t  payload_len;    /* 指令码+数据总长度 */
    uint8_t  ck_calc, ck_recv;
    uint8_t  dev_addr;
    uint8_t  station;
    uint8_t  i;

    /* ---------- 第1步: 找 \r, 定位校验和 ---------- */
    frame_len = g_proto_rx_idx;
    if (frame_len < 10)   /* 最短帧: #01XXCC\rCC = 10字节 */
    {
        proto_send_error("ER1");  /* 帧太短 */
        return;
    }

    /* 找 \r 位置 */
    data_end = 0xFF;
    for (i = 0; i < frame_len; i++)
    {
        if (g_proto_rx_buf[i] == 0x0D)
        {
            data_end = i;
            break;
        }
    }
    if (data_end == 0xFF || data_end + 3 > frame_len)
    {
        /* 无 \r 或 校验和不完整 (\r后需要2字节校验和) */
        proto_send_error("ER2");  /* 帧格式错误 */
        return;
    }
    /* 校验和在 data_end+1 和 data_end+2 */

    /* ---------- 第2步: 校验和验证 ---------- */
    ck_recv = hex2u8((const char *)&g_proto_rx_buf[data_end + 1]);
    ck_calc = proto_xor_checksum((const uint8_t *)g_proto_rx_buf, data_end + 1);  /* 范围: '#'..\r 含\r */
    if (ck_recv != ck_calc)
    {
        proto_send_error("ER3");  /* 校验和错误 */
        return;
    }

    /* ---------- 第3步: 校验帧头 ---------- */
    if (g_proto_rx_buf[0] != '#')
    {
        proto_send_error("ER4");  /* 帧头错误 */
        return;
    }

    /* ---------- 第4步: 校验设备地址 ---------- */
    dev_addr = hex2u8((const char *)&g_proto_rx_buf[1]);
    if (dev_addr != PROTO_DEV_ADDR)
    {
        /* 地址不匹配, 不响应 */
        return;
    }

    /* ---------- 第5步: 解析站号并过滤 ---------- */
    station = hex2u8((const char *)&g_proto_rx_buf[3]);

    /* 00 = 广播 (全体响应), 其他 = 仅匹配自身站号, 不匹配则静默丢弃 */
    if (station != 0x00 && station != s_station)
        return;

    /* ---------- 第6步: 提取指令码+数据 ---------- */
    payload_start = 5;                                        /* 跳过 # + 01 + XX */
    payload_len   = data_end - payload_start;                 /* 指令码+数据总长度 */

    if (payload_len < 2)
    {
        proto_send_error("ER5");  /* 无指令码 */
        return;
    }

    /* ---------- 第7步: 查表匹配指令 ---------- */
    for (i = 0; i < CMD_TABLE_SIZE; i++)
    {
        const proto_cmd_entry_t *cmd = &s_cmd_table[i];

        if (payload_len < cmd->len)
            continue;

        /* 比较指令码 (大小写不敏感 — 接收一律转大写对比) */
        {
            uint8_t match = 1;
            uint8_t j;
            for (j = 0; j < cmd->len; j++)
            {
                char c = (char)g_proto_rx_buf[payload_start + j];
                if (c >= 'a' && c <= 'z') c -= 32;  /* 小写转大写 */
                if (c != cmd->code[j]) { match = 0; break; }
            }
            if (!match) continue;
        }

        /* 命中! 提取数据部分 */
        {
            const char *data_ptr = NULL;
            uint8_t     data_len = 0;

            if (payload_len > cmd->len)
            {
                data_ptr = (const char *)&g_proto_rx_buf[payload_start + cmd->len];
                data_len = payload_len - cmd->len;
            }

            /* 执行处理函数 */
            cmd->handler(station, data_ptr, data_len);
        }
        return;   /* 已处理, 退出 */
    }

    /* 未匹配任何指令 */
    proto_send_error("ER6");  /* 未知指令 */
}

/* ====================================================================================
 * 读指令处理函数
 * ==================================================================================== */

/* ---- ST: 通讯查验 ---- */
static void handler_st(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response("OK");
}

/* ---- VG: 读版本 ---- */
static void handler_vg(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(flash_store_version());
}

/* ---- P3: 读气压 ---- */
static void handler_p3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure;
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */

    pressure = pressure_calc_get();
    sprintf(buf, "%.2f", (double)pressure);
    proto_send_response(buf);
}

/* ---- P1: 单次采集 (F1频率 + F2频率 + 气压) ---- */
static void handler_p1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get();
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)pressure);
    proto_send_response(buf);
}

/* ---- T1: 单次采集 (F1频率 + F2频率 + 温度) ---- */
static void handler_t1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    short temp_raw;
    float temp_c;
    (void)data; (void)data_len;
    (void)station;

    temp_raw = Get_Temprate();
    temp_c   = (float)temp_raw / 100.0f;
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)temp_c);
    proto_send_response(buf);
}

/* ---- T3: 读温度 ---- */
static void handler_t3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    short temp_raw;
    float temp_c;
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */

    temp_raw = Get_Temprate();                    /* ×100 如 3524 = 35.24°C */
    temp_c   = (float)temp_raw / 100.0f;
    sprintf(buf, "%.2f", (double)temp_c);
    proto_send_response(buf);
}

/* ---- H3: 读高度 ---- */
static void handler_h3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure, altitude;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get();
    altitude = pressure_to_altitude(pressure);
    sprintf(buf, "%.2f", (double)altitude);
    proto_send_response(buf);
}

/* ---- F5: 读频率组 (5个CH1 + 5个CH2, 窗口原始数据, 最旧→最新) ---- */
static void handler_f5(uint8_t station, const char *data, uint8_t data_len)
{
    char     buf[200];
    uint32_t ch1[PRESSURE_WINDOW_SIZE];
    uint32_t ch2[PRESSURE_WINDOW_SIZE];
    uint8_t  cnt, i, pos = 0;
    (void)data; (void)data_len;
    (void)station;

    cnt = pressure_calc_get_window(ch1, ch2);  /* 时间顺序: [0]=最旧, [cnt-1]=最新 */

    /* F1 标签 */
    pos += sprintf(&buf[pos], "F1:");

    /* 输出5个F1: 取最新5个, 不足则在前面补 0.000 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }

    /* F2 标签 */
    buf[pos++] = ',';
    pos += sprintf(&buf[pos], "F2:");

    /* 输出5个F2: 同上 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    buf[pos] = '\0';
    proto_send_response(buf);
}

/* ---- SN: 读序列号 ---- */
static void handler_sn_read(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(s_serial);
}

/* ---- FS: 读量程 ---- */
static void handler_fs(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    sprintf(buf, "%.0f-%.0f", (double)s_range_low, (double)s_range_high);
    proto_send_response(buf);
}

/* ---- BR: 读波特率 ---- */
/* ---- DR: 读站号 (返回设备自身站号, 不修改) ---- */
static void handler_dr(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[3];
    (void)station; (void)data; (void)data_len;
    buf[0] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];
    buf[1] = "0123456789ABCDEF"[s_station & 0x0F];
    buf[2] = '\0';
    proto_send_response(buf);
}

/* ---- BR: 读/写波特率 ---- */
static void handler_br(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[16];
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data != NULL && data_len > 0)
    {
        /* ---- 写模式: 设置新波特率 ---- */
        uint32_t new_baud = 0;
        uint8_t  i;

        for (i = 0; i < data_len; i++)
        {
            if (data[i] >= '0' && data[i] <= '9')
                new_baud = new_baud * 10 + (uint32_t)(data[i] - '0');
            else
                break;
        }

        /* 校验: 必须在允许列表中 */
        {
            uint8_t j, valid = 0;
            for (j = 0; j < BAUD_TABLE_SIZE; j++)
            {
                if (new_baud == s_baud_table[j]) { valid = 1; break; }
            }
            if (!valid)
            {
                proto_send_response("ER8");  /* 无效波特率 */
                return;
            }
        }

        s_baud_rate = new_baud;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧波特率发完响应, 再切硬件 */
        proto_send_response("OK");

        /* 等待 DMA 发送完成, 然后切换到新波特率 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_baud_set(s_baud_rate);
    }
    else
    {
        /* ---- 读模式: 返回当前波特率 ---- */
        sprintf(buf, "%lu", (unsigned long)s_baud_rate);
        proto_send_response(buf);
    }
}

/* ---- PT: 读/写校验位 ---- */
static void handler_pt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data != NULL && data_len > 0)
    {
        /* ---- 写模式: 设置校验位 ---- */
        uint8_t new_parity;
        char    c = data[0];

        /* 大小写不敏感 */
        if (c >= 'a' && c <= 'z') c -= 32;

        if (c == 'N')
            new_parity = PROTO_PARITY_NONE;
        else if (c == 'O')
            new_parity = PROTO_PARITY_ODD;
        else if (c == 'E')
            new_parity = PROTO_PARITY_EVEN;
        else
        {
            proto_send_response("ER8");  /* 无效校验位 */
            return;
        }

        s_parity = new_parity;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧校验位发完响应, 再切硬件 */
        proto_send_response("OK");

        /* 等待 DMA 发送完成, 然后切换到新校验位 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_parity_set(s_parity);
    }
    else
    {
        /* ---- 读模式: 返回当前校验位 ---- */
        const char *p;
        if (s_parity == PROTO_PARITY_ODD)
            p = "O";
        else if (s_parity == PROTO_PARITY_EVEN)
            p = "E";
        else
            p = "N";
        proto_send_response(p);
    }
}

/* ---- BT: 只读数据位 ---- */
static void handler_bt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;
    (void)data;
    (void)data_len;

    /* 读模式: 返回 "8" 或 "9" */
    if (s_data_bits == PROTO_DATA_BITS_9)
        proto_send_response("9");
    else
        proto_send_response("8");
}

/* ---- SB: 读/写停止位 ---- */
static void handler_sb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    if (data != NULL && data_len > 0)
    {
        /* ---- 写模式: 设置停止位 ---- */
        uint8_t new_stop;
        char    c = data[0];

        if (c == '1')
            new_stop = PROTO_STOP_BITS_1;
        else if (c == '2')
            new_stop = PROTO_STOP_BITS_2;
        else
        {
            proto_send_response("ER8");  /* 无效停止位 */
            return;
        }

        s_stop_bits = new_stop;
        flash_cfg_save();                /* 持久化到 Flash */

        proto_send_response("OK");
        usart_stop_bits_set(s_stop_bits);
    }
    else
    {
        /* ---- 读模式: 返回当前停止位 ---- */
        if (s_stop_bits == PROTO_STOP_BITS_2)
            proto_send_response("2");
        else
            proto_send_response("1");
    }
}

/* ---- PR: 读分辨率 ---- */
static void handler_pr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(s_resolution_names[s_resolution_idx]);
}

/* ====================================================================================
 * 写指令处理函数
 * ==================================================================================== */

/* ---- ACC: 写量程精度 ---- */
static void handler_acc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        s_accuracy = (float)atof(data);
    }
    proto_send_response("OK");
}

/* ---- ADR: 写站号 ---- */
static void handler_adr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len >= 2)
    {
        uint8_t new_station = hex2u8(data);
        s_station = new_station;
        flash_station_save();       /* 持久化到独立扇区 2045 */
    }
    proto_send_response("OK");
}

/* ---- EWO: 写 EEPROM 使能 ---- */
static void handler_ewo(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        s_eeprom_en = (data[0] == '1') ? 1 : 0;
    }
    proto_send_response("OK");
}

/* ---- PPI: 写压力分辨率 ---- */
static void handler_ppi(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");   /* 缺少数据 */
        return;
    }

    /* 遍历查表, 匹配分辨率字符串 */
    for (i = 0; i < RESOLUTION_TABLE_SIZE; i++)
    {
        if (strncmp(data, s_resolution_names[i], data_len) == 0
            && s_resolution_names[i][data_len] == '\0')
        {
            /* 合法值: 更新全局闸门目标 */
            s_resolution_idx = i;
            g_target_ref_count = s_resolution_ref_counts[i];
            /* 同步信号计数闸门目标 */
            g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);
            g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);

            /* 持久化到 Flash */
            flash_resolution_save();

            proto_send_response("OK");
            return;
        }
    }

    /* 未匹配 → 无效参数 */
    proto_send_response("ER8");
}

/* ---- PAA: 写加法器校准 ---- */
static void handler_paa(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        s_calib_adder = (float)atof(data);
    }
    proto_send_response("OK");
}

/* ---- PMB: 写乘法器校准 ---- */
static void handler_pmb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        s_calib_mult = (float)atof(data);
    }
    proto_send_response("OK");
}

/* ---- TPC: 写标定系数 (暂存, 后续可更新多项式矩阵) ---- */
static void handler_tpc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    /* TPC 系数格式较复杂, 暂只返回 OK, 后续实现具体解析 */
    (void)data; (void)data_len;
    proto_send_response("OK");
}

/* ---- WVR: 写版本号 (3字符写指令) ---- */
static void handler_wvr(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t buf[32];
    uint8_t len, i;

    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");  /* 缺少版本号 */
        return;
    }

    /* 限制长度 */
    len = (data_len > 23) ? 23 : data_len;

    /* 更新内存 */
    for (i = 0; i < len; i++)
        s_fw_version[i] = data[i];
    s_fw_version[len] = '\0';

    /* 写入Flash */
    NORFLASH_Erase_Sector(FLASH_STORE_SECTOR);

    buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_STORE_MAGIC);
    buf[2] = len;
    for (i = 0; i < len; i++)
        buf[3 + i] = (uint8_t)s_fw_version[i];
    for (; i < 29; i++)
        buf[3 + i] = 0xFF;

    NORFLASH_Write(buf, FLASH_STORE_ADDR, 32);
    proto_send_response("OK");
}

/* ---- ID: 写序列号 (2字符写指令) ---- */
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        for (i = 0; i < sizeof(s_serial) - 1 && i < data_len; i++)
        {
            s_serial[i] = data[i];
        }
        s_serial[i] = '\0';
        /* 后续可写 Flash */
    }
    proto_send_response("OK");
}
