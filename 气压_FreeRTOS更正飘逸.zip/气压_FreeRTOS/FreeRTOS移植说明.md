# FreeRTOS 移植说明（GD32F303 双路频率计 + 气压）

> 本工程是 `C:\Users\dell\Desktop\气压` 的**完整副本**，原工程一个字节都没动。
> 内核：**FreeRTOS-Kernel V11.3.1**（官方源码，在 `Middlewares/FreeRTOS/`）。

## ✅ 验证状态（全部实测）

| 验证项 | 结果 |
|---|---|
| **Keil uVision 真实构建**（UV4 -b，Arm Compiler 6.21） | **0 Error(s), 5 Warning(s)**（那 5 个警告原工程本来就有），生成 `Output/GD32F303.hex`（159 KB，可直接烧写） |
| 手工 armclang 全量编译 + 链接（48 个文件） | 48/48 通过，无 `Symbol multiply defined` |
| EIDE/AC5 路径关键文件（`RVDS/ARM_CM4F/port.c`、改过的 `usart.c`、`delay.c`） | armcc 编译 rc=0 通过 |

实测资源占用（Keil 链接器输出）：

| | 裸机版 | FreeRTOS 版 | 变化 |
|---|---|---|---|
| Code + RO-data | 46,992 B (45.9 KB) | **56,264 B (54.9 KB)** | +9.0 KB（内核 ~6KB + 新代码） |
| RW + ZI（RAM） | 10,704 B (10.5 KB) | **28,072 B (27.4 KB)** | +16.9 KB（主要是 16KB 的 FreeRTOS 堆，任务栈都在堆里） |
| Flash 余量 | — | 约 201 KB 可用（代码区上限 224KB，配置区从 0x08038000 起） | 充足 |
| RAM 余量 | — | 约 20 KB | 充足 |

---

## 一、和原工程的区别（动了 5 个文件 + 新增 2 个）

| 文件 | 改动 |
|---|---|
| `User/main.c` | 超级循环拆掉，只剩：初始化 → 建任务 → `vTaskStartScheduler()`。**原文件备份为 `User/main_baremetal.c.bak`**（不参与编译） |
| `User/app_tasks.c/.h` | **新增**：三个任务的实现（逻辑从原 main.c 原样搬来） |
| `User/FreeRTOSConfig.h` | **新增**：内核配置（120MHz、1kHz Tick、16KB 堆、栈溢出检查） |
| `User/gd32f30x_it.c` | SVC / PendSV / SysTick 三个空函数被 `#if (SYS_SUPPORT_OS == 0)` 包起来——这三个向量必须让给 FreeRTOS 的 port.c，否则链接报重复定义 |
| `Drivers/SYSTEM/sys/sys.h` | `SYS_SUPPORT_OS` 由 0 改成 1（**切回裸机版只改这一处**） |
| `Drivers/SYSTEM/delay/delay.c` | OS 分支从"UCOS 专用"换成 FreeRTOS 版 |
| `Drivers/SYSTEM/usart/usart.c` | 串口发送加互斥锁 + `fputc` 保护协议帧 |
| `Projects/MDK-ARM/GD32F303.uvprojx` | 新增 `Middlewares/FreeRTOS` 分组 + 头文件路径（Keil/AC6 → GCC 端口） |
| `Projects/MDK-ARM/.eide/eide.yml` | 同上（EIDE/AC5 → RVDS 端口），并补齐了原清单漏掉的 protocol.c / pressure_calc.c / adc.c |

其余所有驱动、协议、气压算法、Flash 校准代码**一个字都没改**。

---

## 二、三个任务

| 任务 | 优先级 | 栈 | 干什么 | 对应原 main.c 的哪一段 |
|---|---|---|---|---|
| `MeasureTask` | 4 | 2KB | 等测量完成标志 → 中值滤波 → 推样本 → 算气压/高度/温度 → 置显示标志 | CH1/CH2 完成 + 气压计算两块 |
| `ProtocolTask` | 3 | 2KB | `g_proto_frame_ready` 置位就解析帧、回包 | 主循环最后的协议处理 |
| `DisplayTask` | 2 | 1.5KB | 取显示快照 → OLED 刷新（软件 I2C 慢，放最低优先级） | 主循环里的 `need_refresh` 那块 |

堆 `configTOTAL_HEAP_SIZE = 16KB`（heap_4），任务栈都从这里分配。

---

## 三、四个必须知道的坑（都已处理）

1. **delay 会打死 RTOS 时基**：原 `delay_us` 直接改写 `SysTick->LOAD/VAL` 并关掉 SysTick，而 FreeRTOS 的 Tick 就靠 SysTick，那么干调度器必乱。
   现在 `delay_us` **只读** `SysTick->VAL` 计数（不改寄存器、不关中断），`delay_ms` 在调度器跑起来后走 `vTaskDelay`。
   因为不关中断，**TIMER 捕获中断（抢占优先级 0/1）的响应时间与裸机版完全一致**，频率测量精度不受影响。
2. **三个异常向量要腾出来**：`gd32f30x_it.c` 里 SVC/PendSV/SysTick 空函数与 port.c 重复定义，不用宏屏蔽就链接失败。
3. **NVIC 优先级分组必须 PRE4/SUB0**：`main()` 最开始 `nvic_priority_group_set(NVIC_PRIGROUP_PRE4_SUB0);`，必须在任何中断使能之前。
   改完后实测各中断抢占优先级：TIMER 捕获 = 0/1（不受 RTOS 临界区影响）、USART = 7、DMA = 4。
4. **printf 与协议回包抢同一路 UART**：`printf` 单字节轮询、回包走 DMA，两个任务同时写会把协议帧撕开。
   现在 `usart_dma_send()` 整帧持锁，`fputc()` 在 DMA 发帧期间不插字节。

---

## 四、怎么用

**Keil uVision（已验证）**：打开 `Projects/MDK-ARM/GD32F303.uvprojx`，直接 F7 → 0 Error。目标用 ARM Compiler 6（你机器上是 6.21，装在 `E:\keil5\keilf4\ARM\ARMCLANG`），FreeRTOS 走 **GCC 端口**（`portable/GCC/ARM_CM4F`）。

**EIDE（VS Code）**：直接点构建。EIDE 用 AC5，对应 **RVDS 端口**（`portable/RVDS/ARM_CM4F`）；该端口源文件已用 armcc 单独验证可编译。

> 注意：你机器上有两套 Keil —— `E:\keil5\keilf4`（MDK Plus 5.39 / AC6.21，本工程就用它）和 `E:\keil5\32`（旧的，只有 AC5）。
> 老那套的 AC6.7 编不动本工程里的 CMSIS-4 头文件，别用它编 AC6 目标。

---

## 五、已知取舍（不是 bug）

- **内部 Flash 擦写会卡调度**：协议写参数时一次擦写 20–40ms，这段时间其他任务要等。与原工程行为一致。
- **协议/测量任务用 1ms 轮询标志位**，最坏比裸机版晚 1ms 响应。中断里一律不调用 FreeRTOS API，这是刻意设计——保住频率测量的时序。
- 以后若想在中断里直接唤醒任务（`xTaskNotifyFromISR`）：**该中断的抢占优先级数值必须 ≥ 5**（`configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY`）。

---

## 六、想切回裸机版？

1. `Drivers/SYSTEM/sys/sys.h`：`SYS_SUPPORT_OS` 改回 `0`；
2. 用 `User/main_baremetal.c.bak` 覆盖 `User/main.c`（改名为 `main.c`）；
3. 从 Keil/EIDE 文件清单里移除 `app_tasks.c` 与 FreeRTOS 分组（或者直接用原工程——它一直没被改过）。
