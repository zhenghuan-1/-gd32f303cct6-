/* ====================================================================================
 * 文件: main.c
 * 描述: GD32F303 频率计主程序 —— FreeRTOS 版
 * ====================================================================================
 *
 * 和裸机版的区别 (逻辑一行没改, 只是从"超级循环"变成"任务"):
 *   main() 只做: 系统初始化 → 创建任务 → 启动调度器, 之后不再返回
 *   原来的 while(1) 被拆成 3 个任务, 见 app_tasks.c
 *     MeasureTask (4): 频率测量 + 中值滤波 + 气压/高度/温度
 *     ProtocolTask(3): 串口协议解析与回包
 *     DisplayTask (2): OLED 刷新
 *
 * 裸机版原文件保留在 User/main_baremetal.c.bak (不参与编译, 仅作对照)
 *
 * 引脚分配:
 *   - PA8:   CH1频率信号输入 (TIMER0_CH0)
 *   - PA0:   CH2频率信号输入 (TIMER1_ETI)
 *   - PB13/15: OLED I2C (软件模拟)
 *   - PA9/10: USART0 串口通信
 *   - PA4:   DAC输出
 *   - PD2:   LED1
 *
 * 串口协议: #01XX<CMD>[DATA]\r<CKSUM> (见 protocol.c)
 * ==================================================================================== */

#include "sys.h"
#include "gd32f30x.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "oled.h"
#include "dac.h"
#include "adc.h"
#include "string.h"
#include "stdlib.h"
#include "freq_measure.h"
#include "pressure_calc.h"
#include "protocol.h"
#include "app_tasks.h"

/* FreeRTOS */
#include "FreeRTOS.h"
#include "task.h"

/* ====================================================================================
 * 主函数
 * ==================================================================================== */
int main(void)
{
    /* ==================== 系统初始化 ==================== */
    /* NVIC 优先级分组: 必须放在任何中断使能之前!
     * FreeRTOS 规定 configPRIO_BITS 位全部作为抢占优先级(PRE4/SUB0),
     * 这样 configMAX_SYSCALL_INTERRUPT_PRIORITY(=5) 的判断才有意义。 */
    nvic_priority_group_set(NVIC_PRIGROUP_PRE4_SUB0);

    delay_init(120);                       /* 系统时钟120MHz */
    LED_Init();                            /* LED初始化 */

    /* 从内部Flash加载版本号和运行参数 */
    flash_store_init();                    /* 读内部Flash, 版本号 */
    flash_cfg_init();                      /* 读内部Flash, 波特率/站号等 */

    /* UART 直接以 Flash 保存的波特率+校验位+数据位启动 */
    usart_init(flash_cfg_get_baud());
    usart_data_bits_set(flash_cfg_get_data_bits());
    usart_parity_set(flash_cfg_get_parity());
    usart_stop_bits_set(flash_cfg_get_stop_bits());

    OLED_Init();                           /* OLED初始化 */
    Dac_Init();                            /* DAC初始化 */
    freq_measure_init();                   /* 频率测量模块初始化 */
    pressure_calc_init();                  /* 气压计算模块初始化 */
    protocol_init();                       /* 通信协议初始化 */
    adc_temperature_init();

    /* ==================== OLED初始界面 ==================== */
    OLED_Clear();
    OLED_ShowString(0, 0, "Freq+Pressure", 16);
    OLED_ShowString(0, 16, "CH1:PA8 CH2:PA0", 12);
    OLED_ShowString(0, 32, "FreeRTOS V11", 12);
    OLED_Refresh_Gram();

    printf("\r\n=========================================\r\n");
    printf("   GD32F303CCT6 Dual Frequency Meter    \r\n");
    printf("        FreeRTOS V11.3.1 Version        \r\n");
    printf("=========================================\r\n");
    {
        const char *parity_str = "N";
        uint8_t p = flash_cfg_get_parity();
        if (p == 1) parity_str = "O";
        else if (p == 2) parity_str = "E";
        printf("System OK!  Baud: %lu bps  Parity: %s\r\n",
               (unsigned long)flash_cfg_get_baud(), parity_str);
    }
    printf("CH1: PA8 (TIMER0), CH2: PA0 (TIMER1)\r\n");
    printf("Method: Equal Precision, Gate: variable (PR/PPI), default 100ms\r\n");
    printf("[Flash] Internal Flash OK (Config @ 0x08038800)\r\n");
    printf("[RTOS] Kernel heap: %u bytes, Tick: %u Hz\r\n",
           (unsigned)configTOTAL_HEAP_SIZE, (unsigned)configTICK_RATE_HZ);

    /* ==================== 创建任务并启动调度器 ==================== */
    app_tasks_create();

    printf("[RTOS] Starting scheduler...\r\n");

    vTaskStartScheduler();   /* 正常情况下不会返回 */

    /* 只有堆不够、空闲任务都没能创建时才会走到这里 */
    printf("[FATAL] scheduler start failed: not enough heap!\r\n");
    while (1)
    {
        LED1(1);
    }
}
