/* ====================================================================================
 * 文件: app_tasks.c
 * 描述: FreeRTOS 应用任务 —— 把裸机版 main() 里的超级循环拆成 4 个任务
 * ====================================================================================
 *
 * 一、任务划分与优先级（数值越大优先级越高）
 *
 *   任务          优先级  栈     职责
 *   ------------  ------  -----  ---------------------------------------------------
 *   MeasureTask      4    2KB    等两路测量完成 → 中值滤波 → 推气压滑动窗口
 *                                → 算气压/高度/温度 → 填"显示快照"与"串口快照"
 *   ProtocolTask     3    2KB    轮询 g_proto_frame_ready, 解析协议帧并回包
 *   DisplayTask      2    1.5KB  取显示快照 → 刷 OLED（软件 I2C，整屏几十 ms）
 *   StreamTask       1    1.5KB  取串口快照 → printf 流式输出（发不过来就丢帧）
 *   IDLE             0      —    FreeRTOS 空闲任务
 *
 * 二、为什么这样分工（都是实测逼出来的）
 *   1) 测量必须最先跑：闸门一结束就要重启下一轮，晚一点采样率就掉。
 *   2) 打印必须搬出测量任务：9600bps 下发一行(约105字符)要 109ms，若在测量任务里 printf，
 *      这段时间无法重启测量 → 采样率被串口拖到 ~4.6Hz。拆出 StreamTask 后测量稳定在 ~9.5Hz，
 *      串口发得慢就只发最新一帧、中间帧丢弃（"能发多少发多少"）。
 *   3) OLED 也要限速：软件 I2C 刷整屏要几十 ms，若跟着 9.5Hz 刷会吃掉约 40% CPU，
 *      还会把低优先级的 StreamTask 挤成一顿一顿；所以 DisplayTask 每 2 个样本刷一次。
 *
 * 三、任务间通信：只用"互斥锁 + 快照 + 脏标志"，不用队列
 *   MeasureTask 是唯一的数据生产者，其它任务只读快照：
 *     · 显示快照 s_disp_*   + s_disp_mutex   + s_disp_dirty
 *     · 串口快照 s_stream_* + s_stream_mutex + s_stream_dirty
 *   加锁只保护"拷贝快照"这一小段(微秒级)，耗时的 OLED 时序与串口打印都放在锁外，
 *   避免高优先级任务被低优先级任务长时间堵住。
 *
 * 四、与中断的约定（重要）
 *   所有中断服务程序里都不调用 FreeRTOS API，任务靠 vTaskDelay 轮询标志位。
 *   好处：TIMER 捕获中断（抢占优先级 0/1）永远不会被 RTOS 临界区挡住，
 *   测频时序与裸机版完全一致；代价是最坏多等一个轮询周期(1ms)。
 *   以后若要在中断里直接唤醒任务(xTaskNotifyFromISR 等)，
 *   该中断的抢占优先级数值必须 >= 5（configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY）。
 * ==================================================================================== */

#include "app_tasks.h"

#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

#include "sys.h"
#include "gd32f30x.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "oled.h"
#include "dac.h"
#include "adc.h"
#include "freq_measure.h"
#include "pressure_calc.h"
#include "protocol.h"

#include <stdio.h>
#include <string.h>

/* ==================== 全局变量 (与裸机版同名, protocol.c 直接用 extern 引用) ====================
 * 这些是"滤波后"的频率缓存, 协议 F5 指令读的就是它们(不重新计算, 避免拿到已清零的计数器)。 */
uint32_t g_freq_ch1_x1000 = 0;            /* CH1 频率(中值后, ×1000 定点) */
uint32_t g_freq_ch2_x1000 = 0;            /* CH2 频率(中值后, ×1000 定点) */
uint32_t g_ref_ch1_cached  = 0;           /* CH1 本轮参考计数(只用于串口调试输出) */
uint32_t g_ref_ch2_cached  = 0;           /* CH2 本轮参考计数(只用于串口调试输出) */

/* ==================== 频率中值滤波 ====================
 * 每路一个 3 点环形窗口, 取中值后再对外发布:
 *   · 中值对"偶发离群值"天然免疫(比均值好), 但会让阶跃响应慢一拍;
 *   · 窗口 3 是折中: 响应比 6 点快。若输入本身就抖, 可改回 6(FREQ_MEDIAN_WINDOW)。
 * 注意: 窗口里的值也进入气压滑动窗口(见 pressure_calc_push), 所以这里是"全局受益"的单点滤波。 */
#define FREQ_MEDIAN_WINDOW  3   /* 试验: 原为6, 3点响应更快; 效果不好改回6 */
static uint32_t s_freq1_win[FREQ_MEDIAN_WINDOW] = {0};   /* CH1 窗口 */
static uint32_t s_freq2_win[FREQ_MEDIAN_WINDOW] = {0};   /* CH2 窗口 */
static uint8_t  s_freq1_cnt = 0, s_freq1_idx = 0;        /* CH1 已填个数 / 写指针 */
static uint8_t  s_freq2_cnt = 0, s_freq2_idx = 0;        /* CH2 已填个数 / 写指针 */

static uint32_t freq_median(uint32_t *buf, uint8_t n)
{
    uint32_t s[6];
    uint8_t i, j;
    if (n == 0) return 0;
    for (i = 0; i < n; i++) s[i] = buf[i];
    for (i = 1; i < n; i++) {
        uint32_t k = s[i];
        for (j = i; j > 0 && s[j - 1] > k; j--) s[j] = s[j - 1];
        s[j] = k;
    }
    return (n & 1) ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2;
}

/* ==================== 显示快照 (MeasureTask 写 / DisplayTask 读) ====================
 * 为什么要快照: OLED 刷一次要几十 ms, 如果直接让 DisplayTask 读 MeasureTask 正在写的字符串,
 * 可能读到"写了一半"的内容。做法: MeasureTask 在锁内整体 memcpy 进来并置脏标志,
 * DisplayTask 在锁内整体 memcpy 到自己的局部缓冲, 然后到锁外慢慢刷屏。 */
static char  s_disp_ch1[24] = "---";      /* CH1 频率字符串 */
static char  s_disp_ch2[24] = "---";      /* CH2 频率字符串 */
static char  s_disp_p[24]   = "---";      /* 气压字符串 */
static char  s_disp_h[24]   = "---";      /* 高度字符串 */
static char  s_disp_t[16]   = "---";      /* 温度字符串 */
static SemaphoreHandle_t s_disp_mutex = NULL;   /* 保护上面 5 个字符串 */
static volatile uint8_t  s_disp_dirty = 0;      /* 1=有新内容待刷屏 */
/* ==================== 串口流式输出快照 (MeasureTask 写 / StreamTask 读) ====================
 * 【输出解耦改动】原来 printf 直接在 MeasureTask 里做: 9600bps 下一行要 109ms,
 * 而测量任务还负责"启动下一轮测量" —— printf 期间测量无法重启, 采样率被串口拖到 ~4.6Hz。
 * 现在拆成两个任务: MeasureTask 只填快照, StreamTask(最低优先级)负责打印。
 * 串口发得慢就只发最新的一帧(中间帧自动丢), 采样率保持满速 —— "能发多少发多少"。
 * 快照结构与显示快照同理, 同样用"锁内拷贝 + 脏标志"。 */
typedef struct {
    uint32_t ch1_x1000;
    uint32_t ch2_x1000;
    uint32_t ref1;
    uint32_t ref2;
    float    pressure;
    float    altitude;
    float    temperature;
} stream_sample_t;

static stream_sample_t   s_stream_sample;
static SemaphoreHandle_t s_stream_mutex = NULL;
static volatile uint8_t  s_stream_dirty = 0;

/* ====================================================================================
 * MeasureTask: 频率测量 + 滤波 + 气压/高度/温度计算
 * ==================================================================================== */
/* ====================================================================================
 * MeasureTask（优先级 4）—— 系统的心跳，所有数据的唯一生产者
 * ====================================================================================
 * 循环体做三件事:
 *   1) 轮询 g_ch1_measure_done / g_ch2_measure_done（由停表 ISR 置位）;
 *      谁完成了就: 算频率 → 推入中值窗口 → 取中值 → 更新全局缓存 → 立刻重启该路测量。
 *      注意"先取数再重启"的顺序不能反: start() 会把计数器清零, 先重启就拿不到数据了。
 *   2) 两路都有新数据时: 推入气压滑动窗口 → 通知 F5 现采集计数;
 *      到输出节拍就: 算气压(乘加校准) → 限幅 → 算高度 → 算温度 → 填两个快照。
 *   3) 最后 vTaskDelay(1): 1ms 轮询一次, 最坏比裸机版晚 1ms 发现测量完成。
 *
 * 为什么用轮询而不是"中断唤醒任务": 中断里不调用 RTOS API, 才能保证捕获中断
 * (抢占优先级 0/1)不被 RTOS 临界区挡住 —— 这是测频精度的前提(详见文件头第四节)。
 * ==================================================================================== */
static void measure_task(void *pvParameters)
{
    uint32_t freq_ch1_x1000 = 0;           /* CH1频率×1000 (本任务局部) */
    uint32_t freq_ch2_x1000 = 0;           /* CH2频率×1000 (本任务局部) */
    char t_ch1[24], t_ch2[24], t_p[24], t_h[24], t_t[16];
    uint8_t  ch1_new = 0, ch2_new = 0;
    uint16_t output_cycle = 0;

    (void)pvParameters;

    memcpy(t_ch1, s_disp_ch1, sizeof(t_ch1));
    memcpy(t_ch2, s_disp_ch2, sizeof(t_ch2));
    memcpy(t_p,   s_disp_p,   sizeof(t_p));
    memcpy(t_h,   s_disp_h,   sizeof(t_h));
    memcpy(t_t,   s_disp_t,   sizeof(t_t));

    /* 启动两路独立测量 */
    freq_measure_ch1_start();
    freq_measure_ch2_start();

    for (;;)
    {
        uint8_t need_refresh = 0;

        /* ---- CH1 完成: 推入中值窗口, 滤波后统一下发 ---- */
        if (g_ch1_measure_done == 1)
        {
            uint32_t raw = freq_measure_calculate();
            g_ref_ch1_cached = g_ch1_ref_count;

            s_freq1_win[s_freq1_idx] = raw;
            s_freq1_idx = (s_freq1_idx + 1) % FREQ_MEDIAN_WINDOW;
            if (s_freq1_cnt < FREQ_MEDIAN_WINDOW) s_freq1_cnt++;
            freq_ch1_x1000 = freq_median(s_freq1_win, s_freq1_cnt);
            g_freq_ch1_x1000 = freq_ch1_x1000;   /* 协议也用中值 */

            if (freq_ch1_x1000 >= 1000000000UL)
                sprintf(t_ch1, "%lu.%04luMHz", (unsigned long)(freq_ch1_x1000 / 1000000000UL), (unsigned long)((freq_ch1_x1000 / 100000UL) % 10000));
            else if (freq_ch1_x1000 >= 1000000UL)
                sprintf(t_ch1, "%lu.%04lukHz", (unsigned long)(freq_ch1_x1000 / 1000000UL), (unsigned long)((freq_ch1_x1000 / 100UL) % 10000));
            else
                sprintf(t_ch1, "%lu.%03luHz ", (unsigned long)(freq_ch1_x1000 / 1000), (unsigned long)(freq_ch1_x1000 % 1000));

            freq_measure_ch1_start();
            ch1_new = 1;
        }

        /* ---- CH2 完成: 推入中值窗口, 滤波后统一下发 ---- */
        if (g_ch2_measure_done == 1)
        {
            uint32_t raw = freq_measure_ch2_calculate();
            g_ref_ch2_cached = g_ch2_ref_count;

            s_freq2_win[s_freq2_idx] = raw;
            s_freq2_idx = (s_freq2_idx + 1) % FREQ_MEDIAN_WINDOW;
            if (s_freq2_cnt < FREQ_MEDIAN_WINDOW) s_freq2_cnt++;
            freq_ch2_x1000 = freq_median(s_freq2_win, s_freq2_cnt);
            g_freq_ch2_x1000 = freq_ch2_x1000;   /* 协议也用中值 */

            if (freq_ch2_x1000 >= 1000000000UL)
                sprintf(t_ch2, "%lu.%04luMHz", (unsigned long)(freq_ch2_x1000 / 1000000000UL), (unsigned long)((freq_ch2_x1000 / 100000UL) % 10000));
            else if (freq_ch2_x1000 >= 1000000UL)
                sprintf(t_ch2, "%lu.%04lukHz", (unsigned long)(freq_ch2_x1000 / 1000000UL), (unsigned long)((freq_ch2_x1000 / 100UL) % 10000));
            else
                sprintf(t_ch2, "%lu.%03luHz ", (unsigned long)(freq_ch2_x1000 / 1000), (unsigned long)(freq_ch2_x1000 % 1000));

            freq_measure_ch2_start();
            ch2_new = 1;
        }

        /* ---- 两路都有新数据时推入滑动窗口, 每N次计算并输出 ---- */
        if (ch1_new && ch2_new)
        {
            pressure_calc_push(freq_ch1_x1000, freq_ch2_x1000);
            protocol_f5_on_new_sample();  /* F5现采集: 每收到1个新样本计数, 满5个自动回包 */
            ch1_new = 0;
            ch2_new = 0;

            /* 【输出节奏改动】不限流: 每次测量完成就输出一次(原来按 60000000/闸门目标 分频) */
            {
                uint32_t cyc = 1;   /* 恒为 1 → output_cycle 每次归零 → 每完成一次测量就发一行 */
                output_cycle++;
                if (output_cycle >= cyc)
                {
                    float pressure, limit, altitude, temperature;
                    output_cycle = 0;

                    /* 【气压计算公式】 最终气压 = 原始气压 × 乘法器 + 加法器 */
                    pressure = pressure_calc_get() * proto_get_calib_mult() + proto_get_calib_adder();

                    /* 【气压上限限制】 防止异常高气压值导致显示溢出 */
                    limit = proto_get_pressure_limit();
                    if (pressure > limit)
                        pressure = limit;

                    /* 气压显示: xxx.xx */
                    {
                        int32_t p_int = (int32_t)pressure;
                        int32_t p_frac = (int32_t)((pressure - (float)p_int) * 100.0f);
                        if (p_frac < 0) p_frac = -p_frac;
                        sprintf(t_p, "P:%ld.%02ld", (long)p_int, (long)p_frac);
                    }

                    /* 高度显示: xxxx.x */
                    altitude = pressure_to_altitude(pressure);
                    {
                        int32_t a_int = (int32_t)altitude;
                        int32_t a_frac = (int32_t)((altitude - (float)a_int) * 10.0f);
                        if (a_frac < 0) a_frac = -a_frac;
                        sprintf(t_h, "H:%ld.%01ld", (long)a_int, (long)a_frac);
                    }

                    /* 使用TS参数计算温度 */
                    temperature = temperature_calc_get();
                    {
                        int16_t t_int  = (int16_t)temperature;
                        int16_t t_frac = (int16_t)((temperature - (float)t_int) * 100.0f);
                        if (t_frac < 0) t_frac = -t_frac;
                        sprintf(t_t, "T:%d.%02dC", t_int, t_frac);
                    }

                    /* 串口输出: 频率+气压+高度+温度 (SC指令控制) */
                    /* 【输出解耦改动】只填快照, 真正的串口打印交给 StreamTask, 不阻塞测量重启 */
                    xSemaphoreTake(s_stream_mutex, portMAX_DELAY);
                    s_stream_sample.ch1_x1000   = freq_ch1_x1000;
                    s_stream_sample.ch2_x1000   = freq_ch2_x1000;
                    s_stream_sample.ref1        = g_ref_ch1_cached;
                    s_stream_sample.ref2        = g_ref_ch2_cached;
                    s_stream_sample.pressure    = pressure;
                    s_stream_sample.altitude    = altitude;
                    s_stream_sample.temperature = temperature;
                    s_stream_dirty = 1;
                    xSemaphoreGive(s_stream_mutex);

                    need_refresh = 1;
                }
            }
        }

        /* ---- 把新字符串整体交给 DisplayTask (加锁, 毫秒级) ---- */
        if (need_refresh)
        {
            xSemaphoreTake(s_disp_mutex, portMAX_DELAY);
            memcpy(s_disp_ch1, t_ch1, sizeof(s_disp_ch1));
            memcpy(s_disp_ch2, t_ch2, sizeof(s_disp_ch2));
            memcpy(s_disp_p,   t_p,   sizeof(s_disp_p));
            memcpy(s_disp_h,   t_h,   sizeof(s_disp_h));
            memcpy(s_disp_t,   t_t,   sizeof(s_disp_t));
            s_disp_dirty = 1;
            xSemaphoreGive(s_disp_mutex);
        }

        vTaskDelay(pdMS_TO_TICKS(1));   /* 1ms 轮询一次测量完成标志 */
    }
}

/* ====================================================================================
 * ProtocolTask: 串口协议帧处理
 * ==================================================================================== */
/* ====================================================================================
 * ProtocolTask（优先级 3）—— 串口协议帧处理
 * 1ms 轮询 g_proto_frame_ready（由 USART IDLE 中断置位, 帧已收完整帧缓冲里）;
 * protocol_process() 内部解析并回包, 成功时自行清零 g_proto_rx_idx。
 * 最坏比裸机版晚 1ms 回包, 对 9600/115200 下的上位机完全够用。
 * ==================================================================================== */
static void protocol_task(void *pvParameters)
{
    (void)pvParameters;

    for (;;)
    {
        if (g_proto_frame_ready)
        {
            g_proto_frame_ready = 0;
            protocol_process();      /* 内部成功时自行清零 g_proto_rx_idx */
        }

        vTaskDelay(pdMS_TO_TICKS(1));   /* 1ms 轮询: 最坏比裸机版晚 1ms 回包 */
    }
}

/* ====================================================================================
 * DisplayTask: OLED 刷新 (软件 I2C, 整屏约几十毫秒, 放最低优先级)
 * ==================================================================================== */
/* ====================================================================================
 * DisplayTask（优先级 2）—— OLED 刷新
 * 取显示快照(锁内拷贝, 微秒级) → 到锁外慢慢刷屏(软件 I2C, 整屏几十 ms)。
 * 【输出节奏改动】每 2 个样本刷一次(≈4.7Hz): 既保证眼睛看不出卡顿,
 * 又不让它长时间占着 CPU 把低优先级的 StreamTask 挤住。
 * ==================================================================================== */
static void display_task(void *pvParameters)
{
    char b_ch1[24], b_ch2[24], b_p[24], b_h[24], b_t[16];
    uint8_t disp_div = 0;   /* 【输出节奏改动】OLED 抽帧计数 */

    (void)pvParameters;

    for (;;)
    {
        if (s_disp_dirty)
        {
            /* 【输出节奏改动】OLED 每 2 个样本刷一次(≈4.7Hz):
             * 软件 I2C 刷整屏要几十 ms, 若跟着 9.5Hz 的样本刷会吃掉约 40% CPU,
             * 还会把低优先级的串口流任务挤成一顿一顿的 */
            if (disp_div++ < 1) { vTaskDelay(pdMS_TO_TICKS(10)); continue; }
            disp_div = 0;
            /* 只加锁拷贝字符串(微秒级), 耗时的 OLED 时序放在锁外面做 */
            xSemaphoreTake(s_disp_mutex, portMAX_DELAY);
            memcpy(b_ch1, s_disp_ch1, sizeof(b_ch1));
            memcpy(b_ch2, s_disp_ch2, sizeof(b_ch2));
            memcpy(b_p,   s_disp_p,   sizeof(b_p));
            memcpy(b_h,   s_disp_h,   sizeof(b_h));
            memcpy(b_t,   s_disp_t,   sizeof(b_t));
            s_disp_dirty = 0;
            xSemaphoreGive(s_disp_mutex);

            OLED_Clear();
            OLED_ShowString(0, 0, "CH1:", 16);
            OLED_ShowString(32, 0, (const uint8_t *)b_ch1, 16);
            OLED_ShowString(0, 20, "CH2:", 16);
            OLED_ShowString(32, 20, (const uint8_t *)b_ch2, 16);
            OLED_ShowString(0, 40, (const uint8_t *)b_p, 12);
            OLED_ShowString(64, 40, (const uint8_t *)b_h, 12);
            OLED_ShowString(0, 52, (const uint8_t *)b_t, 12);
            OLED_Refresh_Gram();
        }

        vTaskDelay(pdMS_TO_TICKS(20));   /* 20ms 检查一次是否有新数据 */
    }
}

/* ====================================================================================
 * FreeRTOS 钩子函数
 * ==================================================================================== */
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName)
{
    (void)xTask;
    LED1(1);                       /* 点亮 LED1 指示出错 */
    printf("\r\n[FATAL] task stack overflow: %s\r\n", pcTaskName);
    taskDISABLE_INTERRUPTS();
    for (;;) { }
}

void vApplicationMallocFailedHook(void)
{
    LED1(1);                       /* 点亮 LED1 指示出错 */
    printf("\r\n[FATAL] FreeRTOS heap exhausted (configTOTAL_HEAP_SIZE)\r\n");
    taskDISABLE_INTERRUPTS();
    for (;;) { }
}

/* ====================================================================================
 * 创建任务 (在 vTaskStartScheduler() 之前调用)
 * ==================================================================================== */
/* ====================================================================================
 * StreamTask: 串口流式输出 (优先级 1, 只为不拖慢测量)
 *   串口发得过来就每帧都发; 发不过来就只发最新一帧, 中间帧丢弃。
 * ==================================================================================== */
/* ====================================================================================
 * StreamTask（优先级 1，仅高于空闲）—— 串口流式输出
 * 有脏快照且 SC 流已打开就打印一帧。串口发得慢时, 新样本会不断覆盖快照,
 * 于是"只发最新的一帧、中间帧丢弃" —— 这是刻意设计: 测量永远优先于打印。
 * 加锁只在取快照那一瞬间, printf 在锁外做(它要几十~上百 ms)。
 * ==================================================================================== */
static void stream_task(void *pvParameters)
{
    stream_sample_t s;

    (void)pvParameters;

    for (;;)
    {
        if (s_stream_dirty && proto_get_stream_enable())
        {
            xSemaphoreTake(s_stream_mutex, portMAX_DELAY);
            s = s_stream_sample;
            s_stream_dirty = 0;
            xSemaphoreGive(s_stream_mutex);

            printf("[CH1] %lu.%03lu Hz  [CH2] %lu.%03lu Hz  [Ref1] %lu  [Ref2] %lu  [P] %.2f  [H] %.1f  [T] %.2f C\r\n",
                   (unsigned long)(s.ch1_x1000 / 1000),
                   (unsigned long)(s.ch1_x1000 % 1000),
                   (unsigned long)(s.ch2_x1000 / 1000),
                   (unsigned long)(s.ch2_x1000 % 1000),
                   (unsigned long)s.ref1,
                   (unsigned long)s.ref2,
                   (double)s.pressure,
                   (double)s.altitude,
                   (double)s.temperature);
        }

        vTaskDelay(pdMS_TO_TICKS(1));
    }
}

/* ====================================================================================
 * 创建所有任务与互斥锁（在 vTaskStartScheduler() 之前调用一次）
 * 栈深度单位是"字"(1 字 = 4 字节): 512 字 = 2KB。
 * MeasureTask 给 2KB 是因为里面有 sprintf 浮点格式化, 比较吃栈。
 * 堆总量 configTOTAL_HEAP_SIZE = 16KB, 所有任务栈都从这里分配。
 * ==================================================================================== */
void app_tasks_create(void)
{
    s_disp_mutex = xSemaphoreCreateMutex();
    s_stream_mutex = xSemaphoreCreateMutex();

    /* 参数: 入口函数, 任务名, 栈深度(单位=字, 1字=4字节), 参数, 优先级, 句柄 */
    xTaskCreate(measure_task,  "Measure",  512, NULL, 4, NULL);   /* 2KB 栈: 里面有 sprintf 浮点 */
    xTaskCreate(protocol_task, "Protocol", 512, NULL, 3, NULL);   /* 2KB 栈 */
    xTaskCreate(display_task,  "Display",  384, NULL, 2, NULL);   /* 1.5KB 栈 */
    xTaskCreate(stream_task,   "Stream",   384, NULL, 1, NULL);   /* 串口流: 优先级仅高于空闲, 发不过来就丢帧 */
}
