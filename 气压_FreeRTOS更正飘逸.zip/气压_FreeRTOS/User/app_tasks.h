/**
 * ====================================================================================
 * @file     app_tasks.h
 * @brief    应用任务创建入口 (FreeRTOS 版)
 * ====================================================================================
 */
#ifndef __APP_TASKS_H
#define __APP_TASKS_H

#include "gd32f30x.h"

/* 创建测量/协议/显示三个任务 + 互斥锁, 在 vTaskStartScheduler() 之前调用 */
void app_tasks_create(void);

#endif /* __APP_TASKS_H */
