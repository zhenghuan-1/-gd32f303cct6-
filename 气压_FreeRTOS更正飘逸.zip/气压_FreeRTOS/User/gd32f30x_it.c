/*!
    \file    gd32f30x_it.c
    \brief   interrupt service routines

    \version 2017-02-10, V1.0.0, firmware for GD32F30x
    \version 2018-10-10, V1.1.0, firmware for GD32F30x
    \version 2018-12-25, V2.0.0, firmware for GD32F30x
    \version 2020-09-30, V2.1.0, firmware for GD32F30x
*/

/*
    Copyright (c) 2020, GigaDevice Semiconductor Inc.

    Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

    1. Redistributions of source code must retain the above copyright notice, this
       list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright notice,
       this list of conditions and the following disclaimer in the documentation
       and/or other materials provided with the distribution.
    3. Neither the name of the copyright holder nor the names of its contributors
       may be used to endorse or promote products derived from this software without
       specific prior written permission.

    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
OF SUCH DAMAGE.
*/
/* ====================================================================================
 * 文件: gd32f30x_it.c
 * 描述: Cortex-M4 内核异常(Exception)统一入口。GigaDevice 固件库模板原样保留：
 *       NMI / HardFault / MemManage / BusFault / UsageFault 五个系统异常在此给出空实现或
 *       死循环占位；SVC / PendSV / SysTick 三个异常在 FreeRTOS 版下已由 port.c 接管
 *       （详见下方"移植改动"说明块），仅当 SYS_SUPPORT_OS==0（裸机版）才编译下面的空函数。
 * 说明: 本工程所有外设中断(TIMER0/1/4/5、USART0)的真正服务函数都写在各自 BSP 文件
 *       (freq_measure.c / usart.c) 里，不在本文件；本文件只处理内核级异常。
 * ==================================================================================== */

#include "gd32f30x_it.h"
#include "sys.h"            /* SYS_SUPPORT_OS */

/*
 * 函数: NMI_Handler
 * 功能: 处理 NMI（不可屏蔽中断，Non-Maskable Interrupt）异常
 * 说明: NMI 优先级固定为 -2，连 __disable_irq() 关全局中断都挡不住，通常由时钟安全系统(CSS)、
 *       硬件看门狗复位等致命来源触发。本工程未使能任何 NMI 源，保留模板的空实现：
 *       一旦真触发就进入后什么都不做直接返回——仅作占位，真实产品里应在此触发系统复位。
 */
/*!
    \brief      this function handles NMI exception
*/
void NMI_Handler(void)
{
}

/*
 * 函数: HardFault_Handler
 * 功能: 处理 HardFault（硬件错误）异常
 * 说明: 发生了无法被其它 Fault 分类的严重错误：取指失败、总线错误未升级、或栈/指针损坏导致的
 *       非法访问。模板做法是死循环 while(1)：出错即停机，不让程序在错误状态下继续"跑飞"而
 *       破坏测量数据或 Flash。在 FreeRTOS 下也不尝试恢复任务——此时调度器与栈可能已损坏，
 *       死循环等价于"等人/看门狗复位"，是 Cortex-M 上最稳妥的失败策略。
 */
/*!
    \brief      this function handles HardFault exception
*/
void HardFault_Handler(void)
{
    /* if Hard Fault exception occurs, go to infinite loop */
    while (1){
    }
}

/*
 * 函数: MemManage_Handler
 * 功能: 处理 MemManage（内存管理错误）异常
 * 说明: 由 MPU（内存保护单元）违例触发：访问被 MPU 禁止的区域、栈溢出、对齐错误等。
 *       本工程未配置 MPU，正常运行不会进入；保留模板死循环占位，一旦触发说明出现了非法
 *       内存访问，停机待复位。
 */
/*!
    \brief      this function handles MemManage exception
*/
void MemManage_Handler(void)
{
    /* if Memory Manage exception occurs, go to infinite loop */
    while (1){
    }
}

/*
 * 函数: BusFault_Handler
 * 功能: 处理 BusFault（总线错误）异常
 * 说明: 取指或数据访问经过总线时收到错误响应：访问了不存在的外设地址、非法内存映射地址等。
 *       本工程地址映射正常，保留模板死循环占位。
 */
/*!
    \brief      this function handles BusFault exception
*/
void BusFault_Handler(void)
{
    /* if Bus Fault exception occurs, go to infinite loop */
    while (1){
    }
}

/*
 * 函数: UsageFault_Handler
 * 功能: 处理 UsageFault（用法错误）异常
 * 说明: 由程序自身错误触发：未对齐访问、除零、执行未定义/未使能指令、试图切到无效模式等。
 *       FreeRTOS 的 CM4F 端口在非法状态下也可能进这里。保留模板死循环占位——这类错误多为
 *       代码 bug，停机待复位便于定位。
 */
/*!
    \brief      this function handles UsageFault exception
*/
void UsageFault_Handler(void)
{
    /* if Usage Fault exception occurs, go to infinite loop */
    while (1){
    }
}

/* ====================================================================================
 * 【FreeRTOS 移植改动】SVC / PendSV / SysTick 三个异常的去向
 *
 * 这三个异常在裸机模板里是本文件下面的三个空函数；移植 FreeRTOS 后改由内核 port.c 接管：
 *   · vPortSVCHandler     —— SVC_Handler：启动调度器时靠 SVC 指令切到第一个任务；
 *   · xPortPendSVHandler  —— PendSV_Handler：每个 tick 做任务上下文切换（被刻意设为最低优先级，
 *                           不在中断里抢活，避免打断测频捕获中断）；
 *   · xPortSysTickHandler —— SysTick_Handler：1kHz 系统节拍，喂给 FreeRTOS 产生时间片。
 *
 * port.c 里这些函数的原名，通过 FreeRTOSConfig.h 的宏
 *   #define vPortSVCHandler     SVC_Handler
 *   #define xPortPendSVHandler  PendSV_Handler
 *   #define xPortSysTickHandler SysTick_Handler
 * 映射成启动文件(startup)里的标准向量名。因此本文件必须让位、不能再定义同名函数，
 * 否则同一个符号被定义两次，链接直接报 "Symbol multiply defined"。
 *
 * 只有当 SYS_SUPPORT_OS == 0（切回裸机版，见 sys.h）时，下面这三个空函数才参与编译。
 * ==================================================================================== */
#if (SYS_SUPPORT_OS == 0)

/*
 * 函数: SVC_Handler（仅 SYS_SUPPORT_OS==0 裸机版编译）
 * 功能: 裸机模板的 SVC 空实现；FreeRTOS 版下此处不编译，实际由 port.c 的 vPortSVCHandler 接管
 */
/*!
    \brief      this function handles SVC exception
*/
void SVC_Handler(void)
{
}

/*
 * 函数: PendSV_Handler（仅 SYS_SUPPORT_OS==0 裸机版编译）
 * 功能: 裸机模板的 PendSV 空实现；FreeRTOS 版下不编译，实际由 port.c 的 xPortPendSVHandler
 *       接管做任务上下文切换
 */
/*!
    \brief      this function handles PendSV exception
*/
void PendSV_Handler(void)
{
}

/*
 * 函数: SysTick_Handler（仅 SYS_SUPPORT_OS==0 裸机版编译）
 * 功能: 裸机模板的 SysTick 空实现；FreeRTOS 版下不编译，实际由 port.c 的 xPortSysTickHandler
 *       接管产生 1kHz 系统节拍
 */
/*!
    \brief      this function handles SysTick exception
*/
void SysTick_Handler(void)
{
}

#endif /* SYS_SUPPORT_OS == 0 */
