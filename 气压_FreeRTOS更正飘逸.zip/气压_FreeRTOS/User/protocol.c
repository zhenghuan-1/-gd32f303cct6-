/* ====================================================================================
 * 文件: protocol.c
 * 描述: 串口通信协�1�7模块 - ASCII助�1�7符指令解构1�7 + XOR校验 + 响应构建
 * ====================================================================================
 *
 * 【协讄1�7��式�1�7明��1�7
 *   请求帄1�7: #01XX<CMD>[DATA]\r<CKSUM>
 *     - #      : 帧头，固定为 #
 *     - 01     : 设�1�7地址，固定为 01
 *     - XX     : 站号＄1�72字�1�7HEX，默讄1�700
 *     - CMD    : 指令码，2字�1�7(评1�7)戄1�73字�1�7(冄1�7)
 *     - DATA   : 数据部分，可逄1�7
 *     - \r     : 回车，帧结束笄1�7
 *     - CKSUM  : 校验和，2字�1�7HEX大写，XOR(帧头到\r前所有字芄1�7)
 *
 *   响应帄1�7: *01XX<DATA>\r\n<CKSUM>
 *     - *      : 帧头，固定为 *
 *     - 01     : 设�1�7地址
 *     - XX     : 站号
 *     - DATA   : 响应数据
 *     - \r\n   : 回车换�1�7
 *     - CKSUM  : 校验咄1�7
 *
 * 【XOR校验说明〄1�7
 *   XOR(异或)运算：相同为0，不同为1
 *   计算方法：将扢�有字节��个异或，得到校验��1�7
 *   示例＄1�70x01 XOR 0x02 XOR 0x03 = 0x00
 *
 * 【指令分类��1�7
 *   读指令：2字�1�7，�1�7P3、F5、ST等，读取数据
 *   写指令：3字�1�7，�1�7ACC、PAA、PMB等，写入数据
 *   特殊指令：EW(写入使能)、ID(写序列号)
 *
 * 【写入使胄1�7(EW)机制〄1�7
 *   写入Flash前必须先发��EW指令
 *   丢�欄1�7W叄1�7��写一丄1�7��令，写完臄1�7��失效
 *   防�1�7评1�7��作�1�7致Flash袄1�7��外修攄1�7
 *
 * ==================================================================================== */

#include "protocol.h"
#include "usart.h"
#include "freq_measure.h"
#include "pressure_calc.h"

/* 主循玄1�7��存的频率倄1�7 (避免 re-calculate 拿到已清零的数据) */
extern uint32_t g_freq_ch1_x1000;  // CH1 Ƶ��(��ֵ�˲���, ��1000 ����), ������ app_tasks.c, F5/P1/T1 ָ��ֱ�Ӷ���
extern uint32_t g_freq_ch2_x1000;  // CH2 Ƶ��(��ֵ�˲���, ��1000 ����), ����ͬ
#include "adc.h"
#include "dac.h"
#include "gd32f30x_fmc.h"
#include "gd32f30x_bkp.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ====================================================================================
 * 内部Flash读写封�1�7
 *
 * 【GD32F303CCT6 内部Flash特����1�7
 *   - 页大射1�7: 2KB (2048字节)
 *   - 写入: 挄1�732位字(4字节)，只胄1�7 1ↄ1�70，不胄1�7 0ↄ1�71 (霢�先擦附1�7)
 *   - 擦除: 按页，��时~2ms，期间CPU暂停
 *   - 擦写时需关中斄1�7��护，防�1�7丄1�7��打断导致数据损坏
 *
 * 【Flash地址布局〄1�7
 *   代码匄1�7: 0x08000000 ~ 0x08037FFF (224KB)
 *   配置匄1�7: 0x08038000 ~ 0x0803FFFF (32KB＄1�716顄1�7)
 *
 * ==================================================================================== */

/* 内部Flash读取
 * 参数: pbuf-读取缓冲匄1�7, addr-Flash地址, len-读取长度
 * 说明: Flash读取就是直接内存访问，不霢�要特殊操佄1�7
 */
static void intflash_read(uint8_t *pbuf, uint32_t addr, uint16_t len)
{
    memcpy(pbuf, (const void *)addr, len);  // �ڲ� Flash ���ڴ�ӳ���ַ, ֱ�� memcpy ����, ���������ʱ��
}

/* 内部Flash页擦附1�7
 * 参数: page_addr-页起始地坢�
 * 说明: 擦除整页(2KB)，所有字节变丄1�70xFF
 *       擦除期间CPU暂停，需要关丄1�7��保护
 *       __DSB/__ISB是ARM屏障指令，确保操作完戄1�7
 */
static void intflash_erase_page(uint32_t page_addr)
{
    freq_measure_pause();
    __disable_irq();                        /* 关中斄1�7��防�1�7打断 */
    fmc_unlock();                           /* 解锁Flash控制噄1�7 */
    fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT); /* 等待Flash就绪 */
    fmc_page_erase(page_addr);              /* 擦除整页 */
    fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT); /* 等待擦除完成 */
    fmc_lock();                             /* 锁定Flash控制噄1�7 */
    __enable_irq();                         /* 弢�丄1�7�� */
    __DSB();                                /* 数据同�1�7屏障 */
    __ISB();                                /* 指令同�1�7屏障 */
    freq_measure_resume();
}

/* 内部Flash写入
 * 参数: pbuf-写入数据, addr-Flash地址, len-写入长度
 * 说明: 挄1�732位字写入，需覄1�74字节对齐
 *       写入前必须先擦除(叄1�7��1ↄ1�70，不胄1�70ↄ1�71)
 *       写入期间CPU暂停，需要关丄1�7��保护
 */
static void intflash_write(const uint8_t *pbuf, uint32_t addr, uint16_t len)
{
    uint32_t i;
    freq_measure_pause();
    __disable_irq();                        /* 关中斄1�7 */
    fmc_unlock();                           /* 解锁Flash */
    for (i = 0; i < len; i += 4)            /* 挄1�74字�1�7.
	
	
	
	
	�循玄1�7 */
    {
        uint32_t word = 0xFFFFFFFF;         /* 默�1�7倄1�70xFF(穄1�7) */
        uint16_t remaining = len - i;       /* 剩余字节敄1�7 */
        if (remaining >= 4)
            memcpy(&word, pbuf + i, 4);     /* 完整4字节 */
        else
            memcpy(&word, pbuf + i, remaining); /* 不足4字节，高位补0xFF */
        fmc_word_program(addr + i, word);   /* 写入丢�丄1�7�� */
        fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT); /* 等待写入完成 */
    }
    fmc_lock();                             /* 锁定Flash */
    __enable_irq();                         /* 弢�丄1�7�� */
    __DSB();                                /* 数据同�1�7屏障 */
    __ISB();                                /* 指令同�1�7屏障 */
    freq_measure_resume();
}

/* ====================================================================================
 * ISR 接口变量定义
 * 说明: 这些变量在串口中斄1�7��务程庄1�7(ISR)丄1�7��改，在主径1�7��丄1�7�1�7叄1�7
 *       使用volatile关键字防止编译器优化
 * ==================================================================================== */
volatile uint8_t  g_proto_rx_buf[PROTO_RX_BUF_SIZE];  /* 接收缓冲区，存放收到的数捄1�7 */
volatile uint16_t g_proto_rx_idx        = 0;          /* 接收索引，当前收到的字节位置 */
volatile uint8_t  g_proto_rx_mode       = 0;          /* 接收状��机: 0=空闲, 1=正在接收 */
volatile uint8_t  g_proto_rx_need_cksum = 0;          /* 昄1�7��霢�要校验和: 0=不需覄1�7, 1=霢�覄1�7 */
volatile uint8_t  g_proto_frame_ready   = 0;          /* 帧就组1�7��忄1�7: 0=朄1�7��组1�7, 1=收到完整帄1�7 */

/* ====================================================================================
 * 模块内部变量
 * 说明: 这些变量叄1�7��朄1�7��件内使用，�1�7部无法�1�7闄1�7
 *       使用static关键字限制作用域
 * ==================================================================================== */
static uint8_t   s_station      = 0;      /* 当前设�1�7站号 (0~255) */
static char      s_serial[16]   = "XSTK00000000";  /* 序列号，格式: XSTK + 8位后缢� */
static char      s_tx_buf[PROTO_TX_BUF_SIZE];   /* 发��缓冲区，存放�1�7发��的数据 */

/* Flash 版本号存傄1�7 */
static char      s_fw_version[24] = PROTO_FW_VERSION;  /* 当前固件版本叄1�7 */

/* Flash 运�1�7参数 */
static uint32_t  s_baud_rate    = 9600;   /* 串口波特率，叄1�7��1�7: 2400/4800/9600/19200筄1�7 */
static uint8_t   s_parity       = PROTO_PARITY_NONE; /* 校验佄1�7: 0=无校骄1�7, 1=奇校骄1�7, 2=偶校骄1�7 */
static uint8_t   s_data_bits    = PROTO_DATA_BITS_8;  /* 数据佄1�7: 8位或9佄1�7 */
static uint8_t   s_stop_bits    = PROTO_STOP_BITS_1;  /* 停�1�7佄1�7: 1位或2佄1�7 */

/* 允�1�7的波特率列表 */
static const uint32_t s_baud_table[] = {2400, 4800, 9600, 19200, 38400, 57600, 115200};  // �����Ĳ����ʰ�����: BR дָ�����������һ, ����� ER8
#define BAUD_TABLE_SIZE  (sizeof(s_baud_table) / sizeof(s_baud_table[0]))  // ������ = 7 (sizeof ���� / sizeof ��Ԫ��)

/* 【校准参数�1�7明��1�7
 * 加法器和乘法器用于校准气压��1�7
 * 计算兄1�7��: 朢�终气厄1�7 = 原�1�7气压 × 乘法噄1�7 + 加法噄1�7
 *
 * 【双区存储机制��1�7
 * 丢�匄1�7(生效匄1�7): 当前正在使用的校准��1�7
 * 二区(待生效区): 新写入的校准值，下�1�7上电时合并到丢�匄1�7
 *
 * 合并规则:
 *   加法噄1�7: 丢�区��1�7 + 二区倄1�7 ↄ1�7 丢�区��1�7
 *   乘法噄1�7: 丢�区��1�7 × 二区倄1�7 ↄ1�7 丢�区��1�7
 *
 * 这样设�1�7的好处1�7:
 *   1. 叄1�7��約1�7��多个校准倄1�7
 *   2. 防�1�7评1�7��作直接�1�7盖生效��1�7
 *   3. 重启后自动合并，无需手动操作
 */
static float     s_calib_adder  = 0.0f;   /* 加法器校准��1�7 (PAA指令写入) */
static float     s_calib_mult   = 1.0f;   /* 乘法器校准��1�7 (PMB指令写入) */
static float     s_range_low    = 0.0f;   /* 量程下限 (暂未使用) */
static float     s_range_high   = 1000.0f;/* 量程上限 (暂未使用) */

/* 【精度存储�1�7明��1�7
 * PW/PS/PT分别代表不同类型的精庄1�7
 * 精度倄1�7: 0=0.0 1�7, 1=0.1 1�7, 2=0.2 1�7, 3=0.3 1�7
 * 单位昄1�7��分号( 1�7)，用/1000表示
 */
static uint8_t   s_precision_pw = 0;      /* PW精度 (压力精度?) */
static uint8_t   s_precision_ps = 0;      /* PS精度 */
static uint8_t   s_precision_pt = 0;      /* PT精度 */

/* 【气压上限�1�7明��1�7
 * 当气压��超过上限时，按上限值输凄1�7
 * 防�1�7异常高气压���1�7致显示溢凄1�7
 * 默�1�7倄1�7: 10000 (单位取决于气压�1�7算模坄1�7)
 */
static float     s_pressure_limit = 10000.0f; /* 气压上限 (默�1�710000) */

/* 【写入使能标志�1�7明��1�7
 * 为了防�1�7评1�7��作修改Flash，所有写兄1�7lash的指仄1�7
 * 都需要先发��EW指令使能
 * 丢�欄1�7W叄1�7��写一丄1�7��令，写完臄1�7��失效
 * 这样即使评1�7��写入指令，也不会损坏Flash数据
 */
static uint8_t   s_write_enable = 0;      /* EW指令使能标志: 0=禁�1�7, 1=允�1�7 */
/* 【分辨率查表说明〄1�7
 * 分辨率决定�1�7率测量的精度和��度
 * 分辨率越髄1�7(数��越射1�7)，测量越忄1�7��但精度越佄1�7
 * 分辨率越佄1�7(数��越处1�7)，测量越慄1�7��但精度越髄1�7
 *
 * 闸门时间 = 参���1�7数��1�7 / 12000000 (12MHz时钟)
 * 例�1�7: 12000000 / 12000000 = 1秒闸门时闄1�7
 */
#define RESOLUTION_IDX_DEFAULT   6           /* 默�1�7分辨率索弄1�7: "1" (100ms闸门) */
#define RESOLUTION_TABLE_SIZE    10          /* 分辨率表大小 */

/* 分辨率名称字符串 (用于协�1�7显示和解构1�7) */
static const char *s_resolution_names[RESOLUTION_TABLE_SIZE] = {
    "1/100", "1/50", "1/20", "1/10", "1/5", "1/2", "1", "2", "5", "10"  // �ֱ�����ʾ��, ���·� s_resolution_ref_counts ���±�һһ��Ӧ, �±� 6="1" ΪĬ��
};

/* 对应闸门参���1�7数��1�7 (系统时钟12MHz)
 * 计数越大，闸门时间越长，测量精度越高
 */
static const uint32_t s_resolution_ref_counts[RESOLUTION_TABLE_SIZE] = {
       120000UL,    /* 1/100 ↄ1�7 1ms闸门   (朢�忄1�7��精度朢�佄1�7) */
       240000UL,    /* 1/50  ↄ1�7 2ms闸门   */
       600000UL,    /* 1/20  ↄ1�7 5ms闸门   */
      1200000UL,    /* 1/10  ↄ1�7 10ms闸门  */
      2400000UL,    /* 1/5   ↄ1�7 20ms闸门  */
      6000000UL,    /* 1/2   ↄ1�7 50ms闸门  */
     12000000UL,    /* 1     ↄ1�7 100ms闸门 (默�1�7) */
     24000000UL,    /* 2     ↄ1�7 200ms闸门  */
     60000000UL,    /* 5     ↄ1�7 500ms闸门  */
    120000000UL,    /* 10    ↄ1�7 1s闸门    (朢�慄1�7��精度朢�髄1�7) */
};

static uint8_t  s_resolution_idx = RESOLUTION_IDX_DEFAULT;  /* 当前分辨率索弄1�7 */
static float     s_accuracy     = 0.1f;   /* 精度倄1�7 (暂未使用) */
static uint8_t   s_eeprom_en    = 0;      /* EEPROM写使能标忄1�7 (暂未使用) */
static uint8_t   s_stream_enable = 0;     /* 串口臄1�7��流式输出弢�兄1�7: 0=兄1�7, 1=弢� */
static float     s_mult_merged_val = 0.0f; /* 调试甄1�7: 记录合并后的乘法器��1�7 */

/* ====================================================================================
 * 静��函数声昄1�7(前向)
 * ==================================================================================== */
static void flash_serial_init(void);
static void flash_serial_save(void);
static void flash_calib_save_adder_zone2(float val);
static void flash_calib_save_mult_zone2(float val);
static uint8_t calib_read_zone(uint32_t addr, float *out);
static void handler_st (uint8_t station, const char *data, uint8_t data_len);
static void handler_vg (uint8_t station, const char *data, uint8_t data_len);
static void handler_p3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_h3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_f5 (uint8_t station, const char *data, uint8_t data_len);
static void handler_sn_read (uint8_t station, const char *data, uint8_t data_len);
static void handler_fs (uint8_t station, const char *data, uint8_t data_len);
static void handler_dr (uint8_t station, const char *data, uint8_t data_len);
static void handler_br (uint8_t station, const char *data, uint8_t data_len);
static void handler_pt (uint8_t station, const char *data, uint8_t data_len);
static void handler_bt (uint8_t station, const char *data, uint8_t data_len);
static void handler_sb (uint8_t station, const char *data, uint8_t data_len);
static void handler_p1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_pr (uint8_t station, const char *data, uint8_t data_len);
static void handler_acc (uint8_t station, const char *data, uint8_t data_len);
static void handler_adr (uint8_t station, const char *data, uint8_t data_len);
static void handler_ew (uint8_t station, const char *data, uint8_t data_len);
static void handler_ewo (uint8_t station, const char *data, uint8_t data_len);
static void handler_ppi (uint8_t station, const char *data, uint8_t data_len);
static void handler_paa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pmb (uint8_t station, const char *data, uint8_t data_len);

/* 精度Flash操作 */
static uint8_t flash_precision_read(uint32_t addr, uint8_t *val);
static void flash_precision_save(uint32_t addr, uint8_t val);
static void flash_precision_init(void);

/* 气压上限Flash操作 */
static uint8_t flash_pressure_limit_read(float *val);
static void flash_pressure_limit_save(float val);
static void flash_pressure_limit_init(void);

/* 标定参数Flash操作 (PS/TS/PT) */
#define CALIB_PARAM_COUNT 25  /* 每组参数25个double */
static uint8_t flash_calib_param_read(uint32_t addr, double *params);
static void flash_calib_param_save(uint32_t addr, const double *params);
static void flash_calib_param_init(void);

static void handler_tpc (uint8_t station, const char *data, uint8_t data_len);
static void handler_tpcps (uint8_t station, const char *data, uint8_t data_len);
static void handler_tpcts (uint8_t station, const char *data, uint8_t data_len);
static void handler_tpcpt (uint8_t station, const char *data, uint8_t data_len);
static void handler_pc (uint8_t station, const char *data, uint8_t data_len);
static void handler_wvr (uint8_t station, const char *data, uint8_t data_len);
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len);
static void handler_sc (uint8_t station, const char *data, uint8_t data_len);
static void handler_pa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pm (uint8_t station, const char *data, uint8_t data_len);
static void handler_md (uint8_t station, const char *data, uint8_t data_len);
static void handler_ut (uint8_t station, const char *data, uint8_t data_len);

/* ====================================================================================
 * 指令衄1�7
 * 说明: 定义扢�有支持的指令，包拄1�7��令码、长度��类型和处理函数
 *       指令表按长度降序排列(3字�1�7在前＄1�72字�1�7在后)，便于解析匹酄1�7
 *
 * 指令类型:
 *   CMD_TYPE_READ_2  : 2字�1�7读指令，如P3、F5、ST筄1�7
 *   CMD_TYPE_WRITE_2 : 2字�1�7写指令，如ID
 *   CMD_TYPE_WRITE_3 : 3字�1�7写指令，如ACC、PAA、PMB筄1�7
 *
 * 每条指令的结构1�7:
 *   - 指令砄1�7: 2戄1�73丄1�7��笄1�7
 *   - 长度: 指令码的字�1�7敄1�7
 *   - 类型: 读指令或写指仄1�7
 *   - 处理函数: 收到该指令时调用的函敄1�7
 * ==================================================================================== */
static const proto_cmd_entry_t s_cmd_table[] = {
    /* ---- 3字�1�7写指仄1�7 (霢�要EW使能) ---- */
    { "ACC", 3, CMD_TYPE_WRITE_3, handler_acc },   /* 写精度��1�7 */
    { "ADR", 3, CMD_TYPE_WRITE_3, handler_adr },   /* 写站叄1�7 */
    { "EWO", 3, CMD_TYPE_WRITE_3, handler_ewo },   /* 写EEPROM使能 */
    { "PPI", 3, CMD_TYPE_WRITE_3, handler_ppi },   /* 写分辨率 */
    { "PAA", 3, CMD_TYPE_WRITE_3, handler_paa },   /* 写加法器校准 */
    { "PMB", 3, CMD_TYPE_WRITE_3, handler_pmb },   /* 写乘法器校准 */
    { "TPCPS", 5, CMD_TYPE_WRITE_3, handler_tpcps }, /* 写PS标定(单组矄1�7��) */
    { "TPCTS", 5, CMD_TYPE_WRITE_3, handler_tpcts }, /* 写TS标定(单组矄1�7��) */
    { "TPCPT", 5, CMD_TYPE_WRITE_3, handler_tpcpt }, /* 写PT标定(单组矄1�7��) */
    { "TPC",   3, CMD_TYPE_WRITE_3, handler_tpc },   /* 写标定系敄1�7(三组丢�资1�7) */
    { "WVR", 3, CMD_TYPE_WRITE_3, handler_wvr },   /* 写版朄1�7�� */

    /* ---- 2字�1�7读指仄1�7 (无需EW) ---- */
    { "ST", 2, CMD_TYPE_READ_2,  handler_st },     /* 读状怄1�7(通�1�7棢�骄1�7) */
    { "VG", 2, CMD_TYPE_READ_2,  handler_vg },     /* 读版朄1�7�� */
    { "P3", 2, CMD_TYPE_READ_2,  handler_p3 },     /* 读气压��1�7 */
    { "T3", 2, CMD_TYPE_READ_2,  handler_t3 },     /* 读温度��1�7 */
    { "H3", 2, CMD_TYPE_READ_2,  handler_h3 },     /* 读高度��1�7 */
    { "F5", 2, CMD_TYPE_READ_2,  handler_f5 },     /* 读�1�7玄1�7(5个F1+5个F2) */
    { "SN", 2, CMD_TYPE_READ_2,  handler_sn_read },/* 读序列号 */
    { "FS", 2, CMD_TYPE_READ_2,  handler_fs },     /* 读精度��1�7 */
    { "BR", 2, CMD_TYPE_READ_2,  handler_br },     /* 评1�7/写波特率 */
    { "DR", 2, CMD_TYPE_READ_2,  handler_dr },     /* 读站叄1�7 */
    { "PT", 2, CMD_TYPE_READ_2,  handler_pt },     /* 评1�7/写校验位 */
    { "BT", 2, CMD_TYPE_READ_2,  handler_bt },     /* 读数捄1�7�� */
    { "SB", 2, CMD_TYPE_READ_2,  handler_sb },     /* 评1�7/写停歄1�7�� */
    { "P1", 2, CMD_TYPE_READ_2,  handler_p1 },     /* 读�1�7细数捄1�7(频率+气压) */
    { "T1", 2, CMD_TYPE_READ_2,  handler_t1 },     /* 读�1�7细数捄1�7(频率+温度) */
    { "PR", 2, CMD_TYPE_READ_2,  handler_pr },     /* 评1�7/写分辨率 */
    { "SC", 2, CMD_TYPE_READ_2,  handler_sc },     /* 串口流式输出弢�兄1�7 */
    { "PA", 2, CMD_TYPE_READ_2,  handler_pa },     /* 读加法器(丢�匄1�7+二区) */
    { "PM", 2, CMD_TYPE_READ_2,  handler_pm },     /* 读乘法器(丢�匄1�7+二区) */
    { "MD", 2, CMD_TYPE_READ_2,  handler_md },     /* 读调试信恄1�7 */
    { "UT", 2, CMD_TYPE_READ_2,  handler_ut },     /* 评1�7/写气压上附1�7 */
    { "EW", 2, CMD_TYPE_READ_2,  handler_ew },     /* 写入使能 */
    { "PC", 2, CMD_TYPE_READ_2,  handler_pc },     /* 读标定参敄1�7 */

    /* ---- 2字�1�7写指仄1�7 (霢�要EW使能) ---- */
    { "ID", 2, CMD_TYPE_WRITE_2, handler_id_write },/* 写序列号 */
};

#define CMD_TABLE_SIZE  (sizeof(s_cmd_table) / sizeof(s_cmd_table[0]))  // ָ�����Ŀ����, protocol_process ���Ա�������ָ��ƥ��

/* ====================================================================================
 * 兄1�7��函数: 模块初�1�7匄1�7
 * 说明: 系统各1�7��时调甄1�7��从Flash加载扢�有配罄1�7��敄1�7
 *       按顺序加载各丄1�7��罄1�7��，确保依赖关系�1�7硄1�7
 * ==================================================================================== */
void protocol_init(void)
{
    uint16_t i;

    /* 【加载顺序�1�7明��1�7
     * 1. 站号: 朢�先加载，其他指令叄1�7��霢�要站叄1�7
     * 2. 分辨玄1�7: 频率测量的基硢�参数
     * 3. 序列叄1�7: 设�1�7标识
     * 4. 校准参数: 气压计算霢�要，会合并二匄1�7
     * 5. 精度参数: PW/PS/PT精度倄1�7
     * 6. 气压上限: 气压值限刄1�7
     */
    flash_station_init();         /* 从Flash加载站号 */
    flash_resolution_init();      /* 从Flash加载分辨率，同�1�7到全屢�变量 */
    flash_serial_init();          /* 从Flash加载序列叄1�7 */
    flash_calib_init();           /* 从Flash加载校准参数，合并二区到丢�匄1�7 */
    flash_precision_init();       /* 从Flash加载精度参数(PW/PS/PT) */
    flash_pressure_limit_init();  /* 从Flash加载气压上限 */
    flash_calib_param_init();     /* 从Flash加载标定参数(PS/TS/PT) */

    /* 清空接收缓冲区，准�1�7接收新数捄1�7 */
    for (i = 0; i < PROTO_RX_BUF_SIZE; i++)
        g_proto_rx_buf[i] = 0;  // ����ջ���, ��ֹ��һ֡�������ֽ�ƴ����֡
    g_proto_rx_idx        = 0;
    g_proto_rx_mode       = 0;
    g_proto_rx_need_cksum = 0;
    g_proto_frame_ready   = 0;
    /* s_station 甄1�7 flash_station_init 加载, 不清雄1�7 */
}

/* ====================================================================================
 * Flash 版本号存傄1�7
 *
 * 存储格式 (内部Flash 0x0803F000):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 版本字�1�7串长庄1�7
 *   偏移3~: 版本字�1�7丄1�7 (ASCII, 仄1�70结尾)
 * ==================================================================================== */
void flash_store_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    intflash_read(buf, FLASH_STORE_ADDR, 32);  // ���汾��ҳ(ҳ5: 0x08038000+5*2048=0x0803A800)������ 32 �ֽڼ�¼

    magic = ((uint16_t)buf[0] << 8) | buf[1];  // ��¼ǰ���ֽڰ����ƴ��ħ�� A5F3, �����жϸü�¼�Ƿ���Ч

    if (magic == FLASH_STORE_MAGIC)
    {
        /* Flash 丄1�7��有效版本叄1�7, 加载 */
        len = buf[2];  // �汾�ַ������ȴ��ڼ�¼ƫ�� 2
        if (len > 23) len = 23;  // �ضϵ� 23 �ֽ�: s_fw_version[24] ĩβ��Ҫ�� 1 �ֽڴ� '\0'
        for (i = 0; i < len && i < 23; i++)
            s_fw_version[i] = (char)buf[3 + i];  // �Ӽ�¼ƫ�� 3 ��Ѱ汾�ַ�������ȫ�ֻ���
        s_fw_version[len] = '\0';  // �ַ�����β
    }
    else
    {
        /* 首�1�7上电或Flash为空, 写入默�1�7版本叄1�7 */
        len = 0;
        while (PROTO_FW_VERSION[len] && len < 23) len++;  // ͳ��Ĭ�ϰ汾������, ���� 23

        /* 擦除页后写入 */
        intflash_erase_page(FLASH_STORE_ADDR);  // �汾ҳΪ��, �Ȳ���ҳ(2KB)����д��

        buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);   /* 魔数高位 */
        buf[1] = (uint8_t)(FLASH_STORE_MAGIC);         /* 魔数低位 */
        buf[2] = len;                                   /* 版本长度 */
        for (i = 0; i < len; i++)
            buf[3 + i] = (uint8_t)PROTO_FW_VERSION[i];
        for (; i < 29; i++)
            buf[3 + i] = 0xFF;                          /* 剩余塄1�7 0xFF */

        intflash_write(buf, FLASH_STORE_ADDR, 32);  // д�� 32 �ֽڼ�¼(ħ��+����+��+β�� 0xFF ���)
    }
}

/*
 * ����: flash_store_version
 * ����: ���ص�ǰ�̼��汾�ַ���(�Ѱ� Flash/Ĭ�ϳ�ʼ���� s_fw_version)
 * ����: �� '\0' ��β�İ汾��ָ��, �� VG ָ��ֱ�ӻذ�
 */
const char* flash_store_version(void)
{
    return s_fw_version;  // ���ص�ǰ�̼��汾�ַ���ָ��
}

/* ====================================================================================
 * Flash 配置区存傄1�7 (内部Flash, 2KB顄1�7)
 *
 * 【磨损均衡写入策略��1�7
 *   晄1�7��写兄1�7: 每�1�7俄1�7��都�1�7擦除整页再写兄1�7
 *   磨损均衡: 不擦除，直接追加写入到下丢�丄1�7��佄1�7
 *   丢�页可以存很�1�7条�1�7彄1�7(纄1�764杄1�7)
 *   叄1�7��页满了才擦除丢�欄1�7
 *   好�1�7: Flash寿命延长64倄1�7
 *
 * 【存储格式��每条�1�7彄1�7 32 字节:
 *   偏移0~1: 魔数 0xA5 0xF3 (标识有效记录)
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 波特玄1�7 uint32_t (小�1�7庄1�7)
 *   偏移  7: 保留 (站号已迁至独立页)
 *   偏移  8: 校验佄1�7 uint8_t (0=旄1�7, 1=奄1�7, 2=偄1�7)
 *   偏移  9: 数据佄1�7 uint8_t (8戄1�79)
 *   偏移 10: 停�1�7佄1�7 uint8_t (1戄1�72)
 *   偏移11~31: 塄1�7�� 0xFF (预留)
 *
 * 【小竄1�7��说明〄1�7
 *   低字节在前，高字节在各1�7
 *   例�1�7: 9600 = 0x00002580
 *   存储丄1�7: 80 25 00 00
 * ==================================================================================== */

/* 前向声明 (usart.c) */
extern void usart_baud_set(uint32_t baud);

/* 【flash_cfg_save函数说明〄1�7
 * 功能: 保存串口配置到Flash
 * 时机: 俄1�7��波特率��校验位、数捄1�7��、停歄1�7��时调甄1�7
 * 策略: 磨损均衡，追加写入，页满才擦附1�7
 */
static void flash_cfg_save(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];  /* 记录缓冲匄1�7 */
    uint8_t  i;
    int16_t  last_slot = -1;      /* 朢�后一条有效�1�7录的槽号 */
    int16_t  next_slot;           /* 下一丄1�7�1�7写入的槽叄1�7 */
    uint16_t magic;               /* 魔数 */
    uint32_t addr;                /* Flash地址 */

    /* ---- 笄1�71歄1�7: 打包数据到缓冲区 ---- */
    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);  /* 魔数高位 */
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);        /* 魔数低位 */
    buf[2] = 0x01;                              /* 格式版本 */

    /* 波特玄1�7: 4字节小�1�7庄1�7 */
    buf[3] = (uint8_t)(s_baud_rate);            /* 波特率字芄1�70(朢�佄1�7) */
    buf[4] = (uint8_t)(s_baud_rate >> 8);       /* 波特率字芄1�71 */
    buf[5] = (uint8_t)(s_baud_rate >> 16);      /* 波特率字芄1�72 */
    buf[6] = (uint8_t)(s_baud_rate >> 24);      /* 波特率字芄1�73(朢�髄1�7) */

    buf[7] = 0xFF;                              /* 保留(站号已迁至独立页) */
    buf[8] = s_parity;                          /* 校验佄1�7 */
    buf[9] = s_data_bits;                       /* 数据佄1�7 */
    buf[10] = s_stop_bits;                      /* 停�1�7佄1�7 */

    /* 剩余字节塄1�7��0xFF(穄1�7) */
    for (i = 11; i < FLASH_CFG_RECORD_SIZE; i++)
        buf[i] = 0xFF;

    /* ---- 笄1�72歄1�7: 找最后一条有效�1�7录的位置 ----
     * 从前徢�后扫描，找到朢�后一条有效�1�7彄1�7
     * 这样就知道下丢�丄1�7�1�7写入的槽叄1�7
     */
    {
        uint8_t magic_buf[2];
        for (i = 0; i < FLASH_CFG_MAX_RECORDS; i++)
        {
            addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;  // �� i �ĵ�ַ = ��¼����ַ(0x0803B000) + i*32
            intflash_read(magic_buf, addr, 2);  /* 叄1�7�1�72字节魔数 */
            magic = ((uint16_t)magic_buf[0] << 8) | magic_buf[1];  // ���ƴ��ħ��
            if (magic == FLASH_CFG_MAGIC)
                last_slot = (int16_t)i;         /* 记录朢�后有效槽叄1�7 */
        }
    }

    /* ---- 笄1�73歄1�7: 计算下一丄1�7��叄1�7 ---- */
    next_slot = last_slot + 1;  // ׷�ӵ���һ���ղ�, ��������(ĥ��������)

    /* ---- 笄1�74歄1�7: 棢�查是否需要擦附1�7 ----
     * 如果页满亄1�7(扢�有槽都用完了)，需要擦除整顄1�7
     * 擦除后从槄1�70重新弢�始写兄1�7
     */
    if (next_slot >= (int16_t)FLASH_CFG_MAX_RECORDS)  // 2048/32 = 64 ��д������Ҫ��ҳһ��, ��Ч���� ��64
    {
        intflash_erase_page(FLASH_CFG_ADDR);  /* 擦除整页 */
        next_slot = 0;                         /* 从槽0弢�姄1�7 */
    }

    /* ---- 笄1�75歄1�7: 追加写入新�1�7彄1�7 ----
     * 内部Flash特��1�7: 盄1�7��字节丄1�70xFF时可以直接写兄1�7
     * 如果盄1�7��字节不是0xFF，需要先擦除才能写入
     * 这就昄1�7��仢�么我仄1�7��追加写入的方弄1�7
     */
    addr = FLASH_CFG_ADDR + (uint32_t)next_slot * FLASH_CFG_RECORD_SIZE;  // �¼�¼д���ַ
    intflash_write(buf, addr, FLASH_CFG_RECORD_SIZE);  // ׷��дһ�� 32 �ֽ�; Ŀ�괦ԭΪ 0xFF, ��ֱ�� 1->0 д��
}

void flash_cfg_init(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];
    uint16_t magic;
    uint8_t  need_save = 0;
    int16_t  i;

    /* ---- 从后徢�前扫, 找最新一条有效�1�7彄1�7 ---- */
    for (i = (int16_t)(FLASH_CFG_MAX_RECORDS - 1); i >= 0; i--)  // �Ӳ� 63 ��ɨ���� 0, ��һ��ħ�������߼���������
    {
        uint32_t addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
        intflash_read(buf, addr, FLASH_CFG_RECORD_SIZE);
        magic = ((uint16_t)buf[0] << 8) | buf[1];

        if (magic == FLASH_CFG_MAGIC)
        {
            /* 找到! 加载配置 */
            s_baud_rate = (uint32_t)buf[3]
                        | ((uint32_t)buf[4] << 8)
                        | ((uint32_t)buf[5] << 16)
                        | ((uint32_t)buf[6] << 24);  // С����ԭ������: buf[3]����ֽ� -> buf[6]����ֽ�, ���ֽ�����ƴ�� uint32

            /* 合法性�1�7柄1�7: 必须在允许列表中 */
            {
                uint8_t j, valid = 0;
                for (j = 0; j < BAUD_TABLE_SIZE; j++)
                {
                    if (s_baud_rate == s_baud_table[j]) { valid = 1; break; }  // �����Ĳ����ʱ������а��������Ͽ�
                }
                if (!valid)
                {
                    s_baud_rate = 9600;  // �Ƿ������ʻ���Ĭ�� 9600
                    need_save = 1;  // ����������ֵ��д Flash
                }
            }

            /* 加载校验佄1�7 */
            s_parity = buf[8];  // У��λ���ڼ�¼ƫ�� 8
            if (s_parity > PROTO_PARITY_EVEN)
            {
                s_parity = PROTO_PARITY_NONE;  // Խ���������У��
                need_save = 1;
            }

            /* 加载数据佄1�7 */
            s_data_bits = buf[9];  // ����λ����ƫ�� 9
            if (s_data_bits > PROTO_DATA_BITS_9)
            {
                s_data_bits = PROTO_DATA_BITS_8;  // Խ������� 8 ����λ
                need_save = 1;
            }

            /* 加载停�1�7佄1�7 */
            s_stop_bits = buf[10];  // ֹͣλ����ƫ�� 10
            if (s_stop_bits > PROTO_STOP_BITS_2)
            {
                s_stop_bits = PROTO_STOP_BITS_1;  // Խ������� 1 ֹͣλ
                need_save = 1;
            }

            /* 站号甄1�7 flash_station_init() 狄1�7��加载, 不从这里读取 */

            if (need_save)
            {
                flash_cfg_save();
            }
            /* UART 尚未初�1�7匄1�7 */
            return;  // �Ѽ��ص���Ч��¼��ֱ�ӷ���, ������Ĭ�Ϸ�֧
        }
    }

    /* 扇区全空或全无效 ↄ1�7 首�1�7上电 */
    s_baud_rate = 9600;  // ��ҳȫ��=�״��ϵ�, ��Ĭ�� 9600 N 8 1
    s_parity    = PROTO_PARITY_NONE;
    s_data_bits = PROTO_DATA_BITS_8;
    s_stop_bits = PROTO_STOP_BITS_1;
    /* 站号甄1�7 flash_station_init() 狄1�7��初�1�7匄1�7 */
    flash_cfg_save();  // ��Ĭ��������Ϊ�� 0 ��д�� Flash
}

uint32_t flash_cfg_get_baud(void)
{
    return s_baud_rate;
}

uint8_t flash_cfg_get_parity(void)
{
    return s_parity;
}

uint8_t flash_cfg_get_data_bits(void)
{
    return s_data_bits;
}

uint8_t flash_cfg_get_stop_bits(void)
{
    return s_stop_bits;
}

/* ====================================================================================
 * Flash 站号狄1�7��存储 (扇区 2045)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 站号 uint8_t
 *   偏移4~31: 塄1�7�� 0xFF
 *
 * 站号极少变更, 不使用追加磨损均衄1�7, 每�1�7擦除后单条写兄1�7
 * ==================================================================================== */
void flash_station_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_STATION_ADDR, 32);  // ��վ��ҳ(ҳ7: 0x0803B800)�� 32 �ֽڼ�¼

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_CFG_MAGIC)
    {
        /* 有效记录 ↄ1�7 加载站号 */
        s_station = buf[3];  // ��Ч��¼: վ�Ŵ���ƫ�� 3
    }
    else
    {
        /* 首�1�7上电 ↄ1�7 默�1�7站号 0x01, 写入内部Flash */
        s_station = 0x01;  // �״��ϵ�Ĭ��վ�� 0x01
        flash_station_save();  // ��Ĭ��վ������
    }
}

void flash_station_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    intflash_erase_page(FLASH_STATION_ADDR);

    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);
    buf[2] = 0x01;
    buf[3] = s_station;

    for (i = 4; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_STATION_ADDR, 32);
}

/* ---- Flash 分辨率存傄1�7 (内部Flash 0x0803FC00) ---- */
void flash_resolution_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_RESOLUTION_ADDR, 32);  // ���ֱ���ҳ(ҳ8: 0x0803C000)�� 32 �ֽڼ�¼

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_RESOLUTION_MAGIC && buf[2] < RESOLUTION_TABLE_SIZE)  // ħ��ƥ���������� 0~9 �ڲ���Ϊ��Ч
    {
        /* 有效记录 ↄ1�7 加载分辨玄1�7 */
        s_resolution_idx = buf[2];  // ���طֱ�������
    }
    else
    {
        /* 首�1�7上电 ↄ1�7 默�1�7分辨玄1�7 "1" (100ms), 写入内部Flash */
        s_resolution_idx = RESOLUTION_IDX_DEFAULT;  // �״��ϵ���Ĭ������ 6(��Ӧ "1", 100ms բ��)
        flash_resolution_save();
    }

    /* 同�1�7到�1�7率测量模块的闸门盄1�7�� */
    g_target_ref_count = s_resolution_ref_counts[s_resolution_idx];  // ͬ����Ƶբ�Ųο�����: ������բ��ʱ��
    /* 同�1�7信号计数闸门盄1�7��: signal = ref × est_freq / 120MHz */
    g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);  // �����������ź�բ��: Ĭ�� ref=12,000,000 ʱ��ԭ 6500 ��(CH1)
    g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);  // ͬ��, CH2 Ĭ�� 5900 ��
}

void flash_resolution_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    intflash_erase_page(FLASH_RESOLUTION_ADDR);

    buf[0] = (uint8_t)(FLASH_RESOLUTION_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_RESOLUTION_MAGIC);
    buf[2] = s_resolution_idx;

    for (i = 3; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_RESOLUTION_ADDR, 32);
}

uint8_t flash_resolution_get_idx(void)
{
    return s_resolution_idx;
}

/* ====================================================================================
 * Flash 序列号存傄1�7 (内部Flash 0x0803EC00)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 序列号字符串长度 (不含\0)
 *   偏移4~15: 序列号字符串 (ASCII, "XSTK" + 8位后缢�, 兄1�712字�1�7)
 *   偏移16~31: 塄1�7�� 0xFF
 * ==================================================================================== */

static void flash_serial_save(void)
{
    uint8_t buf[32];
    uint8_t len, i;

    len = (uint8_t)strlen(s_serial);  // ���кų���
    if (len > 12) len = 12;  // � 12 �ַ�(XSTK+8λ��׺)

    intflash_erase_page(FLASH_SERIAL_ADDR);

    buf[0] = (uint8_t)(FLASH_SERIAL_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_SERIAL_MAGIC);
    buf[2] = 0x01;
    buf[3] = len;
    for (i = 0; i < len; i++)
        buf[4 + i] = (uint8_t)s_serial[i];
    for (; i < 12; i++)
        buf[4 + i] = 0xFF;
    for (i = 16; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_SERIAL_ADDR, 32);  // д�����к�ҳ(ҳ4: 0x0803A000)
}

static void flash_serial_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    intflash_read(buf, FLASH_SERIAL_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_SERIAL_MAGIC)
    {
        /* 有效记录 ↄ1�7 加载序列叄1�7 */
        len = buf[3];
        if (len > 12) len = 12;
        for (i = 0; i < len; i++)
            s_serial[i] = (char)buf[4 + i];
        s_serial[len] = '\0';
    }
    else
    {
        /* 首�1�7上电 ↄ1�7 默�1�7序列叄1�7, 写入内部Flash */
        strcpy(s_serial, "XSTK00000000");
        flash_serial_save();
    }
}

/* ====================================================================================
 * Flash 校准参数存储 (加法噄1�7/乘法噄1�7, 双区机制)
 *
 * 每个参数有两匄1�7 (各1�71KB狄1�7��顄1�7):
 *   丢�匄1�7: 当前生效倄1�7, 上电读取直接用于计算
 *   二区: 待生效��1�7, 串口指令写入, 下�1�7上电合并到一匄1�7
 *
 * 合并规则:
 *   加法噄1�7: 丢�匄1�7 + 二区 ↄ1�7 丢�匄1�7
 *   乘法噄1�7: 丢�匄1�7 × 二区 ↄ1�7 丢�匄1�7
 *
 * 存储格式 (32字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: float倄1�7 (little-endian)
 *   偏移7~31: 塄1�7�� 0xFF
 * ==================================================================================== */

/* 读取校准区的float倄1�7, 返回1=有效, 0=无效(兄1�70xFF或魔数不寄1�7) */
/* 【calib_read_zone函数说明〄1�7
 * 功能: 从Flash读取校准倄1�7
 * 参数: addr-Flash地址, out-输出缓冲匄1�7
 * 返回: 1=读取成功, 0=无有效数捄1�7
 *
 * 【存储格式��1�732字节:
 *   偏移0~1: 魔数 0xA5 0xF3 (标识有效数据)
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 校准倄1�7 float (4字节)
 *   偏移7~31: 塄1�7�� 0xFF
 *
 * 【float存储说明〄1�7
 *   float类型卄1�74字节，直掄1�7emcpy拷贝
 *   避免内存对齐闄1�7�1�7
 */
static uint8_t calib_read_zone(uint32_t addr, float *out)
{
    uint8_t buf[32];    /* 读取缓冲匄1�7 */
    uint16_t magic;     /* 魔数 */

    /* 读取32字节 */
    intflash_read(buf, addr, 32);  // �� 32 �ֽ�У׼��¼

    /* 棢�查魔数是否�1�7硄1�7 */
    magic = ((uint16_t)buf[0] << 8) | buf[1];
    if (magic != FLASH_CALIB_MAGIC)
        return 0;  /* 魔数不匹配，无有效数捄1�7 */

    /* 拷贝4字节float倄1�7 */
    memcpy(out, &buf[3], 4);  // У׼ֵ�� float(4�ֽ�), ��ƫ�� 3 ֱ�Ӱ��ֽ� memcpy, �ܿ���������
    return 1;  /* 读取成功 */
}

/* 【calib_write_zone函数说明〄1�7
 * 功能: 写入校准值到Flash
 * 参数: addr-Flash地址, val-要写入的校准倄1�7
 * 返回: 1=写入成功, 0=写入失败
 *
 * 【写入流程��1�7
 *   1. 擦除整页(2KB)
 *   2. 构��1�732字节数据
 *   3. 写入Flash
 *   4. 读回验证
 *   5. 如果验证失败，重试最处1�73欄1�7
 *
 * 【为仢�么需要验证��1�7
 *   Flash写入叄1�7��因为干扰或硬件问题失贄1�7
 *   读回验证硄1�7��数据正确写入
 *   3次重试提高成功率
 *
 * 【为仢�么擦除整页��1�7
 *   Flash叄1�7��1ↄ1�70，不胄1�70ↄ1�71
 *   要写入新数据，必须先擦除(全变0xFF)
 *   擦除昄1�7��页进行的，所以擦除整顄1�7
 */
static uint8_t calib_write_zone(uint32_t addr, float val)
{
    uint8_t buf[32];    /* 写入缓冲匄1�7 */
    uint8_t rbuf[32];   /* 读回验证缓冲匄1�7 */
    uint8_t i;
    uint8_t retry;      /* 重试计数噄1�7 */

    /* 朢�多重评1�73欄1�7 */
    for (retry = 0; retry < 3; retry++)  // �����д 3 ��, ��ֹ���β�д�����ʧ��
    {
        /* 笄1�71歄1�7: 擦除整页 */
        intflash_erase_page(addr);

        /* 笄1�72歄1�7: 构��1�732字节数据 */
        buf[0] = (uint8_t)(FLASH_CALIB_MAGIC >> 8);  /* 魔数高位 */
        buf[1] = (uint8_t)(FLASH_CALIB_MAGIC);        /* 魔数低位 */
        buf[2] = 0x01;                                /* 格式版本 */
        memcpy(&buf[3], &val, 4);                     /* float校准倄1�7(4字节) */
        for (i = 7; i < 32; i++)                      /* 剩余塄1�7��0xFF */
            buf[i] = 0xFF;

        /* 笄1�73歄1�7: 写入Flash */
        intflash_write(buf, addr, 32);

        /* 笄1�74歄1�7: 读回验证 */
        intflash_read(rbuf, addr, 32);  // ���ظ�д�����ҳ������У��

        /* 笄1�75歄1�7: 比较写入和�1�7回的数据 */
        if (rbuf[0] == buf[0] && rbuf[1] == buf[1] && rbuf[2] == buf[2] &&
            memcmp(&rbuf[3], &buf[3], 4) == 0)
        {
            return 1;  /* 写入成功 */
        }
        /* 验证失败，继组1�7��评1�7 */
    }

    return 0;  /* 3次重试全部失贄1�7 */
}

/* 清零校准匄1�7 (擦除整页, 全变0xFF) */
static void calib_clear_zone(uint32_t addr)
{
    intflash_erase_page(addr);  // ����ҳ���Ѷ������ȫ 0xFF(=��Ч)
}

/* 【flash_calib_init函数说明〄1�7
 * 功能: 从Flash加载校准参数，合并二区到丢�匄1�7
 * 时机: 系统各1�7��时调甄1�7
 *
 * 【双区存储机制��1�7
 * 丢�匄1�7(生效匄1�7): 当前正在使用的校准��1�7
 * 二区(待生效区): 新写入的校准值，下�1�7上电时合并到丢�匄1�7
 *
 * 【合并�1�7则��1�7
 * 加法噄1�7: 丢�区��1�7 + 二区倄1�7 ↄ1�7 丢�区��1�7
 * 乘法噄1�7: 丢�区��1�7 × 二区倄1�7 ↄ1�7 丢�区��1�7
 *
 * 【合并流程��1�7
 * 1. 读取丢�区和二区的��1�7
 * 2. 如果丢�区有效，二区有数捄1�7��执�1�7合并
 * 3. 合并后写入一区，清除二区
 * 4. 如果丢�区无敄1�7(首�1�7上电)，用二区值作为一匄1�7
 * 5. 如果都空，写入默认��1�7
 *
 * 【为仢�么写成功才清二区〄1�7
 * 防�1�7合并写入失败时丢失二区数捄1�7
 * 如果写入失败，二区数捄1�7��留，下�1�7各1�7��重试
 */
void flash_calib_init(void)
{
    float zone1_val, zone2_val;  /* 丢�区和二区的��1�7 */
    float final_val;             /* 朢�终使用的倄1�7 */
    uint8_t need_write = 0;      /* 昄1�7��霢�要写兄1�7(暂未使用) */

    /* ---- 处理加法噄1�7 ---- */
    if (calib_read_zone(FLASH_CALIB_ADDER1_ADDR, &zone1_val))
    {
        /* 丢�区有敄1�7 */
        if (calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        {
            /* 二区有数捄1�7 ↄ1�7 合并: 丢�匄1�7 + 二区 */
            final_val = zone1_val + zone2_val;
            /* 写入丢�区，成功后清除二匄1�7 */
            if (calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_ADDER2_ADDR);
        }
        else
        {
            /* 二区穄1�7 ↄ1�7 直接使用丢�区��1�7 */
            final_val = zone1_val;
        }
    }
    else
    {
        /* 丢�区无敄1�7(首�1�7上电) */
        if (calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        {
            /* 二区有数捄1�7 ↄ1�7 用二区��作为一匄1�7 */
            final_val = zone2_val;
            if (calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_ADDER2_ADDR);
        }
        else
        {
            /* 都空 ↄ1�7 写默认��1�70.0 */
            final_val = 0.0f;
            calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val);
        }
    }
    s_calib_adder = final_val;  /* 保存到全屢�变量 */

    /* ---- 处理乘法噄1�7 ---- */
    if (calib_read_zone(FLASH_CALIB_MULT1_ADDR, &zone1_val))
    {
        /* 丢�区有敄1�7 */
        if (calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        {
            /* 二区有数捄1�7 ↄ1�7 合并: 丢�匄1�7 × 二区 */
            final_val = zone1_val * zone2_val;
            s_mult_merged_val = final_val;  /* 记录合并值用于调评1�7 */
            /* 写入丢�区，成功后清除二匄1�7 */
            if (calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_MULT2_ADDR);
        }
        else
        {
            /* 二区穄1�7 ↄ1�7 直接使用丢�区��1�7 */
            final_val = zone1_val;
        }
    }
    else
    {
        /* 丢�区无敄1�7(首�1�7上电) */
        if (calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        {
            /* 二区有数捄1�7 ↄ1�7 用二区��作为一匄1�7 */
            final_val = zone2_val;
            if (calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_MULT2_ADDR);
        }
        else
        {
            /* 都空 ↄ1�7 写默认��1�71.0(乘法器默讄1�71.0，不影响计算) */
            final_val = 1.0f;
            calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val);
        }
    }
    s_calib_mult = final_val;  /* 保存到全屢�变量 */
}

float proto_get_calib_adder(void)
{
    return s_calib_adder;
}

float proto_get_calib_mult(void)
{
    return s_calib_mult;
}

/* 串口写入: 叄1�7��二区, 朄1�7�1�7上电不影响一匄1�7 */
static void flash_calib_save_adder_zone2(float val)
{
    calib_write_zone(FLASH_CALIB_ADDER2_ADDR, val);
}

static void flash_calib_save_mult_zone2(float val)
{
    calib_write_zone(FLASH_CALIB_MULT2_ADDR, val);
}

/* ====================================================================================
 * 精度Flash存储 (PW/PS/PT)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 精度倄1�7 (uint8_t, 0=0.0, 1=0.1, 2=0.2, 3=0.3)
 *   偏移4~31: 塄1�7�� 0xFF
 *
 * 精度值极少变曄1�7, 不使用追加磨损均衄1�7, 每�1�7擦除后单条写兄1�7
 * ==================================================================================== */

/* 读取精度倄1�7, 返回1=成功 0=失败 */
static uint8_t flash_precision_read(uint32_t addr, uint8_t *val)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, addr, 32);
    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic != FLASH_PRECISION_MAGIC)
        return 0;

    *val = buf[3];  // ����ֵ����ƫ�� 3
    return 1;
}

/* 保存精度倄1�7 */
static void flash_precision_save(uint32_t addr, uint8_t val)
{
    uint8_t buf[32];
    uint8_t i;

    /* 擦除 */
    intflash_erase_page(addr);

    /* 构��数捄1�7 */
    buf[0] = (uint8_t)(FLASH_PRECISION_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_PRECISION_MAGIC);
    buf[2] = 0x01;
    buf[3] = val;
    for (i = 4; i < 32; i++)
        buf[i] = 0xFF;

    /* 写入 */
    intflash_write(buf, addr, 32);
}

/* 初�1�7化精庄1�7 */
static void flash_precision_init(void)
{
    uint8_t val;

    if (flash_precision_read(FLASH_PRECISION_PW_ADDR, &val))
        s_precision_pw = val;
    else
        s_precision_pw = 0;

    if (flash_precision_read(FLASH_PRECISION_PS_ADDR, &val))
        s_precision_ps = val;
    else
        s_precision_ps = 0;

    if (flash_precision_read(FLASH_PRECISION_PT_ADDR, &val))
        s_precision_pt = val;
    else
        s_precision_pt = 0;
}

/* ====================================================================================
 * 气压上限Flash存储
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 气压上限 float
 *   偏移7~31: 塄1�7�� 0xFF
 * ==================================================================================== */

/* 读取气压上限, 返回1=成功 0=失败 */
static uint8_t flash_pressure_limit_read(float *val)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_PRESSURE_LIMIT_ADDR, 32);
    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic != FLASH_PRESSURE_LIMIT_MAGIC)
        return 0;

    memcpy(val, &buf[3], 4);  // ��ѹ������ float, ��ƫ�� 3 memcpy
    return 1;
}

/* 保存气压上限 */
static void flash_pressure_limit_save(float val)
{
    uint8_t buf[32];
    uint8_t i;

    /* 擦除 */
    intflash_erase_page(FLASH_PRESSURE_LIMIT_ADDR);

    /* 构��数捄1�7 */
    buf[0] = (uint8_t)(FLASH_PRESSURE_LIMIT_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_PRESSURE_LIMIT_MAGIC);
    buf[2] = 0x01;
    memcpy(&buf[3], &val, 4);
    for (i = 7; i < 32; i++)
        buf[i] = 0xFF;

    /* 写入 */
    intflash_write(buf, FLASH_PRESSURE_LIMIT_ADDR, 32);
}

/* 初�1�7化气压上附1�7 */
static void flash_pressure_limit_init(void)
{
    float val;

    if (flash_pressure_limit_read(&val))
        s_pressure_limit = val;
    else
        s_pressure_limit = 10000.0f;  // Flash �޼�¼����Ĭ������ 10000.0
}

/* ====================================================================================
 * 标定参数Flash存储 (PS/TS/PT)
 *
 * 【存储格式��每页存储一组参敄1�7 (25个float = 100字节)
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~102: 25个float参数 (25×4=100字节)
 *   偏移103~2047: 塄1�7�� 0xFF
 * ==================================================================================== */

/* 【flash_calib_param_read函数说明〄1�7
 * 功能: 从Flash读取标定参数
 * 参数: addr-Flash地址, params-输出缓冲匄1�7(25个double)
 * 返回: 1=读取成功, 0=无有效数捄1�7
 */
static uint8_t flash_calib_param_read(uint32_t addr, double *params)
{
    uint8_t buf[208];  /* 2字节魔数 + 1字节版本 + 25×8字节参数 = 203字节 */
    uint16_t magic;

    /* 读取数据 */
    intflash_read(buf, addr, 208);

    /* 棢�查魔敄1�7 */
    magic = ((uint16_t)buf[0] << 8) | buf[1];
    if (magic != FLASH_CALIB_PARAM_MAGIC)
        return 0;

    /* 拷贝25个double参数 */
    memcpy(params, &buf[3], CALIB_PARAM_COUNT * sizeof(double));  // 25 �� double �� 200 �ֽ�, ��ƫ�� 3 �����鿽��
    return 1;
}

/* 【flash_calib_param_save函数说明〄1�7
 * 功能: 保存标定参数到Flash
 * 参数: addr-Flash地址, params-参数数组(25个double)
 * 说明: 会先擦除整页，再写入数据
 */
static void flash_calib_param_save(uint32_t addr, const double *params)
{
    uint8_t buf[208];  /* 2字节魔数 + 1字节版本 + 25×8字节参数 = 203字节 */
    uint8_t i;

    /* 擦除整页 */
    intflash_erase_page(addr);

    /* 构��数捄1�7 */
    buf[0] = (uint8_t)(FLASH_CALIB_PARAM_MAGIC >> 8);  /* 魔数高位 */
    buf[1] = (uint8_t)(FLASH_CALIB_PARAM_MAGIC);        /* 魔数低位 */
    buf[2] = 0x01;                                      /* 格式版本 */

    /* 拷贝25个double参数 */
    memcpy(&buf[3], params, CALIB_PARAM_COUNT * sizeof(double));  // �� 25 �� double ������ƫ�� 3 �𿽽���¼

    /* 塄1�7��剩余字节丄1�70xFF */
    for (i = 203; i < 208; i++)  // 203 ֮�� 208 �� 0xFF
        buf[i] = 0xFF;

    /* 写入Flash */
    intflash_write(buf, addr, 208);  // д 208 �ֽڵ�����궨ҳ(ҳ13/14/15)
}

/* 【flash_calib_param_init函数说明〄1�7
 * 功能: 从Flash加载标定参数(PS/PT)，�1�7罄1�7��pressure_calc模块
 * 时机: 系统各1�7��时调甄1�7
 * 说明: 如果Flash为空(首�1�7上电)，使用代码中的默认��1�7
 */
static void flash_calib_param_init(void)
{
    static double ps_params[CALIB_PARAM_COUNT];
    static double ts_params[CALIB_PARAM_COUNT];
    static double pt_params[CALIB_PARAM_COUNT];

    /* 尝试从Flash加载PS参数 */
    if (flash_calib_param_read(FLASH_CALIB_PS_ADDR, ps_params))
    {
        pressure_calc_set_ps_params(ps_params);
    }

    /* 尝试从Flash加载TS参数 */
    if (flash_calib_param_read(FLASH_CALIB_TS_ADDR, ts_params))
    {
        pressure_calc_set_ts_params(ts_params);
    }

    /* 尝试从Flash加载PT参数 */
    if (flash_calib_param_read(FLASH_CALIB_PT_ADDR, pt_params))
    {
        pressure_calc_set_pt_params(pt_params);
    }
}

/* ====================================================================================
 * 标定参数Flash存储 (PS/TS/PT)
 *
 * 【存储格式��每页存储一组参敄1�7 (25个float = 100字节)
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~102: 25个float参数 (25×4=100字节)
 *   偏移103~2047: 塄1�7�� 0xFF
 *
 * 【参数顺序��1�7
 *   1. Δf1 (归一化参敄1�7)
 *   2. f1_scale (归一化参敄1�7)
 *   3. Δf2 (归一化参敄1�7)
 *   4. f2_scale (归一化参敄1�7)
 *   5~25. k14, k05, k04, k03, k13, k23, k02, k12, k22, k32, k01, k11, k21, k31, k41, k00, k10, k20, k30, k40, k50
 *
 * ==================================================================================== */


/* ====================================================================================
 * 辅助函数: 计算 XOR 校验咄1�7
 *   buf: 待校验数捄1�7
 *   len: 字节敄1�7
 *   返回: XOR 结果 (0x00~0xFF)
 * ==================================================================================== */
uint8_t proto_xor_checksum(const uint8_t *buf, uint16_t len)
{
    uint8_t ck = 0;
    uint16_t i;
    for (i = 0; i < len; i++)
    {
        ck ^= buf[i];  // ���ֽ����: ��ͬΪ 0����ͬΪ 1
    }
    return ck;  // ���� 0x00~0xFF �������
}

/* ====================================================================================
 * 辅助函数: 构建并发送响应帧
 *   臄1�7��计算校验咄1�7, 组�1�7丄1�7 *01XX<data>\r\n<CK>
 *   data: 响应数据字�1�7丄1�7 (不含帧头帧尾校验咄1�7)
 * ==================================================================================== */
void proto_send_response(const char *data)
{
    static uint8_t frame[PROTO_TX_BUF_SIZE];
    uint16_t idx = 0;
    uint8_t  ck;

    /* ---------- 构建帄1�7 ---------- */
    frame[idx++] = '*';                     /* 帧头 */
    frame[idx++] = '0';                     /* 地址高位 */
    frame[idx++] = '0' + PROTO_DEV_ADDR;    /* 地址低位: '1' */
    frame[idx++] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];  /* 站号高位 */
    frame[idx++] = "0123456789ABCDEF"[s_station & 0x0F];         /* 站号低位 */

    /* 数据部分 (前面加空栄1�7, 与帧头分隄1�7) */
    frame[idx++] = ' ';  // ����ǰ��һ���ո�, ��֡ͷ���ָ�
    if (data != NULL)
    {
        while (*data && idx < PROTO_TX_BUF_SIZE - 6)  // �� 6 �ֽ������� \r\n + 2 λУ���, ��Խ��
        {
            frame[idx++] = (uint8_t)(*data++);
        }
    }

    /* 帧尾 \r\n */
    frame[idx++] = 0x0D;
    frame[idx++] = 0x0A;

    /* 校验咄1�7 (范围: 帧头 '*' 刄1�7 \r\n 剄1�7, 卄1�7 idx-2 丄1�7��芄1�7) */
    ck = proto_xor_checksum(frame, idx - 2);
    frame[idx++] = "0123456789ABCDEF"[(ck >> 4) & 0x0F];  // У��͸� 4 λת��д HEX
    frame[idx++] = "0123456789ABCDEF"[ck & 0x0F];  // У��͵� 4 λת��д HEX

    /* ---------- DMA 发��1�7 ---------- */
    usart_dma_send(frame, idx);  // �� DMA ������֡
}

/* ====================================================================================
 * 辅助函数: 发错评1�7��庄1�7
 * ==================================================================================== */
static void proto_send_error(const char *err_msg)
{
    proto_send_response(err_msg);
}

/* ====================================================================================
 * 辅助函数: 2佄1�7 hex 字�1�7 ↄ1�7 uint8
 *   hex: 指向2个ASCII hex字�1�7的指钄1�7
 *   返回: 0x00~0xFF
 * ==================================================================================== */
static uint8_t hex2u8(const char *hex)
{
    uint8_t val = 0;
    uint8_t i;
    for (i = 0; i < 2; i++)
    {
        val <<= 4;  // ������ 4 λ�ڳ��Ͱ��ֽ�
        if (hex[i] >= '0' && hex[i] <= '9')
            val |= hex[i] - '0';  // ���� 0~9
        else if (hex[i] >= 'A' && hex[i] <= 'F')
            val |= hex[i] - 'A' + 10;  // ��д A~F ӳ�䵽 10~15
        else if (hex[i] >= 'a' && hex[i] <= 'f')
            val |= hex[i] - 'a' + 10;  // Сд a~f Ҳ����(��Сд������)
    }
    return val;
}

/* ====================================================================================
 * 核心函数: 协�1�7帧解析与处理 (主循玄1�7��调用)
 * ==================================================================================== */
void protocol_process(void)
{
    uint16_t frame_len;
    uint16_t data_end;       /* \r 的位罄1�7 (数据部分结束) */
    uint8_t  payload_start;  /* 指令码起始位罄1�7 = 5 */
    uint8_t  payload_len;    /* 指令砄1�7+数据总长庄1�7 */
    uint8_t  ck_calc, ck_recv;
    uint8_t  dev_addr;
    uint8_t  station;
    uint16_t i;

    /* ---------- 笄1�71歄1�7: 扄1�7 \r, 定位校验咄1�7 ---------- */
    frame_len = g_proto_rx_idx;
    if (frame_len < 10)   /* 朢�矄1�7��: #01XXCC\rCC = 10字节 */
    {
        /* 帧太矄1�7: 叄1�7��USB分包朄1�7��宄1�7, 静默等待后续数据 */
        return;
    }

    /* 扄1�7 \r 位置 */
    data_end = 0xFFFF;  // ���� 0xFFFF ���"��δ�ҵ�\r"
    for (i = 0; i < frame_len; i++)
    {
        if (g_proto_rx_buf[i] == 0x0D)  // �ڽ��ջ�������֡β�س� 0x0D
        {
            data_end = i;
            break;
        }
    }
    if (data_end == 0xFFFF || data_end + 3 > frame_len)
    {
        /* 帧不完整: 静默等待后续数据拼接 */
        return;
    }
    /* 校验和在 data_end+1 咄1�7 data_end+2 */

    /* ---------- 笄1�72歄1�7: 校验和验评1�7 ---------- */
    ck_recv = hex2u8((const char *)&g_proto_rx_buf[data_end + 1]);  // �յ��� 2 λ HEX У���(��\r֮��)
    ck_calc = proto_xor_checksum((const uint8_t *)g_proto_rx_buf, data_end + 1);  /* 范围: '#'..\r 含\r */
    if (ck_recv != ck_calc)
    {
        proto_send_error("ER3");  /* 校验和错评1�7 */
        g_proto_rx_idx = 0;
        return;
    }

    /* ---------- 笄1�73歄1�7: 校验帧头 ---------- */
    if (g_proto_rx_buf[0] != '#')  // ���ֽڱ���������֡ͷ '#'
    {
        proto_send_error("ER4");  /* 帧头错�1�7 */
        g_proto_rx_idx = 0;
        return;
    }

    /* ---------- 笄1�74歄1�7: 校验设�1�7地址 ---------- */
    dev_addr = hex2u8((const char *)&g_proto_rx_buf[1]);  // �豸��ַ�� buf[1][2], Ӧ���� "01"
    if (dev_addr != PROTO_DEV_ADDR)  // �豸��ַ������Ĭ����(����Ӧ)
    {
        /* 地址不匹酄1�7, 不响庄1�7 */
        g_proto_rx_idx = 0;
        return;
    }

    /* ---------- 笄1�75歄1�7: 解析站号并过滄1�7 ---------- */
    station = hex2u8((const char *)&g_proto_rx_buf[3]);  // վ���� buf[3][4]

    /* 00 = 广播 (全体响应), 其他 = 仅匹配自躄1�7��叄1�7, 不匹配则静默丢弃 */
    if (station != 0x00 && station != s_station)  // 00=�㲥ȫ��Ӧ��; ����ֻ�ϱ���վ�� s_station
    {
        g_proto_rx_idx = 0;
        return;
    }

    /* ---------- 笄1�76歄1�7: 提取指令砄1�7+数据 ---------- */
    payload_start = 5;                                        /* 跳过 # + 01 + XX */
    payload_len   = data_end - payload_start;                 /* 指令砄1�7+数据总长庄1�7 */

    if (payload_len < 2)
    {
        proto_send_error("ER5");  /* 无指令码 */
        g_proto_rx_idx = 0;
        return;
    }

    /* ---------- 笄1�77歄1�7: 查表匹配指令 ---------- */
    for (i = 0; i < CMD_TABLE_SIZE; i++)  // ����ָ�������ƥ��
    {
        const proto_cmd_entry_t *cmd = &s_cmd_table[i];

        if (payload_len < cmd->len)  // ����ָ��Ƚ�����, ���ݲ�����ָ��Ⱦ�ֱ������һ��
            continue;

        /* 比较指令砄1�7 (大小写不敏感  1�7 接收丢�律转大写对比) */
        {
            uint8_t match = 1;
            uint8_t j;
            for (j = 0; j < cmd->len; j++)
            {
                char c = (char)g_proto_rx_buf[payload_start + j];
                if (c >= 'a' && c <= 'z') c -= 32;  /* 小写轄1�7��冄1�7 */
                if (c != cmd->code[j]) { match = 0; break; }
            }
            if (!match) continue;
        }

        /* 命中! 提取数据部分 */
        {
            const char *data_ptr = NULL;
            uint8_t     data_len = 0;

            if (payload_len > cmd->len)
            {
                data_ptr = (const char *)&g_proto_rx_buf[payload_start + cmd->len];  // ����ָ�� = ָ����֮��
                data_len = payload_len - cmd->len;  // ���ݳ��� = �ܳ� - ָ���볤��
            }

            /* 执�1�7处理函数 */
            cmd->handler(station, data_ptr, data_len);  // �ַ�����Ӧ��������
        }
        g_proto_rx_idx = 0;  /* 帧�1�7理完毄1�7, 清缓冄1�7 */
        return;
    }

    /* 朄1�7��配任何指仄1�7 */
    proto_send_error("ER6");  /* 朄1�7��指令 */
    g_proto_rx_idx = 0;
}

/* ====================================================================================
 * 读指令�1�7理函敄1�7
 * ==================================================================================== */

/* ---- ST: 通�1�7查验 ---- */
static void handler_st(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */
    proto_send_response("OK");
}

/* ---- VG: 读版朄1�7 ---- */
static void handler_vg(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */
    proto_send_response(flash_store_version());
}

/* ---- P3: 读气厄1�7 (各1�7��法器/乘法器校凄1�7) ---- */
static void handler_p3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;  // ������ѹ = ����ʽԭʼֵ �� �˷��� + �ӷ���
    if (pressure > s_pressure_limit)  // ����������ضϵ�����
        pressure = s_pressure_limit;
    sprintf(buf, "%.2f", (double)pressure);  // ������λС���ַ���
    proto_send_response(buf);
}

/* ---- P1: 单�1�7采集 (F1频率 + F2频率 + 气压, 各1�7��凄1�7) ---- */
static void handler_p1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    if (pressure > s_pressure_limit)
        pressure = s_pressure_limit;
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),  // ��1000 ��������������
            (unsigned long)(g_freq_ch1_x1000 % 1000),  // ������С���� 3 λ
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)pressure);
    proto_send_response(buf);
}

/* ---- T1: 单�1�7采集 (F1频率 + F2频率 + 温度) ---- */
static void handler_t1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    float temp_c;
    (void)data; (void)data_len;
    (void)station;

    temp_c = temperature_calc_get();
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)temp_c);
    proto_send_response(buf);
}

/* ---- T3: 读温庄1�7 (使用TS参数计算) ---- */
static void handler_t3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float temp_c;
    (void)data; (void)data_len;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    temp_c = temperature_calc_get();
    sprintf(buf, "%.2f", (double)temp_c);
    proto_send_response(buf);
}

/* ---- H3: 读高庄1�7 (气压各1�7��凄1�7) ---- */
static void handler_h3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure, altitude;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;  // ����У׼�˷�/�ӷ�
    if (pressure > s_pressure_limit)
        pressure = s_pressure_limit;
    altitude = pressure_to_altitude(pressure);  // У׼����ѹ���������ģ�ͻ���߶�(m)
    sprintf(buf, "%.2f", (double)altitude);
    proto_send_response(buf);
}

/* ---- F5: 读�1�7率组 (5个CH1 + 5个CH2, 窗口原�1�7数据, 朢�旧→朢�斄1�7) ---- */
static volatile uint8_t s_f5_pending = 0;
static uint8_t s_f5_count = 0;

/*
 * ����: f5_send_window
 * ����: �� F5 ��Ӧ֡ ���� ��� 5 �� CH1 Ƶ�� + ��� 5 �� CH2 Ƶ��
 * ˵��: ���ڹ� 6 ��(PRESSURE_WINDOW_SIZE), ���� 5 ��ʱǰ�油 0.000;
 *       ���˳�������ǰ�������ں�; Ƶ�ʾ��� ����.3λ(��1000����)��ӡ
 */
static void f5_send_window(void)
{
    char     buf[200];
    uint32_t ch1[PRESSURE_WINDOW_SIZE];
    uint32_t ch2[PRESSURE_WINDOW_SIZE];
    uint8_t  cnt, i, pos = 0;

    cnt = pressure_calc_get_window(ch1, ch2);  /* 时间顺序: [0]=朢�旄1�7, [cnt-1]=朢�斄1�7 */

    /* F1 标�1�7 */
    pos += sprintf(&buf[pos], "F1:");

    /* 输出5个F1: 取最斄1�75丄1�7, 不足则在前面衄1�7 0.000 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",  // Ƶ�ʰ� ����.3λ���� ���(��1000 ��ԭ)
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }

    /* F2 标�1�7 */
    buf[pos++] = ',';
    pos += sprintf(&buf[pos], "F2:");

    /* 输出5个F2: 同上 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    buf[pos] = '\0';
    proto_send_response(buf);
}

static void handler_f5(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;
    /* arm fresh collection; actual response sent after 5 new samples */
    s_f5_pending = 1;
    s_f5_count = 0;
}

void protocol_f5_on_new_sample(void)
{
    if (s_f5_pending)
    {
        if (++s_f5_count >= 5)
        {
            s_f5_pending = 0;
            s_f5_count = 0;
            f5_send_window();
        }
    }
}

/* ---- SN: 读序列号 ---- */
static void handler_sn_read(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */
    proto_send_response(s_serial);
}

/* ---- FS: 读量稄1�7 ---- */
static void handler_fs(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    (void)data; (void)data_len;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    /* per-mille to percent: 0.1 permille -> 0.01% */
    sprintf(buf, "PW:%.2f%% PS:%.2f%% PT:%.2f%%",  // ����ֵ 0~3 �� 0.01 ����ɰٷֱ���ʾ(0.1�� -> 0.01%)
            s_precision_pw * 0.01f,
            s_precision_ps * 0.01f,
            s_precision_pt * 0.01f);
    proto_send_response(buf);
}

/* ---- BR: 读波特率 ---- */
/* ---- DR: 读站叄1�7 (返回设�1�7臄1�7��站号, 不修攄1�7) ---- */
static void handler_dr(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[3];
    (void)station; (void)data; (void)data_len;
    buf[0] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];  // վ�Ÿ� 4 λת HEX �ַ�
    buf[1] = "0123456789ABCDEF"[s_station & 0x0F];  // վ�ŵ� 4 λת HEX �ַ�
    buf[2] = '\0';
    proto_send_response(buf);
}

/* ---- BR: 评1�7/写波特率 ---- */
static void handler_br(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[16];
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    if (data != NULL && data_len > 0)
    {
        /* 棢�查写入使胄1�7 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");
            return;
        }
        s_write_enable = 0;  /* 消��使胄1�7 */

        /* ---- 写模弄1�7: 设置新波特率 ---- */
        uint32_t new_baud = 0;
        uint8_t  i;

        for (i = 0; i < data_len; i++)
        {
            if (data[i] >= '0' && data[i] <= '9')
                new_baud = new_baud * 10 + (uint32_t)(data[i] - '0');  // ���ַ��� ASCII ����ƴ��ʮ��������
            else
                break;
        }

        /* 校验: 必须在允许列表中 */
        {
            uint8_t j, valid = 0;
            for (j = 0; j < BAUD_TABLE_SIZE; j++)
            {
                if (new_baud == s_baud_table[j]) { valid = 1; break; }
            }
            if (!valid)
            {
                proto_send_response("ER8");  /* 无效波特玄1�7 */
                return;
            }
        }

        s_baud_rate = new_baud;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧波特率发完响庄1�7, 再切硄1�7�� */
        proto_send_response("OK");

        /* 等待 DMA 发��完戄1�7, 然后切换到新波特玄1�7 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);  // �� DMA �Ѿɲ����ʵ���Ӧ����
        }
        usart_baud_set(s_baud_rate);  // �������е��²�����Ӳ��
    }
    else
    {
        /* ---- 读模弄1�7: 返回当前波特玄1�7 ---- */
        sprintf(buf, "%lu", (unsigned long)s_baud_rate);
        proto_send_response(buf);
    }
}

/* ---- PT: 评1�7/写校验位 ---- */
static void handler_pt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    if (data != NULL && data_len > 0)
    {
        /* 棢�查写入使胄1�7 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");
            return;
        }
        s_write_enable = 0;  /* 消��使胄1�7 */

        /* ---- 写模弄1�7: 设置校验佄1�7 ---- */
        uint8_t new_parity;
        char    c = data[0];

        /* 大小写不敏感 */
        if (c >= 'a' && c <= 'z') c -= 32;  // У��λ��ĸͳһת��д

        if (c == 'N')
            new_parity = PROTO_PARITY_NONE;
        else if (c == 'O')
            new_parity = PROTO_PARITY_ODD;
        else if (c == 'E')
            new_parity = PROTO_PARITY_EVEN;
        else
        {
            proto_send_response("ER8");  /* 无效校验佄1�7 */
            return;
        }

        s_parity = new_parity;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧校验位发完响庄1�7, 再切硄1�7�� */
        proto_send_response("OK");

        /* 等待 DMA 发��完戄1�7, 然后切换到新校验佄1�7 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_parity_set(s_parity);

        /* 切换校验后清空协讄1�7��收状怄1�7: 旧校验下叄1�7��叄1�7��到半帄1�7,
         * 不清掉会和下丢�帄1�7(新校骄1�7)拼接导致校验和错评1�7 */
        g_proto_rx_idx      = 0;  // �л�У��λ�������У�����յ��İ�֡
        g_proto_frame_ready = 0;  // ��ֹ��֡����У���µ�֡ƴ�ӳ���
    }
    else
    {
        /* ---- 读模弄1�7: 返回当前校验佄1�7 ---- */
        const char *p;
        if (s_parity == PROTO_PARITY_ODD)
            p = "O";
        else if (s_parity == PROTO_PARITY_EVEN)
            p = "E";
        else
            p = "N";
        proto_send_response(p);
    }
}

/* ---- BT: 叄1�7�1�7数据佄1�7 ---- */
static void handler_bt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;
    (void)data;
    (void)data_len;

    /* 读模弄1�7: 返回 "8" 戄1�7 "9" */
    if (s_data_bits == PROTO_DATA_BITS_9)
        proto_send_response("9");
    else
        proto_send_response("8");
}

/* ---- SB: 评1�7/写停歄1�7�� ---- */
static void handler_sb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    if (data != NULL && data_len > 0)
    {
        /* 棢�查写入使胄1�7 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");
            return;
        }
        s_write_enable = 0;  /* 消��使胄1�7 */

        /* ---- 写模弄1�7: 设置停�1�7佄1�7 ---- */
        uint8_t new_stop;
        char    c = data[0];

        if (c == '1')
            new_stop = PROTO_STOP_BITS_1;
        else if (c == '2')
            new_stop = PROTO_STOP_BITS_2;
        else
        {
            proto_send_response("ER8");  /* 无效停�1�7佄1�7 */
            return;
        }

        s_stop_bits = new_stop;
        flash_cfg_save();                /* 持久化到 Flash */

        proto_send_response("OK");
        usart_stop_bits_set(s_stop_bits);
    }
    else
    {
        /* ---- 读模弄1�7: 返回当前停�1�7佄1�7 ---- */
        if (s_stop_bits == PROTO_STOP_BITS_2)
            proto_send_response("2");
        else
            proto_send_response("1");
    }
}

/* ---- PR: 读分辨率 ---- */
static void handler_pr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */
    proto_send_response(s_resolution_names[s_resolution_idx]);
}

/* ---- MD: 调试 - 输出全部校准相关参数 ---- */
static void handler_md(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[200];
    uint16_t flag;
    float m_z1, m_z2, a_z1, a_z2;
    uint8_t m_z1_ok, m_z2_ok, a_z1_ok, a_z2_ok;
    uint8_t m_z1_raw[8], m_z2_raw[8];
    uint8_t pos = 0;
    (void)data; (void)data_len;
    (void)station;

    rcu_periph_clock_enable(RCU_PMU);
    rcu_periph_clock_enable(RCU_BKPI);
    flag = bkp_read_data(BKP_DATA_0);

    /* 读取各区域原始数捄1�7 */
    a_z1_ok = calib_read_zone(FLASH_CALIB_ADDER1_ADDR, &a_z1);
    a_z2_ok = calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &a_z2);
    m_z1_ok = calib_read_zone(FLASH_CALIB_MULT1_ADDR, &m_z1);
    m_z2_ok = calib_read_zone(FLASH_CALIB_MULT2_ADDR, &m_z2);

    /* 读各区域原�1�78字节 (魔数+版本+float) */
    uint8_t a_z1_raw[8], a_z2_raw[8];
    intflash_read(a_z1_raw, FLASH_CALIB_ADDER1_ADDR, 8);
    intflash_read(a_z2_raw, FLASH_CALIB_ADDER2_ADDR, 8);
    intflash_read(m_z1_raw, FLASH_CALIB_MULT1_ADDR, 8);
    intflash_read(m_z2_raw, FLASH_CALIB_MULT2_ADDR, 8);

    pos += sprintf(&buf[pos], "BKP:%04X ", flag);
    pos += sprintf(&buf[pos], "Mrg:%.4f ", (double)s_mult_merged_val);
    pos += sprintf(&buf[pos], "RunM:%.4f ", (double)s_calib_mult);
    pos += sprintf(&buf[pos], "RunA:%.4f ", (double)s_calib_adder);
    pos += sprintf(&buf[pos], "A1:%s%.4f ", a_z1_ok ? "" : "X", (double)a_z1);
    pos += sprintf(&buf[pos], "A2:%s%.4f ", a_z2_ok ? "" : "X", (double)a_z2);
    pos += sprintf(&buf[pos], "M1:%s%.4f ", m_z1_ok ? "" : "X", (double)m_z1);
    pos += sprintf(&buf[pos], "M2:%s%.4f ", m_z2_ok ? "" : "X", (double)m_z2);
    pos += sprintf(&buf[pos], "A1R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   a_z1_raw[0], a_z1_raw[1], a_z1_raw[2], a_z1_raw[3],
                   a_z1_raw[4], a_z1_raw[5], a_z1_raw[6], a_z1_raw[7]);
    pos += sprintf(&buf[pos], " A2R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   a_z2_raw[0], a_z2_raw[1], a_z2_raw[2], a_z2_raw[3],
                   a_z2_raw[4], a_z2_raw[5], a_z2_raw[6], a_z2_raw[7]);
    pos += sprintf(&buf[pos], " M1R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   m_z1_raw[0], m_z1_raw[1], m_z1_raw[2], m_z1_raw[3],
                   m_z1_raw[4], m_z1_raw[5], m_z1_raw[6], m_z1_raw[7]);
    pos += sprintf(&buf[pos], " M2R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   m_z2_raw[0], m_z2_raw[1], m_z2_raw[2], m_z2_raw[3],
                   m_z2_raw[4], m_z2_raw[5], m_z2_raw[6], m_z2_raw[7]);

    /* 测试: 直接冄1�70x0803E800并�1�7囄1�7 */
    {
        uint8_t test_buf[8] = {0xA5, 0xF3, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40}; /* 2.0的前8字节 */
        uint8_t test_read[8];
        intflash_erase_page(0x0803D800);
        intflash_write(test_buf, 0x0803D800, 8);
        intflash_read(test_read, 0x0803D800, 8);
        pos += sprintf(&buf[pos], " TST:%02X%02X%02X%02X%02X%02X%02X%02X",
                       test_read[0], test_read[1], test_read[2], test_read[3],
                       test_read[4], test_read[5], test_read[6], test_read[7]);
    }

    proto_send_response(buf);
}

/* ---- UT: 评1�7/写气压上附1�7 ---- */
/* 【handler_ut函数说明〄1�7
 * 功能: 读取或写入气压上附1�7
 * 指令: UT
 * 格式: 读取-UT, 写入-UT<倄1�7>
 * 示例: 读取-#0100UT\r<CKSUM>, 写入-#0100UT5000\r<CKSUM>
 *
 * 【功能�1�7明��1�7
 * 读取: 返回当前气压上限倄1�7
 * 写入: 设置新的气压上限值，霢�要EW使能
 *
 * 【气压上限作用��1�7
 * 当气压��超过上限时，按上限值输凄1�7
 * 防�1�7异常高气压���1�7致显示溢凄1�7
 *
 * 【存储位罄1�7��1�7
 * Flash page 12
 *
 * 【使用示例��1�7
 * 1. 读取: #0100UT\r<CKSUM> ↄ1�7 *0101 10000.0\r\n<CKSUM>
 * 2. 写入: #0100EW\r<CKSUM> ↄ1�7 *0101 OK\r\n<CKSUM>
 * 3. 写入: #0100UT5000\r<CKSUM> ↄ1�7 *0101 OK\r\n<CKSUM>
 */
static void handler_ut(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    (void)station;

    if (data != NULL && data_len > 0)
    {
        /* 写模弄1�7: 棢�查写入使胄1�7 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");  /* 拒绝写入 */
            return;
        }
        s_write_enable = 0;  /* 消��使胄1�7 */

        /* 解析新上限��1�7 */
        float new_limit = (float)atof(data);
        if (new_limit > 0.0f)  /* 上限必须大于0 */
        {
            s_pressure_limit = new_limit;  /* 更新内存 */
            flash_pressure_limit_save(new_limit);  /* 保存到Flash */
        }
    }

    /* 返回当前上限倄1�7 */
    sprintf(buf, "%.1f", (double)s_pressure_limit);
    proto_send_response(buf);
}

float proto_get_pressure_limit(void)
{
    return s_pressure_limit;
}

/* ---- EW: 写入使能 (叄1�7�1�7下一丄1�7��入指令有敄1�7) ---- */
/* 【handler_ew函数说明〄1�7
 * 功能: 写入使能指令
 * 指令: EW
 * 说明: 发��EW后，允�1�7执�1�7下一丄1�7��兄1�7lash的指仄1�7
 *       丢�欄1�7W叄1�7��写一丄1�7��令，写完臄1�7��失效
 *       这样设�1�7防�1�7评1�7��作损坏Flash数据
 *
 * 【使用示例��1�7
 * 1. 发��1�7: #0100EW\r<CKSUM>
 * 2. 接收: *0101 OK\r\n<CKSUM>
 * 3. 发��1�7: #0100PAA1.5\r<CKSUM> (现在叄1�7��写入)
 * 4. 接收: *0101 OK\r\n<CKSUM>
 * 5. 发��1�7: #0100PMB2.0\r<CKSUM> (拒绝，需要重新EW)
 * 6. 接收: *0101 DENY\r\n<CKSUM>
 */
static void handler_ew(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;  /* 朄1�7��用参敄1�7 */
    (void)station;

    s_write_enable = 1;  /* 设置写入使能标志 */
    proto_send_response("OK");
}

/* ====================================================================================
 * 写指令�1�7理函敄1�7
 * ==================================================================================== */

/* ---- SC: 串口流式输出弢�兄1�7 (切换, 返回当前状��1�7) ---- */
static void handler_sc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;

    s_stream_enable = !s_stream_enable;  /* 切换弢�兄1�7 */
    proto_send_response(s_stream_enable ? "ON" : "OFF");
}

uint8_t proto_get_stream_enable(void)
{
    return s_stream_enable;
}

/* ---- PA: 读加法器 (丢�区生效��1�7, 二区待生效��1�7) ---- */
static void handler_pa(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    float zone2_val;
    (void)data; (void)data_len;
    (void)station;

    if (!calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        zone2_val = 0.0f;
    sprintf(buf, "%.4f,%.4f", (double)s_calib_adder, (double)zone2_val);
    proto_send_response(buf);
}

/* ---- PM: 读乘法器 (丢�区生效��1�7, 二区待生效��1�7) ---- */
static void handler_pm(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    float zone2_val;
    (void)data; (void)data_len;
    (void)station;

    if (!calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        zone2_val = 0.0f;
    sprintf(buf, "%.4f,%.4f", (double)s_calib_mult, (double)zone2_val);
    proto_send_response(buf);
}

/* ---- ACC: 写量程精庄1�7 ---- */
/* 【handler_acc函数说明〄1�7
 * 功能: 写入精度倄1�7
 * 指令: ACC
 * 格式: ACC<类型><倄1�7> (无空栄1�7)
 * 示例: ACCPW0.1, ACCPS0.2, ACCPT0.3
 *
 * 【参数�1�7明��1�7
 * 类型: PW(压力精度), PS(?), PT(?)
 * 倄1�7: 0.0, 0.1, 0.2, 0.3 (单位: 千分号��1�7)
 *
 * 【存储位罄1�7��1�7
 * PW: Flash page 9
 * PS: Flash page 10
 * PT: Flash page 11
 *
 * 【使用示例��1�7
 * 1. 发��1�7: #0100EW\r<CKSUM> (先使胄1�7)
 * 2. 接收: *0101 OK\r\n<CKSUM>
 * 3. 发��1�7: #0100ACCPW0.1\r<CKSUM>
 * 4. 接收: *0101 OK\r\n<CKSUM>
 */
static void handler_acc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");  /* 拒绝写入 */
        return;
    }
    s_write_enable = 0;  /* 消��使能，丢�欄1�7W叄1�7��写一丄1�7��仄1�7 */

    if (data != NULL && data_len >= 4)
    {
        /* 格式: PW0.1, PS0.2, PT0.3 (无空栄1�7) */
        uint8_t type = 0;  /* 0=PW, 1=PS, 2=PT */
        float val;
        uint8_t precision_val;

        /* 笄1�71歄1�7: 解析类型 (剄1�72丄1�7��笄1�7) */
        if (data[0] == 'P' && data[1] == 'W')
            type = 0;  /* PW: 压力精度 */
        else if (data[0] == 'P' && data[1] == 'S')
            type = 1;  /* PS: ? */
        else if (data[0] == 'P' && data[1] == 'T')
            type = 2;  /* PT: ? */
        else
        {
            proto_send_response("ERR");  /* 类型错�1�7 */
            return;
        }

        /* 笄1�72歄1�7: 解析数��1�7 (笄1�73丄1�7��符开姄1�7) */
        val = (float)atof(&data[2]);  /* 字�1�7串转浄1�7��敄1�7 */
        if (val == 0.0f)
            precision_val = 0;  /* 0.0 1�7 */
        else if (val == 0.1f)
            precision_val = 1;  /* 0.1 1�7 */
        else if (val == 0.2f)
            precision_val = 2;  /* 0.2 1�7 */
        else if (val == 0.3f)
            precision_val = 3;  /* 0.3 1�7 */
        else
        {
            proto_send_response("ERR");  /* 数��错评1�7 */
            return;
        }

        /* 笄1�73歄1�7: 保存到�1�7应的Flash */
        switch (type)
        {
            case 0:  /* PW */
                s_precision_pw = precision_val;  /* 更新内存 */
                flash_precision_save(FLASH_PRECISION_PW_ADDR, precision_val);  /* 保存到Flash */
                break;
            case 1:  /* PS */
                s_precision_ps = precision_val;
                flash_precision_save(FLASH_PRECISION_PS_ADDR, precision_val);
                break;
            case 2:  /* PT */
                s_precision_pt = precision_val;
                flash_precision_save(FLASH_PRECISION_PT_ADDR, precision_val);
                break;
        }
    }
    proto_send_response("OK");
}

/* ---- ADR: 写站叄1�7 ---- */
static void handler_adr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data != NULL && data_len >= 2)
    {
        uint8_t new_station = hex2u8(data);  // վ���� 2 λ HEX, ת�� 0~255
        s_station = new_station;
        flash_station_save();       /* 持久化到狄1�7��扇区 2045 */
    }
    proto_send_response("OK");
}

/* ---- EWO: 冄1�7 EEPROM 使能 ---- */
static void handler_ewo(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data != NULL && data_len > 0)
    {
        s_eeprom_en = (data[0] == '1') ? 1 : 0;  // EWO Ԥ������: '1' ʹ�ܷ����
    }
    proto_send_response("OK");
}

/* ---- PPI: 写压力分辨率 ---- */
static void handler_ppi(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");   /* 缺少数据 */
        return;
    }

    /* 遍历查表, 匹配分辨率字符串 */
    for (i = 0; i < RESOLUTION_TABLE_SIZE; i++)
    {
        if (strncmp(data, s_resolution_names[i], data_len) == 0
            && s_resolution_names[i][data_len] == '\0')
        {
            /* 合法倄1�7: 更新全局闸门盄1�7�� */
            s_resolution_idx = i;
            g_target_ref_count = s_resolution_ref_counts[i];  // ���к�ͬ��բ�Ųο�����
            /* 同�1�7信号计数闸门盄1�7�� */
            g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);  // ͬ�������� CH1 �ź�բ�ż���
            g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);  // ͬ�������� CH2 �ź�բ�ż���

            /* 持久化到 Flash */
            flash_resolution_save();

            proto_send_response("OK");
            return;
        }
    }

    /* 朄1�7��酄1�7 ↄ1�7 无效参数 */
    proto_send_response("ER8");
}

/* ---- PAA: 写加法器校准 (写入二区, 下�1�7上电合并到一匄1�7) ---- */
static void handler_paa(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data != NULL && data_len > 0)
    {
        float val = (float)atof(data);  // �����ӷ�������ֵ
        if (!calib_write_zone(FLASH_CALIB_ADDER2_ADDR, val))  // д��ӷ�������(����Ч), ʧ�ܻ� ER9
        {
            proto_send_response("ER9");  /* Flash写入失败 */
            return;
        }
    }
    proto_send_response("OK");
}

/* ---- PMB: 写乘法器校准 (写入二区, 下�1�7上电合并到一匄1�7) ---- */
static void handler_pmb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data != NULL && data_len > 0)
    {
        float val = (float)atof(data);
        if (!calib_write_zone(FLASH_CALIB_MULT2_ADDR, val))
        {
            proto_send_response("ER9");  /* Flash写入失败 */
            return;
        }
    }
    proto_send_response("OK");
}

/* ---- TPC: 写标定系敄1�7 (暂存, 后续叄1�7��新�1�7项式矩阵) ---- */
/* 【handler_tpc函数说明〄1�7
 * 功能: 写入标定参数
 * 指令: TPC
 * 格式: TPC PS<参数25丄1�7>;TS<参数25丄1�7>;PT<参数25丄1�7>
 * 示例: TPC PS 65000,3800,...;TS 67000,3400,...;PT 69000,3500,...
 *
 * 【参数校验��1�7
 * 每组参数必须昄1�725个float值，否则返回错�1�7
 *
 * 【存储位罄1�7��1�7
 * PS: Flash page 13
 * TS: Flash page 14
 * PT: Flash page 15
 */
/* 【handler_tpc函数说明〄1�7
 * 功能: 写入标定参数
 * 指令: TPC
 * 格式: TPC PS<参数25丄1�7>;TS<参数25丄1�7>;PT<参数25丄1�7>
 * 示例: TPC PS 65000,3800,...;TS 67000,3400,...;PT 69000,3500,...
 *
 * 【参数校验��1�7
 * 每组参数必须昄1�725个float值，否则返回错�1�7
 *
 * 【存储位罄1�7��1�7
 * PS: Flash page 13
 * TS: Flash page 14
 * PT: Flash page 15
 */
static void handler_tpc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");
        return;
    }

    /* parse three groups: TS<25>;PS<25>;PT<25> */
    {
        const char *p = data;
        static double ps_params[CALIB_PARAM_COUNT];
        static double ts_params[CALIB_PARAM_COUNT];
        static double pt_params[CALIB_PARAM_COUNT];
        uint8_t param_idx;

        /* TS params - optional "TS" prefix, first group defaults to TS */
        {
            if (p[0] == 'T' && p[1] == 'S')
            {
                p += 2;
                if (*p == ' ') p++;
            }

            for (param_idx = 0; param_idx < CALIB_PARAM_COUNT; param_idx++)
            {
                ts_params[param_idx] = atof(p);  // atof ����һ�� double ����
                while (*p && *p != ',' && *p != ';' && *p != '\r') p++;  // ������һ���ָ�������β
                if (*p == ',') p++;
                else if (*p == ';') { param_idx++; break; }
                else
                {
                    proto_send_response("ERR");
                    return;
                }
            }

            if (param_idx != CALIB_PARAM_COUNT)
            {
                proto_send_response("ERR");
                return;
            }
        }

        /* PS params - optional "PS" prefix after ';' */
        {
            if (*p != ';')
            {
                proto_send_response("ERR");
                return;
            }
            p++;

            if (p[0] == 'P' && p[1] == 'S')
            {
                p += 2;
                if (*p == ' ') p++;
            }

            for (param_idx = 0; param_idx < CALIB_PARAM_COUNT; param_idx++)
            {
                ps_params[param_idx] = atof(p);
                while (*p && *p != ',' && *p != ';' && *p != '\r') p++;
                if (*p == ',') p++;
                else if (*p == ';') { param_idx++; break; }
                else
                {
                    proto_send_response("ERR");
                    return;
                }
            }

            if (param_idx != CALIB_PARAM_COUNT)
            {
                proto_send_response("ERR");
                return;
            }
        }

        /* PT params - optional "PT" prefix after ';' */
        {
            if (*p != ';')
            {
                proto_send_response("ERR");
                return;
            }
            p++;

            if (p[0] == 'P' && p[1] == 'T')
            {
                p += 2;
                if (*p == ' ') p++;
            }

            for (param_idx = 0; param_idx < CALIB_PARAM_COUNT; param_idx++)
            {
                pt_params[param_idx] = atof(p);
                while (*p && *p != ',' && *p != ';' && *p != '\r' && *p != '\0') p++;
                if (*p == ',') p++;
                else if (*p == ';' || *p == '\r' || *p == '\0') { param_idx++; break; }
                else
                {
                    proto_send_response("ERR");
                    return;
                }
            }

            if (param_idx != CALIB_PARAM_COUNT)
            {
                proto_send_response("ERR");
                return;
            }
        }

        flash_calib_param_save(FLASH_CALIB_PS_ADDR, ps_params);
        flash_calib_param_save(FLASH_CALIB_TS_ADDR, ts_params);
        flash_calib_param_save(FLASH_CALIB_PT_ADDR, pt_params);

        pressure_calc_set_ps_params(ps_params);
        pressure_calc_set_ts_params(ts_params);
        pressure_calc_set_pt_params(pt_params);

        proto_send_response("OK");
    }
}

/* ---- TPCPS: 写PS标定系数 (单组25丄1�7��敄1�7, 矄1�7��~280字节) ---- */
/* 格式: TPCPS 65000,3800,... (25个float逗号分隔, 不需要PS标�1�7) */
static void handler_tpcps(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t param_idx;
    static double params[CALIB_PARAM_COUNT];
    const char *p;
    (void)station; (void)data_len;

    if (!s_write_enable) { proto_send_response("DENY"); return; }
    s_write_enable = 0;

    if (data == NULL || *data == '\0') { proto_send_response("ER7"); return; }

    p = data;
    while (*p == ' ') p++;

    for (param_idx = 0; param_idx < CALIB_PARAM_COUNT; param_idx++)
    {
        params[param_idx] = atof(p);
        while (*p && *p != ' ' && *p != ',' && *p != ';' && *p != '\r' && *p != '\0') p++;
        while (*p == ' ' || *p == ',') p++;
        if (*p == ';' || *p == '\r' || *p == '\0') { param_idx++; break; }
    }
    if (param_idx != CALIB_PARAM_COUNT) { proto_send_response("ERR"); return; }

    flash_calib_param_save(FLASH_CALIB_PS_ADDR, params);
    pressure_calc_set_ps_params(params);  /* 立即生效 */
    proto_send_response("OK");
}

/* ---- TPCTS: 写TS标定系数 (单组25丄1�7��敄1�7, 矄1�7��~300字节) ---- */
static void handler_tpcts(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t param_idx;
    static double params[CALIB_PARAM_COUNT];
    const char *p;
    (void)station; (void)data_len;

    if (!s_write_enable) { proto_send_response("DENY"); return; }
    s_write_enable = 0;

    if (data == NULL || *data == '\0') { proto_send_response("ER7"); return; }

    p = data;
    while (*p == ' ') p++;

    for (param_idx = 0; param_idx < CALIB_PARAM_COUNT; param_idx++)
    {
        params[param_idx] = atof(p);
        while (*p && *p != ' ' && *p != ',' && *p != ';' && *p != '\r' && *p != '\0') p++;
        while (*p == ' ' || *p == ',') p++;
        if (*p == ';' || *p == '\r' || *p == '\0') { param_idx++; break; }
    }
    if (param_idx != CALIB_PARAM_COUNT) { proto_send_response("ERR"); return; }

    flash_calib_param_save(FLASH_CALIB_TS_ADDR, params);
    pressure_calc_set_ts_params(params);  /* 立即生效 */
    proto_send_response("OK");
}

/* ---- TPCPT: 写PT标定系数 (单组25丄1�7��敄1�7, 矄1�7��~270字节) ---- */
static void handler_tpcpt(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t param_idx;
    static double params[CALIB_PARAM_COUNT];
    const char *p;
    (void)station; (void)data_len;

    if (!s_write_enable) { proto_send_response("DENY"); return; }
    s_write_enable = 0;

    if (data == NULL || *data == '\0') { proto_send_response("ER7"); return; }

    p = data;
    while (*p == ' ') p++;

    for (param_idx = 0; param_idx < CALIB_PARAM_COUNT; param_idx++)
    {
        params[param_idx] = atof(p);
        while (*p && *p != ' ' && *p != ',' && *p != ';' && *p != '\r' && *p != '\0') p++;
        while (*p == ' ' || *p == ',') p++;
        if (*p == ';' || *p == '\r' || *p == '\0') { param_idx++; break; }
    }
    if (param_idx != CALIB_PARAM_COUNT) { proto_send_response("ERR"); return; }

    flash_calib_param_save(FLASH_CALIB_PT_ADDR, params);
    pressure_calc_set_pt_params(params);  /* 立即生效 */
    proto_send_response("OK");
}

/* 【handler_pc函数说明〄1�7
 * 功能: 读取标定参数
 * 指令: PC
 * 返回: 15丄1�7��数，带标号，逗号分隔
 * 格式: Tt-k30:倄1�7,Tt-k40:倄1�7,Tt-k50:倄1�7,Ps-k14:倄1�7,Ps-k05:倄1�7,...
 *
 * 【返回的15丄1�7��数��1�7
 * TS: Tt-k30, Tt-k40, Tt-k50 (3丄1�7)
 * PS: Ps-k14, Ps-k05, Ps-k04, Ps-k03, Ps-k13, Ps-k23 (6丄1�7)
 * PT: Pt-k00, Pt-k10, Pt-k20, Pt-k30, Pt-k40, Pt-k50 (6丄1�7)
 */
static void handler_pc(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[800];
    uint16_t pos = 0;
    static double ps_params[CALIB_PARAM_COUNT];
    static double ts_params[CALIB_PARAM_COUNT];
    static double pt_params[CALIB_PARAM_COUNT];
    (void)data; (void)data_len;
    (void)station;

    /* 从Flash读取三组参数 */
    if (!flash_calib_param_read(FLASH_CALIB_PS_ADDR, ps_params) ||
        !flash_calib_param_read(FLASH_CALIB_TS_ADDR, ts_params) ||
        !flash_calib_param_read(FLASH_CALIB_PT_ADDR, pt_params))
    {
        /* Flash为空，使用默认参敄1�7 */
        /* PS默�1�7: Δf1=65000, f1_scale=3800, Δf2=59000, f2_scale=3700 */
        ps_params[0] = 65000.0; ps_params[1] = 3800.0; ps_params[2] = 59000.0; ps_params[3] = 3700.0;  // PS Ĭ��ǰ 4 ���һ������: ��f1=65000 f1_scale=3800 ��f2=59000 f2_scale=3700
        ps_params[4] = 23392.128518; ps_params[5] = 4781.604294; ps_params[6] = 894.836195;
        ps_params[7] = -80.166787; ps_params[8] = 3521.446816; ps_params[9] = 45853.375261;
        ps_params[10] = -31.061953; ps_params[11] = -225.548104; ps_params[12] = 5228.960876;
        ps_params[13] = 45020.691682; ps_params[14] = -538.863937; ps_params[15] = -11.107721;
        ps_params[16] = -210.360991; ps_params[17] = 3472.179803; ps_params[18] = 22136.615546;
        ps_params[19] = 661.933891; ps_params[20] = 628.383544; ps_params[21] = 19.318891;
        ps_params[22] = -65.337509; ps_params[23] = 869.761164; ps_params[24] = 4363.371597;

        /* TS默�1�7: Δf1=67000, f1_scale=3400, Δf2=57000, f2_scale=3500 */
        ts_params[0] = 67000.0; ts_params[1] = 3400.0; ts_params[2] = 57000.0; ts_params[3] = 3500.0;
        ts_params[4] = -51540.666802; ts_params[5] = -10639.306226; ts_params[6] = -8574.159444;
        ts_params[7] = -1192.055229; ts_params[8] = -33349.524963; ts_params[9] = -100950.282909;
        ts_params[10] = 62.531171; ts_params[11] = -3451.915184; ts_params[12] = -49029.201003;
        ts_params[13] = -99943.395118; ts_params[14] = -198.060965; ts_params[15] = 134.729419;
        ts_params[16] = -3351.636471; ts_params[17] = -32289.226921; ts_params[18] = -50012.792114;
        ts_params[19] = 17.709475; ts_params[20] = -194.948391; ts_params[21] = 64.674796;
        ts_params[22] = -1090.735473; ts_params[23] = -8038.003013; ts_params[24] = -10118.257036;

        /* PT默�1�7: Δf1=69000, f1_scale=3500, Δf2=55000, f2_scale=3900 */
        pt_params[0] = 69000.0; pt_params[1] = 3500.0; pt_params[2] = 55000.0; pt_params[3] = 3900.0;
        pt_params[4] = 27012.526537; pt_params[5] = 5530.603019; pt_params[6] = 1652.604618;
        pt_params[7] = 23.328971; pt_params[8] = 6446.174426; pt_params[9] = 52894.765013;
        pt_params[10] = -34.398654; pt_params[11] = 67.879673; pt_params[12] = 9479.932671;
        pt_params[13] = 51909.653386; pt_params[14] = -512.135010; pt_params[15] = -15.992962;
        pt_params[16] = 67.368365; pt_params[17] = 6230.225024; pt_params[18] = 25533.491431;
        pt_params[19] = 1904.967029; pt_params[20] = 628.062869; pt_params[21] = 13.823200;
        pt_params[22] = 23.709267; pt_params[23] = 1544.080372; pt_params[24] = 5036.415497;
    }

    /* TS: Ts-k30, Ts-k40, Ts-k50 */
    pos += sprintf(&buf[pos], "Ts-k30:%.15g,Ts-k40:%.15g,Ts-k50:%.15g,",
                   ts_params[22], ts_params[23], ts_params[24]);

    /* PS: Ps-k14, Ps-k05, Ps-k04, Ps-k03, Ps-k13, Ps-k23 */
    pos += sprintf(&buf[pos], "Ps-k14:%.15g,Ps-k05:%.15g,Ps-k04:%.15g,Ps-k03:%.15g,Ps-k13:%.15g,Ps-k23:%.15g,",
                   ps_params[4], ps_params[5], ps_params[6],
                   ps_params[7], ps_params[8], ps_params[9]);

    /* PT: Pt-k00, Pt-k10, Pt-k20, Pt-k30, Pt-k40, Pt-k50 */
    pos += sprintf(&buf[pos], "Pt-k00:%.15g,Pt-k10:%.15g,Pt-k20:%.15g,Pt-k30:%.15g,Pt-k40:%.15g,Pt-k50:%.15g",
                   pt_params[19], pt_params[20], pt_params[21],
                   pt_params[22], pt_params[23], pt_params[24]);

    proto_send_response(buf);
}

/* ---- WVR: 写版朄1�7�� (3字�1�7写指仄1�7) ---- */
static void handler_wvr(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t buf[32];
    uint8_t len, i;

    (void)station;           /* 叄1�7�1�7臄1�7��站号, 不�1�7盄1�7 */

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");  /* 缺少版本叄1�7 */
        return;
    }

    /* 限制长度 */
    len = (data_len > 23) ? 23 : data_len;  // �汾��� 23 �ַ�

    /* 更新内存 */
    for (i = 0; i < len; i++)
        s_fw_version[i] = data[i];
    s_fw_version[len] = '\0';

    /* 写入内部Flash */
    intflash_erase_page(FLASH_STORE_ADDR);  // д�汾ǰ�Ȳ��汾ҳ

    buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_STORE_MAGIC);
    buf[2] = len;
    for (i = 0; i < len; i++)
        buf[3 + i] = (uint8_t)s_fw_version[i];
    for (; i < 29; i++)
        buf[3 + i] = 0xFF;

    intflash_write(buf, FLASH_STORE_ADDR, 32);
    proto_send_response("OK");
}

/* ---- ID: 写序列号 (2字�1�7写指仄1�7) ----
 *
 * 格式: #01XXID<12位序列号>\r<CK>
 * 序列叄1�7: "XSTK" + 8位后缢� (0-9 A-Z a-z, 存储时统丢�轄1�7��冄1�7)
 * 示例: #0100IDXSTK24505322\rXX
 * ---- */
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;

    /* 棢�查写入使胄1�7 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消��使胄1�7 */

    if (data == NULL || data_len != 12)
    {
        proto_send_response("ER8");  /* 长度必须丄1�712 */
        return;
    }

    /* 验证前缀 "XSTK" (大小写不敏感) */
    for (i = 0; i < 4; i++)
    {
        char c = data[i];
        if (c >= 'a' && c <= 'z') c -= 32;  // Сдת��дͳһУ��/�洢
        if (c != "XSTK"[i])
        {
            proto_send_response("ER8");  /* 前缀错�1�7 */
            return;
        }
    }

    /* 验证后缀8佄1�7: 0-9 A-Z a-z, 统一轄1�7��写存兄1�7 */
    for (i = 4; i < 12; i++)
    {
        char c = data[i];
        if (c >= 'a' && c <= 'z') c -= 32;  /* 小写轄1�7��冄1�7 */
        if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z')))
        {
            proto_send_response("ER8");  /* 后缀各1�7��法字笄1�7 */
            return;
        }
        s_serial[i] = c;
    }
    s_serial[0] = 'X';  // ǰ׺ 4 λǿ��д�ɴ�д XSTK
    s_serial[1] = 'S';
    s_serial[2] = 'T';
    s_serial[3] = 'K';
    s_serial[12] = '\0';  // ���к� 12 �ַ��󲹴�β

    flash_serial_save();  /* 持久化到内部Flash */
    proto_send_response("OK");
}
