/*
 * ====================================================================================
 * 文件: FreeRTOSConfig.h
 * 描述: FreeRTOS 内核配置 —— GD32F303CCT6 (Cortex-M4F @120MHz) + Keil MDK
 * 内核: FreeRTOS-Kernel V11.3.1
 * ====================================================================================
 *
 * 说明:
 *   1) 本工程的 NVIC 优先级分组必须设成 PRE4/SUB0(nvic_priority_group_set),
 *      FreeRTOS 要求 4 位优先级全部作为抢占优先级, 见 main.c。
 *   2) configMAX_SYSCALL_INTERRUPT_PRIORITY = 5: 会调用 FreeRTOS API(FromISR 类)的
 *      中断, 抢占优先级数值必须 >= 5。本工程中断里一律不调用 RTOS API,
 *      所以 TIMER 捕获中断(优先级 0/1)不受任何影响, 测量时序与裸机版一致。
 *   3) 堆用 heap_4(带碎片合并), 16KB; 任务栈全部从这里分配。
 * ====================================================================================
 */
#ifndef FREERTOS_CONFIG_H
#define FREERTOS_CONFIG_H

/* 时钟: system_gd32f30x.c 中定义的 SystemCoreClock, 本工程 120MHz */
extern uint32_t SystemCoreClock;

#define configUSE_PREEMPTION                    1
#define configUSE_PORT_OPTIMISED_TASK_SELECTION 1
#define configUSE_TICKLESS_IDLE                 0
#define configCPU_CLOCK_HZ                      (SystemCoreClock)
#define configTICK_RATE_HZ                      ((TickType_t)1000)      /* 1ms 一个 Tick */
#define configMAX_PRIORITIES                    (32)
#define configMINIMAL_STACK_SIZE                ((unsigned short)128)
#define configTOTAL_HEAP_SIZE                   ((size_t)(16 * 1024))   /* RAM 共 48KB */
#define configMAX_TASK_NAME_LEN                 (16)
#define configUSE_16_BIT_TICKS                  0
#define configIDLE_SHOULD_YIELD                 1

/* 同步原语 */
#define configUSE_MUTEXES                       1
#define configUSE_RECURSIVE_MUTEXES             1
#define configUSE_COUNTING_SEMAPHORES           1
#define configUSE_QUEUE_SETS                    0
#define configQUEUE_REGISTRY_SIZE               8

/* 调试 */
#define configCHECK_FOR_STACK_OVERFLOW          2
#define configUSE_MALLOC_FAILED_HOOK            1
#define configUSE_IDLE_HOOK                     0
#define configUSE_TICK_HOOK                     0
#define configUSE_TRACE_FACILITY                0
#define configGENERATE_RUN_TIME_STATS           0

/* 功能裁剪 */
#define configUSE_TIMERS                        0
#define configUSE_CO_ROUTINES                   0
#define configUSE_TASK_NOTIFICATIONS            1
#define configUSE_NEWLIB_REENTRANT              0
#define configSUPPORT_STATIC_ALLOCATION         0
#define configSUPPORT_DYNAMIC_ALLOCATION        1
#define configENABLE_BACKWARD_COMPATIBILITY     0

/* ---------------- 中断优先级 ----------------
 * GD32F303 的 Cortex-M4 实现了 4 位优先级(0~15, 数值越小越紧急)
 * configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY = 5  → 0x50
 * 即: 抢占优先级 0~4 的中断不归 FreeRTOS 管(不能调用 RTOS API, 但响应最快)
 *     抢占优先级 5~15 的中断可以调用 xxxFromISR 系列函数
 */
#define configPRIO_BITS                         4
#define configLIBRARY_LOWEST_INTERRUPT_PRIORITY         15
#define configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY    5
#define configKERNEL_INTERRUPT_PRIORITY \
    (configLIBRARY_LOWEST_INTERRUPT_PRIORITY << (8 - configPRIO_BITS))
#define configMAX_SYSCALL_INTERRUPT_PRIORITY \
    (configLIBRARY_MAX_SYSCALL_INTERRUPT_PRIORITY << (8 - configPRIO_BITS))

/* 断言失败: 关中断死等, 方便调试器里看调用栈 */
#define configASSERT(x)                         \
    if ((x) == 0) { taskDISABLE_INTERRUPTS(); for (;;) { } }

/* ---------------- 中断向量交给 port.c ----------------
 * 这三个函数由 FreeRTOS 的 port.c 实现并重命名到启动文件的标准向量名,
 * 因此 gd32f30x_it.c 里的同名空函数必须屏蔽掉(否则重复定义链接报错)。
 */
#define vPortSVCHandler                         SVC_Handler
#define xPortPendSVHandler                      PendSV_Handler
#define xPortSysTickHandler                     SysTick_Handler

/* ---------------- 可选 API ---------------- */
#define INCLUDE_vTaskPrioritySet                1
#define INCLUDE_uxTaskPriorityGet               1
#define INCLUDE_vTaskDelete                     1
#define INCLUDE_vTaskSuspend                    1
#define INCLUDE_vTaskDelayUntil                 1
#define INCLUDE_vTaskDelay                      1
#define INCLUDE_xTaskGetSchedulerState          1
#define INCLUDE_xTaskGetCurrentTaskHandle       1
#define INCLUDE_xTaskGetIdleTaskHandle          1
#define INCLUDE_uxTaskGetStackHighWaterMark     1
#define INCLUDE_xTaskAbortDelay                 1
#define INCLUDE_xTaskGetHandle                  1
#define INCLUDE_eTaskGetState                   1
#define INCLUDE_xQueueGetMutexHolder            1
#define INCLUDE_xTimerPendFunctionCall          0      /* configUSE_TIMERS=0, 必须关 */

#endif /* FREERTOS_CONFIG_H */
