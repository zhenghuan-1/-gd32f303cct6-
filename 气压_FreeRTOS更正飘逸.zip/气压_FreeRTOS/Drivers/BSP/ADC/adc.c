/************************************************
 * WKS Nano GD32 开发板
 * ADC 驱动（ADC0 + 内部温度传感器）
 * 版本：V1.1
 * 编码：UTF-8（注释补全版，代码逻辑未改动）
 ************************************************/

#include "adc.h"
#include "delay.h"

/*
 * 函数: Adc_Init
 * 功能: 初始化 ADC0（PA1 模拟输入通道）
 * 说明: 配置为单次转换、软件触发、数据右对齐，并执行校准；
 *       ADC 时钟 = APB2 / 6 = 120MHz / 6 = 20MHz（在 ADC 规格范围内）
*/
void  Adc_Init(void)
{    
  rcu_periph_clock_enable(RCU_GPIOA);                             //使能GPIOA时钟
  gpio_init(GPIOA, GPIO_MODE_AIN, GPIO_OSPEED_50MHZ, GPIO_PIN_1); //AD采集引脚(PA1)模式设置,模拟输入
	 
	rcu_periph_clock_enable(RCU_ADC0);   //使能ADC0时钟
	 
	adc_deinit(ADC0);   //复位ADC0
	
	//ADC时钟挂在APB2,频率为120Mhz
	//使用6分频,得到APB2/6 = 20Mhz的ADC时钟
  rcu_adc_clock_config(RCU_CKADC_CKAPB2_DIV6);   //设置ADC时钟
	
  adc_mode_config(ADC_MODE_FREE);   //ADC独立工作模式              
	
	adc_special_function_config(ADC0, ADC_SCAN_MODE, DISABLE);        //禁用扫描模式	
  adc_special_function_config(ADC0, ADC_CONTINUOUS_MODE, DISABLE);  //禁止连续模式 
	
	adc_data_alignment_config(ADC0, ADC_DATAALIGN_RIGHT);             //数据右对齐
	
	adc_external_trigger_config(ADC0, ADC_REGULAR_CHANNEL, ENABLE);                               //规则通道使能外部触发
  adc_external_trigger_source_config(ADC0, ADC_REGULAR_CHANNEL, ADC0_1_2_EXTTRIG_REGULAR_NONE); //规则通道无外部触发源(走软件触发)
	
	adc_channel_length_config(ADC0, ADC_REGULAR_CHANNEL, 1);   //规则通道序列长度:1个转换(每次只转1个通道) 

  adc_enable(ADC0);   //使能ADC0

  adc_calibration_enable(ADC0);   //使能ADC0校准位
	
}

/*
 * 函数: Get_Adc
 * 功能: 读取指定通道的 ADC 转换结果
 * 参数: ch —— 通道号（0~17，含内部温度/参考电压通道）
 * 返回: 该通道的一次 12 位转换结果
 * 说明: 配置规则通道 → 软件触发 → 等待 EOC 标志 → 读数据寄存器
 */
uint16_t Get_Adc(uint8_t ch)   
{
	  uint16_t adc_value = 0; 
	
	  adc_regular_channel_config(ADC0, 0, ch, ADC_SAMPLETIME_239POINT5);//配置ADC规则通道,选择采样时间为239.5周期,提高采样时间以获取更高精确度
	
    adc_software_trigger_enable(ADC0, ADC_REGULAR_CHANNEL);   //软件触发使能,启动一次转换开始
	
	  while(SET != adc_flag_get(ADC0,ADC_FLAG_EOC));   //等待转换结束（EOC = End Of Conversion）
	   
	  adc_value = adc_regular_data_read(ADC0);         //读ADC规则数据寄存器
	
    return  adc_value;   //返回该次ADC0的转换结果
}

/*
 * 函数: Get_Adc_Average
 * 功能: 读取通道 ch 的转换值共 times 次，然后取平均
 * 参数: ch    —— 通道号
 *       times —— 采样次数
 * 返回: 通道 ch 的 times 次转换结果的平均值
 * 说明: 对噪声较大的模拟量（如温度传感器）用多次采样平均抑制抖动
*/	 
uint16_t Get_Adc_Average(uint8_t ch,uint8_t times)
{
	uint32_t temp_val=0;
	uint8_t t;
	for(t=0;t<times;t++)
	{
		temp_val+=Get_Adc(ch);  //累加times次采样值 
	}
	return temp_val/times;    //返回平均值
} 
	 
/*
 * 函数: adc_temperature_init
 * 功能: ADC 内部温度传感器初始化
 * 说明: GD32 内部温度传感器只能接到 ADC0 的通道16, 其它ADC无法对其转换.
 *       额外使能 Vrefint（内部参考电压）通道，用于计算实际 VDDA。
 */
void adc_temperature_init(void)
{
    Adc_Init();                        //先初始化ADC 	
		adc_tempsensor_vrefint_enable();   //TSVREN = 1,使能内部温度传感器与Vrefint通道
}


/*
 * 函数: Get_Temprate
 * 功能: 读取内部温度传感器的温度值
 * 返回: 温度值（放大100倍, 单位: 0.01℃）
 * 说明: 
 *   1) 先采样 Vrefint 通道（20次平均），用 1.2V 基准反推实际 VDDA；
 *   2) 再采样温度传感器通道（100次平均），按数据手册线性公式换算温度；
 *   3) 最后过一阶卡尔曼滤波，抑制 ADC 抖动，输出 0.01℃ 定点整数。
 */
short Get_Temprate(void)
{
    uint32_t adcx, adc_vref;
    short result;
    double temperate;
    float vdda;

    adc_vref = Get_Adc_Average(ADC_CHX_VREFINT, 20);
    vdda = 4915.2f / (float)adc_vref;                     /* 1.2*4096 预计算: VDDA = 1.2V × 4096 / Vref采样值 */

    adcx = Get_Adc_Average(ADC_CHX_TEMPSENSOR, 100);
    /* T = 378.659 - V * 243.902,  V = adcx * vdda / 4096
     * 合并常数后: temperate = 378.659 - adcx × vdda × 0.0595465
     * （0.0595465 = 243.902 / 4096，数据手册给出的线性标定） */
    temperate = 378.659f - (float)adcx * vdda * 0.0595465f;

    result = (short)(temperate * 100.0f);

    /* 1阶卡尔曼滤波: 状态=温度(×100), 强滤波抑制噪声
     * 温度变化极慢(过程噪声Q很小), 而ADC单次抖动大(测量噪声R很大),
     * 因此滤波结果对单次测量强烈不信任, 输出非常平滑。 */
    {
        static float x = 0.0f;       /* 状态估计 */
        static float p = 100.0f;     /* 误差协方差, 初始大→快速收敛 */
        static uint8_t kf_init = 0;
        const float Q = 0.02f;       /* 过程噪声——温度变化极慢 */
        const float R = 5000.0f;     /* 测量噪声——ADC抖动大, 强烈不信任 */

        if (!kf_init) {
            x = (float)result;       /* 首次直接初始化 */
            kf_init = 1;
        } else {
            /* 预测: x不变, p增长 */
            p += Q;

            /* 更新 */
            float k = p / (p + R);   /* 卡尔曼增益 */
            x += k * ((float)result - x);
            p = (1.0f - k) * p;
        }
        result = (short)x;
    }

    return result;
}


