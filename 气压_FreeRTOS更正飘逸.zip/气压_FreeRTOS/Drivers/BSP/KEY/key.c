/*********************************************
 * WKS Nano GD32 开发板
 * 按键驱动（KEY0 / WK_UP）
 * 版本：V1.1
 * 编码：UTF-8（注释补全版，代码逻辑未改动）
*********************************************/

#include "key.h"
#include "delay.h"

/*
 * 函数: KEY_Init
 * 功能: 按键 GPIO 初始化
 * 说明: PA13 配为上拉输入（KEY0，按下为低电平）；
 *       PA0（WK_UP，按下为高电平）的初始化代码已注释掉，
 *       当前固件实际只使用 KEY0 一个按键。
*/
void KEY_Init(void)
{
	  rcu_periph_clock_enable(RCU_GPIOA);  //GPIOA时钟使能
	  //gpio_init(GPIOA, GPIO_MODE_IPD, GPIO_OSPEED_50MHZ, GPIO_PIN_0);    //配置PA0为下拉输入(预留 WK_UP)
		gpio_init(GPIOA, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, GPIO_PIN_13);   //配置PA13为上拉输入(KEY0)
}

/*
 * 函数: KEY_Scan
 * 功能: 按键扫描函数
 * 参数: mode —— 0:单次触发(仅按下瞬间返回一次);
 *                1:连按模式(每轮扫描都返回)
 * 返回: keyval —— 0:无按键; KEY0_PRES:KEY0按下; WKUP_PRES:WK_UP按下
 * 说明: 带 10ms 软件消抖；KEY0 按下为低(KEY0==0)，WK_UP 按下为高(WK_UP==1)
*/
uint8_t KEY_Scan(uint8_t mode)
{
	static uint8_t key_up = 1;  //按键松开标志(1=松开, 0=按下)
    uint8_t keyval = 0;

    if (mode) key_up = 1;       //支持连按:每次扫描都当"已松开"
    if (key_up && (KEY0 == 0 || WK_UP == 1))  //按键松开标志为1, 且检测到有按键按下
    {
        delay_ms(10);           //去抖动
        key_up = 0;

        if (KEY0 == 0)  keyval = KEY0_PRES;
        if (WK_UP == 1) keyval = WKUP_PRES;
    }
    else if (KEY0 == 1  && WK_UP == 0) //没有任何按键按下, 则标记当前按键已松开
    {
        key_up = 1;
    }

    return keyval;              //返回键值
}

