/************************************************
 * WKS Nano GD32 开发板
 * OLED 驱动头文件（SSD1306, 128×64）
 * 版本：V1.1
 * 编码：UTF-8（注释补全版，代码逻辑未改动）
 ************************************************/

#ifndef __OLED_H
#define __OLED_H
#include "sys.h"

//OLED模式选择(条件编译)
//0: 4线SPI模式 （模块的BS1=0）
//1: IIC模式    （模块的BS1=1）
#define OLED_MODE 	1
		    						  
//-----------------OLED端口定义----------------
#define OLED_CS(x)      do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_6, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_6, RESET); \
                        }while(0)      
#define OLED_DC(x)      do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_7, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_7, RESET); \
                        }while(0) 
#define OLED_BS1(x)      do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_5, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_5, RESET); \
                        }while(0) 
#define OLED_RST(x)     do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_0, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_0, RESET); \
                        }while(0) 	
 
//使用4线SPI接口时使用 
#define OLED_SCLK(x)    do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_13, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_13, RESET); \
                        }while(0) 
#define OLED_SDIN(x)    do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_15, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_15, RESET); \
                        }while(0) 

#define OLED_CMD  	0		//写命令
#define OLED_DATA 	1		//写数据

//OLED控制函数
void OLED_WR_Byte(uint8_t dat,uint8_t cmd);	    
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Refresh_Gram(void);		   

void OLED_Init(void);
void OLED_Clear(void);
void OLED_DrawPoint(uint8_t x,uint8_t y,uint8_t t);
void OLED_Fill(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2,uint8_t dot);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t size,uint8_t mode);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size);
void OLED_ShowString(uint8_t x,uint8_t y,const uint8_t *p,uint8_t size);
							   		    
//中文显示函数
int OLED_FindChineseIndex(const char *chinese);
void OLED_ShowChinese(uint8_t x,uint8_t y,const char *chinese);
void OLED_ShowChineseString(uint8_t x,uint8_t y,const char *str);
void OLED_ShowMixString(uint8_t x,uint8_t y,const char *str);

#endif
