/************************************************
 * WKS Nano GD32 开发板
 * OLED 驱动（SSD1306, 128×64, I2C/SPI 双模式）
 * 版本：V1.1
 * 编码：UTF-8（注释补全版，代码逻辑未改动）
 ************************************************/

#include "oled.h"
#include "stdlib.h"
#include "delay.h"
#include "oledfont.h"
#include "myiic.h"
#include "string.h"


//OLED显存数组
//存储格式: 纵向8页, 每页128列
//[0]0 1 2 3 ... 127	
//[1]0 1 2 3 ... 127	
//[2]0 1 2 3 ... 127	
//[3]0 1 2 3 ... 127	
//[4]0 1 2 3 ... 127	
//[5]0 1 2 3 ... 127	
//[6]0 1 2 3 ... 127	
//[7]0 1 2 3 ... 127 		   
uint8_t OLED_GRAM[128][8];	 

//将显存刷新到OLED屏
//按页(0~7)循环: 每页先设页地址, 再连续送出128列数据
void OLED_Refresh_Gram(void)
{
		uint8_t i,n;		    
		for(i=0;i<8;i++)  
		{  
				OLED_WR_Byte (0xb0+i,OLED_CMD);    //设置页地址(0~7)
				OLED_WR_Byte (0x00,OLED_CMD);      //设置显示位置-列的低地址
				OLED_WR_Byte (0x10,OLED_CMD);      //设置显示位置-列的高地址  
#if OLED_MODE==1	
        IIC_Start();
			  IIC_Send_Byte(0X78);
			  IIC_Wait_Ack();
			  IIC_Send_Byte(0x40);
				IIC_Wait_Ack();
			  for(n=0;n<128;n++)
			  {         	
						IIC_Send_Byte(OLED_GRAM[n][i]);	
						IIC_Wait_Ack();
			  }
			  IIC_Stop();
#else 
				for(n=0;n<128;n++)OLED_WR_Byte(OLED_GRAM[n][i],OLED_DATA); 
#endif
		}		   
}

#if OLED_MODE==1	  //IIC模式
 
//向OLED写入一个字节。
//dat:要写入的数据/命令
//cmd:命令/数据标志 0,表示命令;1,表示数据;
//IIC 时序: 起始 → 从机地址0x78 → 控制字节(0x00命令/0x40数据) → 数据 → 停止
void OLED_WR_Byte(uint8_t dat,uint8_t cmd)
{
	    IIC_Start();             //产生起始信号
	    IIC_Send_Byte(0X78);     //发送从机地址
	    IIC_Wait_Ack();          //每次发送完一个字节,需要等待ACK
	    if(cmd == OLED_CMD)
	    IIC_Send_Byte(0x00);     //若是写命令时的控制字节
			else
			IIC_Send_Byte(0x40);     //若是写数据时的控制字节
			IIC_Wait_Ack();          //每次发送完一个字节,需要等待ACK
			IIC_Send_Byte(dat);	     //发送数据字节
			IIC_Wait_Ack();          //等待ACK 
			IIC_Stop();              //产生一个停止信号
} 	   

#else               //4线SPI模式
//向OLED写入一个字节。
//dat:要写入的数据/命令
//cmd:命令/数据标志 0,表示命令;1,表示数据;
void OLED_WR_Byte(uint8_t dat,uint8_t cmd)
{	
		uint8_t i;			  
		OLED_DC(cmd);     //写命令/数据选择 
		OLED_CS(0);		  
  SPI1_ReadWriteByte(dat);
//  	while(RESET == spi_i2s_flag_get(SPI1, SPI_FLAG_TBE));    //等待发送缓冲区空
//	
//	  spi_i2s_data_transmit(SPI1, dat);                     //发送一个字节
//    while(RESET == spi_i2s_flag_get(SPI1, SPI_FLAG_RBNE));   //等待接收缓冲区非空

//	  (void*)spi_i2s_data_receive(SPI1);                       //读出接收的数据
//		for(i=0;i<8;i++)
//		{			  
//				OLED_SCLK(0);
//				if(dat&0x80)OLED_SDIN(1);
//				else OLED_SDIN(0);
//				OLED_SCLK(1);      //把SCLK拉高,数据从SDIN写入
//				dat<<=1;   
//		}				 
		OLED_CS(1);		  
		OLED_DC(1);   	  
} 
#endif
	  	  

	  

//清屏函数: 清屏,清屏,整屏是黑色!没写反!!!	  
//只清显存(OLED_GRAM), 不刷新屏幕; 实际刷屏由调用方负责
void OLED_Clear(void)  
{  
		uint8_t i,n;  
		for(i=0;i<8;i++)for(n=0;n<128;n++)OLED_GRAM[n][i]=0X00;  
		/* OLED_Refresh_Gram() removed - caller handles refresh */  //刷新显示
}

//画点
//x:0~127
//y:0~63
//t:1 填充   0,清除				   
void OLED_DrawPoint(uint8_t x,uint8_t y,uint8_t t)
{
		uint8_t pos,bx,temp=0;
		if(x>127||y>63)return;//超出范围则返回.
		pos=7-y/8;
		bx=y%8;
		temp=1<<(7-bx);
		if(t)OLED_GRAM[x][pos]|=temp;
		else OLED_GRAM[x][pos]&=~temp;	    
}

//x1,y1,x2,y2 填充区域的对角线坐标
//确保x1<=x2;y1<=y2 0<=x1<=127 0<=y1<=63	 

//在指定位置显示一个字符,包括部分字符
//x:0~127
//y:0~63
//mode:0,反色显示;1,正常显示				 
//size:选择字体 12/16/24
//chr 为字符的 ASCII 码, 内部自动减去 0x20(空格)作为字库偏移
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t size,uint8_t mode)
{      			    
		uint8_t temp,t,t1;
		uint8_t y0=y;
		uint8_t csize=(size/8+((size%8)?1:0))*(size/2);		//得到字体一个字符对应点阵集所占字节数
		chr=chr-' ';                                //得到偏移后的值		 
		for(t=0;t<csize;t++)
		{   
				if(size==12)temp=asc2_1206[chr][t]; 	 	  //调用1206字体
				else if(size==16)temp=asc2_1608[chr][t];	//调用1608字体
				
				for(t1=0;t1<8;t1++)
				{
						if(temp&0x80)OLED_DrawPoint(x,y,mode);
						else OLED_DrawPoint(x,y,!mode);
						temp<<=1;
						y++;
						if((y-y0)==size)
						{
								y=y0;
								x++;
								break;
						}
				}  	 
		}          
}

//m^n 幂运算
uint32_t mypow(uint8_t m,uint8_t n)
{
	uint32_t result=1;	 
	while(n--)result*=m;    
	return result;
}		

//显示len个数字
//x,y :起点坐标	 
//len :显示数字的位数
//size:字体大小
//num:数值(0~2^32);	  
//高位为0的位用空格占位(不显示前导0)
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size)
{         	
		uint8_t t,temp;
		uint8_t enshow=0;						   
		for(t=0;t<len;t++)      //按显示位数循环           
		{
			temp=(num/mypow(10,len-t-1))%10;   //获取对应位的数字
			if(enshow==0&&t<(len-1))           //没有使能显示,且还有高位要显示
			{
				if(temp==0)
				{
					OLED_ShowChar(x+(size/2)*t,y,' ',size,1);  //显示空格,占位 
					continue;       //继续下一位
				}else enshow=1;   //使能显示
				 
			}
			OLED_ShowChar(x+(size/2)*t,y,temp+'0',size,1); //显示字符 
		}
} 

//显示字符串
//x,y:起点坐标  
//size:字体大小 
//*p:字符串起始地址 
//自动换行: 列超出右边界则换行, 行超出下边界则清屏重来
void OLED_ShowString(uint8_t x,uint8_t y,const uint8_t *p,uint8_t size)
{	
    while((*p<='~')&&(*p>=' '))  //判断是不是非法字符(仅显示可打印ASCII)!
    {       
        if(x>(128-(size/2)))     //列越界
         {
					x=0;
				  y+=size;               //换行
				 }
        if(y>(64-size))          //高度越界
				 {
				  y=x=0;
				  OLED_Clear();
				 }
        OLED_ShowChar(x,y,*p,size,1);	  //显示一个字符 
        x+=size/2;                      //ASCII字符宽度为汉字宽度的一半
        p++;
    }  

}	

//查找汉字在字库中的索引
//chinese:要查找的汉字

//初始化OLED(SSD1306)
//1) GPIO 时钟/引脚初始化, 按 OLED_MODE 选择 IIC 或 4线SPI 接口;
//2) 硬件复位(拉低RST 100ms 再拉高);
//3) 写 SSD1306 初始化命令序列(显示关闭→时钟/分频→多路→偏移→起始行→电荷泵→
//   寻址模式→段重映射→COM扫描→硬件配置→对比度→预充电→VCOMH→正常显示→开显示);
//4) 清屏。
void OLED_Init(void)
{ 	 		 
    rcu_periph_clock_enable(RCU_GPIOB);  //GPIOB时钟使能
		rcu_periph_clock_enable(RCU_GPIOC);  //GPIOC时钟使能
	  rcu_periph_clock_enable(RCU_AF);     //使能复用时钟
	
#if OLED_MODE==1		//使用IIC模式		
	
		//配置PB0,5,7为推挽输出
		gpio_init(GPIOB, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,GPIO_PIN_0|GPIO_PIN_5|GPIO_PIN_7); 
	
		IIC_Init();   //IIC接口初始化
		OLED_BS1(1);  //BS1=1选择IIC通信方式
		OLED_DC(0);   //DC为0时,IIC从机地址为0x78;DC为1时,IIC从机地址为0x7a;

#else					      //使用4线SPI模式
    SPI1_Init();
		//配置PB0为推挽输出  
//    gpio_init(GPIOB, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, GPIO_PIN_0); 		 
	
		//配置PB0,5,6,7为推挽输出
		gpio_init(GPIOB, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ,GPIO_PIN_0|GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7);
	
	  OLED_BS1(0);   //BS1=0选择4线SPI通信方式
		OLED_CS(1);
		OLED_DC(1);	 
		OLED_SDIN(1);
		OLED_SCLK(1);
		
#endif
			
		//OLED硬件复位	
		OLED_RST(0);
		delay_ms(100);
		OLED_RST(1); 
					  
		OLED_WR_Byte(0xAE,OLED_CMD); //关闭显示
		OLED_WR_Byte(0xD5,OLED_CMD); //设置时钟分频因子,振荡频率
		OLED_WR_Byte(80,OLED_CMD);   //[3:0],分频因子;[7:4],振荡频率
		OLED_WR_Byte(0xA8,OLED_CMD); //设置驱动路数
		OLED_WR_Byte(0X3F,OLED_CMD); //默认0X3F(1/64) 
		OLED_WR_Byte(0xD3,OLED_CMD); //设置显示偏移
		OLED_WR_Byte(0X00,OLED_CMD); //默认为0
		OLED_WR_Byte(0x40,OLED_CMD); //设置显示开始行 [5:0],行数.										    
		OLED_WR_Byte(0x8D,OLED_CMD); //电荷泵设置
		OLED_WR_Byte(0x14,OLED_CMD); //bit2,开启/关闭
		OLED_WR_Byte(0x20,OLED_CMD); //设置内存地址模式
		OLED_WR_Byte(0x02,OLED_CMD); //[1:0],00,列地址模式;01,行地址模式;10,页地址模式;默认10;
		OLED_WR_Byte(0xA1,OLED_CMD); //段重映射设置,bit0:0,0->0;1,0->127;
		OLED_WR_Byte(0xC0,OLED_CMD); //设置COM扫描方向;bit3:0,普通模式;1,重定义模式 COM[N-1]->COM0;N:驱动路数
		OLED_WR_Byte(0xDA,OLED_CMD); //设置COM硬件引脚配置
		OLED_WR_Byte(0x12,OLED_CMD); //[5:4]配置	 
		OLED_WR_Byte(0x81,OLED_CMD); //对比度设置
		OLED_WR_Byte(0xEF,OLED_CMD); //1~255;默认0X7F (亮度设置,越大越亮)
		OLED_WR_Byte(0xD9,OLED_CMD); //设置预充电周期
		OLED_WR_Byte(0xf1,OLED_CMD); //[3:0],PHASE 1;[7:4],PHASE 2;
		OLED_WR_Byte(0xDB,OLED_CMD); //设置VCOMH 电压倍率
		OLED_WR_Byte(0x30,OLED_CMD); //[6:4] 000,0.65*vcc;001,0.77*vcc;011,0.83*vcc;
		OLED_WR_Byte(0xA4,OLED_CMD); //全局显示开启;bit0:1,开启;0,关闭;(白屏/黑屏)
		OLED_WR_Byte(0xA6,OLED_CMD); //设置显示方式;bit0:1,反相显示;0,正常显示	    						   
		OLED_WR_Byte(0xAF,OLED_CMD); //开启显示	 
		OLED_Clear();                //清屏
}                            
