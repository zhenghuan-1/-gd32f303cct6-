/* ====================================================================================
 * 文件: pressure_calc.c
 * 描述: 气压计算模块 - 6点滑动窗口 + 2D多项式标定
 * ====================================================================================
 *
 * 传感器: 24505322#
 * 公式:   P = Σ k[i][j] * x^j * y^i
 * 其中:   x = (f1/1000 - 65000) / 3800
 *         y = (f2/1000 - 59000) / 3700
 *
 * 优化: 先对6个样本的频率取均值, 再算一次多项式, 精度无损, 计算量降为1/6
 *       频率滤波由 main.c 中值窗口统一处理, 此处仅做均值平均
 * ==================================================================================== */

#include "pressure_calc.h"
#include <math.h>
#include <string.h>

/* 函数前向声明 */
static void set_ps_params_from_float(const float params[25]);
static void set_pt_params_from_float(const float params[25]);
static void set_ts_params_from_float(const float params[25]);

/* ====================================================================================
 * 默认标定参数 (三组: PS/TS/PT)
 *
 * 参数布局 (25个double):
 *   [0] = Δf1, [1] = f1_scale, [2] = Δf2, [3] = f2_scale
 *   [4-24] = 21个k[i][j]多项式系数 (下三角展开)
 *
 * TPC参数顺序:
 *   Δf1,f1_scale,Δf2,f2_scale,k14,k05,k04,k03,k13,k23,
 *   k02,k12,k22,k32,k01,k11,k21,k31,k41,k00,k10,k20,k30,k40,k50
 * ==================================================================================== */

/* PS默认参数 (Δf1=65000, f1_scale=3800, Δf2=59000, f2_scale=3700) */
static const float s_default_ps_params[25] = {
    65000.0f, 3800.0f, 59000.0f, 3700.0f,
    23392.128518f, 4781.604294f, 894.836195f, -80.166787f, 3521.446816f, 45853.375261f,
    -31.061953f, -225.548104f, 5228.960876f, 45020.691682f,
    -538.863937f, -11.107721f, -210.360991f, 3472.179803f, 22136.615546f,
    661.933891f, 628.383544f, 19.318891f, -65.337509f, 869.761164f, 4363.371597f
};

/* TS默认参数 (Δf1=67000, f1_scale=3400, Δf2=57000, f2_scale=3500) */
static const float s_default_ts_params[25] = {
    67000.0f, 3400.0f, 57000.0f, 3500.0f,
    -51540.666802f, -10639.306226f, -8574.159444f, -1192.055229f, -33349.524963f, -100950.282909f,
    62.531171f, -3451.915184f, -49029.201003f, -99943.395118f,
    -198.060965f, 134.729419f, -3351.636471f, -32289.226921f, -50012.792114f,
    17.709475f, -194.948391f, 64.674796f, -1090.735473f, -8038.003013f, -10118.257036f
};

/* PT默认参数 (Δf1=69000, f1_scale=3500, Δf2=55000, f2_scale=3900) */
static const float s_default_pt_params[25] = {
    69000.0f, 3500.0f, 55000.0f, 3900.0f,
    27012.526537f, 5530.603019f, 1652.604618f, 23.328971f, 6446.174426f, 52894.765013f,
    -34.398654f, 67.879673f, 9479.932671f, 51909.653386f,
    -512.135010f, -15.992962f, 67.368365f, 6230.225024f, 25533.491431f,
    1904.967029f, 628.062869f, 13.823200f, 23.709267f, 1544.080372f, 5036.415497f
};

/* ====================================================================================
 * Flash标定参数 (PS/PT双区间)
 *
 * PS: 用于 ≤1200hPa 的气压计算
 * PT: 用于 >1200hPa 时重新计算
 *
 * 参数布局 (25个double):
 *   [0] = Δf1, [1] = f1_scale, [2] = Δf2, [3] = f2_scale
 *   [4-24] = 21个k[i][j]多项式系数 (下三角展开)
 *
 * TPC指令参数顺序:
 *   Δf1,f1_scale,Δf2,f2_scale,k14,k05,k04,k03,k13,k23,
 *   k02,k12,k22,k32,k01,k11,k21,k31,k41,k00,k10,k20,k30,k40,k50
 * ==================================================================================== */

/* PS参数 (≤1200hPa) */
static float    s_ps_delta_f1   = DELTA_PS1;  // PS 区归一化偏移 Δf1：默认 = DELTA_PS1 = 65000.0f（频率居中用）
static float    s_ps_f1_scale   = PS1;  // PS 区归一化缩放 f1_scale：默认 = PS1 = 3800.0f
static float    s_ps_delta_f2   = DELTA_PS2;  // PS 区归一化偏移 Δf2：默认 = DELTA_PS2 = 59000.0f
static float    s_ps_f2_scale   = PS2;  // PS 区归一化缩放 f2_scale：默认 = PS2 = 3700.0f
static float    s_ps_k[6][6];  // PS 区 6×6 多项式系数矩阵（只填下三角 i+j≤5，共 21 个有效系数）
static uint8_t  s_ps_loaded     = 0;  // 1=PS 系数已就绪（默认参数或 Flash 参数加载过）

/* PT参数 (>1200hPa) */
static float    s_pt_delta_f1   = DELTA_PS1;  // PT 区 Δf1：默认同 PS = 65000.0f
static float    s_pt_f1_scale   = PS1;  // PT 区 f1_scale：默认 = 3800.0f
static float    s_pt_delta_f2   = DELTA_PS2;  // PT 区 Δf2：默认 = 59000.0f
static float    s_pt_f2_scale   = PS2;  // PT 区 f2_scale：默认 = 3700.0f
static float    s_pt_k[6][6];  // PT 区 6×6 系数矩阵
static uint8_t  s_pt_loaded     = 0;  // 1=PT 系数已就绪；注意：仅 Flash 加载路径会置位，默认参数初始化不置位

/* TS参数 (温度计算) */
static float    s_ts_delta_f1   = 67000.0f;  // TS 区 Δf1：默认 67000.0f（温度标定用，与 PS/PT 不同）
static float    s_ts_f1_scale   = 3400.0f;  // TS 区 f1_scale：默认 3400.0f
static float    s_ts_delta_f2   = 57000.0f;  // TS 区 Δf2：默认 57000.0f
static float    s_ts_f2_scale   = 3500.0f;  // TS 区 f2_scale：默认 3500.0f
static float    s_ts_k[6][6];  // TS 区 6×6 系数矩阵
static uint8_t  s_ts_loaded     = 0;  // 1=TS 系数已就绪

/* Flash参数是否已加载 */
static uint8_t  s_flash_params_loaded = 0;

/* ====================================================================================
 * TPC参数索引到k[i][j]的映射表
 *
 * TPC参数顺序: k14,k05,k04,k03,k13,k23,k02,k12,k22,k32,k01,k11,k21,k31,k41,k00,k10,k20,k30,k40,k50
 * 索引4~24对应k[i][j]:
 *   [4] =k[1][4], [5] =k[0][5], [6] =k[0][4], [7] =k[0][3]
 *   [8] =k[1][3], [9] =k[2][3], [10]=k[0][2], [11]=k[1][2]
 *   [12]=k[2][2], [13]=k[3][2], [14]=k[0][1], [15]=k[1][1]
 *   [16]=k[2][1], [17]=k[3][1], [18]=k[4][1], [19]=k[0][0]
 *   [20]=k[1][0], [21]=k[2][0], [22]=k[3][0], [23]=k[4][0]
 *   [24]=k[5][0]
 * ==================================================================================== */
static void parse_params_to_k(const float params[25], float k_out[6][6])
{
    memset(k_out, 0, sizeof(float) * 36);  // 36 = 6×6，先把整个系数矩阵清零（下三角之外的位置保持 0）

    /* k_out[i][j] = y^i * x^j 的系数
     * i=行=y的幂次, j=列=x的幂次
     * 与 Python pressure_calc.py 的 K[i][j] 布局一致
     *
     * 注意: 该赋值顺序与上方 TPC 文档表不一致, 但它是默认系数实际标定的顺序,
     * 在实测频率 (f1≈65920, f2≈57713) 下能得到正确气压 ≈1000hPa, 勿按文档改动 */
    k_out[0][0] = params[19];   /* k00 */
    k_out[0][1] = params[20];   /* k01 */
    k_out[0][2] = params[21];   /* k02 */
    k_out[0][3] = params[22];   /* k03 */
    k_out[0][4] = params[23];   /* k04 */
    k_out[0][5] = params[24];   /* k05 */
    k_out[1][0] = params[14];   /* k10 */
    k_out[1][1] = params[15];   /* k11 */
    k_out[1][2] = params[16];   /* k12 */
    k_out[1][3] = params[17];   /* k13 */
    k_out[1][4] = params[18];   /* k14 */
    k_out[2][0] = params[10];   /* k20 */
    k_out[2][1] = params[11];   /* k21 */
    k_out[2][2] = params[12];   /* k22 */
    k_out[2][3] = params[13];   /* k23 */
    k_out[3][0] = params[7];    /* k30 */
    k_out[3][1] = params[8];    /* k31 */
    k_out[3][2] = params[9];    /* k32 */
    k_out[4][0] = params[6];    /* k40 */
    k_out[4][1] = params[4];    /* k41 */
    k_out[5][0] = params[5];    /* k50 */
}

/* ====================================================================================
 * 滑动窗口
 * ==================================================================================== */
static uint32_t s_ch1_buf[PRESSURE_WINDOW_SIZE];  // CH1 频率(×1000)环形缓冲，长度 = PRESSURE_WINDOW_SIZE = 6
static uint32_t s_ch2_buf[PRESSURE_WINDOW_SIZE];  // CH2 频率(×1000)环形缓冲，与 CH1 同槽对齐
static uint8_t  s_count     = 0;  // 当前窗口内有效样本数 0~6（未满 6 即开始累计）
static uint8_t  s_write_idx = 0;  // 下一个写入槽位的环形索引 0~5

/* ====================================================================================
 * 公共函数实现
 * ==================================================================================== */

void pressure_calc_init(void)
{
    uint8_t i;
    for (i = 0; i < PRESSURE_WINDOW_SIZE; i++)  // 遍历 6 个样本槽
    {
        s_ch1_buf[i] = 0;  // CH1 槽清零
        s_ch2_buf[i] = 0;  // CH2 槽清零
    }
    s_count     = 0;  // 有效样本数归零
    s_write_idx = 0;  // 写指针回到槽 0

    /* 使用默认参数初始化 */
    set_ps_params_from_float(s_default_ps_params);  // 先用硬编码默认 PS 系数填充（≤1200hPa 气压段）
    set_pt_params_from_float(s_default_pt_params);  // 默认 PT 系数（>1200hPa 气压段）
    set_ts_params_from_float(s_default_ts_params);  // 默认 TS 系数（温度换算）
}

void pressure_calc_push(uint32_t ch1_freq_x1000, uint32_t ch2_freq_x1000)
{
    s_ch1_buf[s_write_idx] = ch1_freq_x1000;  // 新一组 CH1 频率(×1000)写入当前槽
    s_ch2_buf[s_write_idx] = ch2_freq_x1000;  // 同槽写入 CH2 频率(×1000)，两路保持对齐

    s_write_idx++;  // 写指针后移一格
    if (s_write_idx >= PRESSURE_WINDOW_SIZE)  // 写到第 6 个槽（越界）即触发回绕
        s_write_idx = 0;  // 环形缓冲回绕到槽 0，覆盖最旧样本

    if (s_count < PRESSURE_WINDOW_SIZE)  // 样本数未满 6 时继续累加计数
        s_count++;  // 满 6 后保持 6 不变（滑动窗口永远只统计最近 6 个）
}

/* 内部多项式计算: 使用指定的参数计算气压 */
static float calc_polynomial(const float k[6][6], float delta_f1, float f1_scale,
                              float delta_f2, float f2_scale)
{
    float result = 0.0f;  // 多项式累加和，初值 0
    uint8_t i, j;
    uint64_t sum1 = 0, sum2 = 0;  // 两路频率求和（6 个 uint32 累加，用 64 位防止中间溢出）

    for (i = 0; i < s_count; i++)  // 把窗口内所有 s_count 个样本的频率累加
    {
        sum1 += s_ch1_buf[i];  // CH1 累加
        sum2 += s_ch2_buf[i];  // CH2 累加
    }

    float f1 = (float)(sum1 / s_count) / 1000.0f;  // 先整数平均 sum1/s_count，再 ÷1000 还原成 Hz：f1 = CH1 窗口频率均值
    float f2 = (float)(sum2 / s_count) / 1000.0f;  // f2 = CH2 窗口频率均值（Hz）
    float x  = (f1 - delta_f1) / f1_scale;  // 归一化 x=(f1-Δf1)/f1_scale：把频率居中并缩放成无量纲量
    float y  = (f2 - delta_f2) / f2_scale;  // 归一化 y=(f2-Δf2)/f2_scale

    /* 输入限幅: x,y超出[-3,3]说明窗口有异常值 */
    if (x > 3.0f || x < -3.0f || y > 3.0f || y < -3.0f)
        return -9999.0f;  /* 异常标记 */

    /* 预计算 x 和 y 的各次幂 */
    float xp[6], yp[6];  // 预存 x、y 的 0~5 次幂，避免内层循环重复做乘方
    xp[0] = 1.0f;  yp[0] = 1.0f;  // x^0 = y^0 = 1
    for (i = 1; i < 6; i++)  // 递推算 x^i、y^i（i=1..5）
    {
        xp[i] = xp[i - 1] * x;  // xp[i] = x^(i-1)·x = x^i
        yp[i] = yp[i - 1] * y;  // yp[i] = y^(i-1)·y = y^i
    }

    /* 多项式累加: result += k[i][j] * x^j * y^i */
    for (i = 0; i < 6; i++)  // 遍历 y 的幂次 i = 0..5
    {
        for (j = 0; j < 6 - i; j++)  // x 的幂次 j = 0..5-i（下三角 i+j≤5，共 6+5+4+3+2+1 = 21 项）
        {
            result += k[i][j] * xp[j] * yp[i];  // 累加一项 k[i][j]·x^j·y^i
        }
    }

    return result;  // 返回多项式结果（气压 hPa 或温度，取决于传入的是哪组系数）
}

float pressure_calc_get(void)
{
    float result;
    static float s_last_valid = 0.0f;  /* 上一次有效气压值 */

    if (s_count == 0)  // 还没有任何样本，无气压可算
        return 0.0f;  // 返回 0 表示无效

    /* PS/PT双区间逻辑:
     * 1. 先用PS系数计算
     * 2. 如果结果>1200，改用PT系数重新计算
     */
    result = calc_polynomial(s_ps_k, s_ps_delta_f1, s_ps_f1_scale,  // 第一步：用 PS 系数（≤1200hPa 段）算一次气压
                             s_ps_delta_f2, s_ps_f2_scale);

    /* 异常检查 */
    if (result < -9000.0f)  // calc_polynomial 的异常标记是 -9999，这里判 <-9000 即视为异常
        return (s_last_valid > 0.0f) ? s_last_valid : 0.0f;  // 异常时保持上一次有效气压，避免输出跳变；从未有效过则返回 0

    /* 如果PS结果>1200且PT参数已加载，改用PT重新计算 */
    if (result > 1200.0f && s_pt_loaded)  // PS 结果超过 1200hPa 且 PT 系数已加载 → 切到高压段重算
    {
        result = calc_polynomial(s_pt_k, s_pt_delta_f1, s_pt_f1_scale,  // 用 PT 系数重算高压段气压
                                 s_pt_delta_f2, s_pt_f2_scale);
        if (result < -9000.0f)  // PT 结果同样做异常保护
            return (s_last_valid > 0.0f) ? s_last_valid : 0.0f;  // 异常时保持上一次有效气压
    }

    if (result > 0.0f) s_last_valid = result;  // 仅当结果为正（合理气压）才刷新"上一次有效值"
    return result;  // 返回当前气压（hPa）
}

uint8_t pressure_calc_count(void)
{
    return s_count;  // 返回窗口内有效样本数 0~6
}

/* ====================================================================================
 * 气压→高度转换 (三层大气模型, ISA标准)
 * ====================================================================================
 *
 * 常数:
 *   R  = 287.05287 m²/(K·s²)    干空气气体常数
 *   gn = 9.80665   m/s²          标准重力加速度
 *
 * 第一层 对流层: 226.32 < Ps < 1277.74 hPa, H = -2000 ~ 11000 m
 *   β=-0.0065 K/m, Hb=-2000m, Tb=301.15K, Pb=1277.74 hPa
 *   H = (Tb/β) × [(Ps/Pb)^(-βR/gn) - 1] + Hb
 *
 * 第二层 等温层: 54.75 ≤ Ps ≤ 226.32 hPa, H = 11000 ~ 20000 m
 *   β=0, Hb=11000m, Tb=216.65K, Pb=226.32 hPa
 *   H = (R·Tb/gn) × ln(Pb/Ps) + Hb
 *
 * 第三层 逆温层: Ps < 54.75 hPa, H = 20000 ~ 32000 m
 *   β=0.001 K/m, Hb=20000m, Tb=216.65K, Pb=54.7487 hPa
 *   H = (Tb/β) × [(Ps/Pb)^(-βR/gn) - 1] + Hb
 * ==================================================================================== */

/* 预计算的无量纲指数 */
#define L1_EXPONENT   0.1902631f   /* -βR/gn = 0.0065*287.05287/9.80665 */
#define L3_EXPONENT  -0.02927125f  /* -βR/gn = -0.001*287.05287/9.80665 */

float pressure_to_altitude(float pressure_hpa)
{
    float h;

    if (pressure_hpa <= 0.0f)  // 非法/零气压直接返回 0，避免 pow/log 算出 NaN
        return 0.0f;  // 返回 0

    if (pressure_hpa > 226.32f)  // 第一层 对流层（约 -2~11km）：气压 > 226.32hPa
    {
        /* 第一层: 对流层, β=-0.0065, Tb/β = -46330.77 */
        float ratio = pressure_hpa / 1277.74f;  // ratio = Ps/Pb，Pb = 1277.74hPa 为对流层顶参考气压
        h = -(301.15f / 0.0065f) * (powf(ratio, L1_EXPONENT) - 1.0f) - 2000.0f;  // H=(Tb/β)[(Ps/Pb)^(-βR/gn)-1]+Hb；Tb=301.15K，β=-0.0065K/m，Hb=-2000m
    }
    else if (pressure_hpa >= 54.75f)  // 第二层 等温层（11~20km）：54.75 ≤ Ps ≤ 226.32hPa
    {
        /* 第二层: 等温层 */
        h = (287.05287f * 216.65f / 9.80665f) * logf(226.32f / pressure_hpa) + 11000.0f;  // 等温层 H=(R·Tb/gn)·ln(Pb/Ps)+Hb；Tb=216.65K，Pb=226.32hPa，Hb=11000m
    }
    else
    {
        /* 第三层: 逆温层 */
        float ratio = pressure_hpa / 54.7487f;  // 第三层 逆温层（20~32km）：Ps<54.75hPa；ratio=Ps/Pb，Pb=54.7487hPa
        h = (216.65f / 0.001f) * (powf(ratio, L3_EXPONENT) - 1.0f) + 20000.0f;  // H=(Tb/β)[(Ps/Pb)^(-βR/gn)-1]+Hb；Tb=216.65K，β=0.001K/m，Hb=20000m
    }

    return h;  // 返回海拔高度（m）
}

uint8_t pressure_calc_get_window(uint32_t *ch1_out, uint32_t *ch2_out)
{
    uint8_t i;
    for (i = 0; i < s_count; i++)  // 按时间顺序取出窗口内 s_count 个样本
    {
        uint8_t idx = (s_write_idx + PRESSURE_WINDOW_SIZE - s_count + i) % PRESSURE_WINDOW_SIZE;  // 环形顺序：最旧样本在(写指针-样本数)处，逐个递进到最新
        ch1_out[i] = s_ch1_buf[idx];  // 拷出该样本的 CH1 频率
        ch2_out[i] = s_ch2_buf[idx];  // 拷出该样本的 CH2 频率
    }
    return s_count;  // 返回有效样本数
}

/* ====================================================================================
 * 温度计算 (使用TS参数)
 *
 * 公式: T = Σ k[i][j] * x^j * y^i
 * 其中: x = (f1 - Δf1) / f1_scale
 *       y = (f2 - Δf2) / f2_scale
 * ==================================================================================== */
float temperature_calc_get(void)
{
    float result = 0.0f;
    uint8_t i, j;
    static float s_last_valid = 0.0f;

    if (s_count == 0 || !s_ts_loaded)  // 无样本或 TS 系数未就绪，直接返回 0
        return 0.0f;  // 返回 0

    /* 求频率均值 */
    {
        uint64_t sum1 = 0, sum2 = 0;  // 两路频率求和（64 位防溢出）
        for (i = 0; i < s_count; i++)  // 累加窗口内所有样本频率
        {
            sum1 += s_ch1_buf[i];  // CH1 累加
            sum2 += s_ch2_buf[i];  // CH2 累加
        }

        float f1 = (float)(sum1 / s_count) / 1000.0f;  // f1 = CH1 窗口频率均值（Hz）
        float f2 = (float)(sum2 / s_count) / 1000.0f;  // f2 = CH2 窗口频率均值（Hz）
        float x  = (f1 - s_ts_delta_f1) / s_ts_f1_scale;  // 用 TS 自己的归一化参数求 x=(f1-Δf1)/f1_scale
        float y  = (f2 - s_ts_delta_f2) / s_ts_f2_scale;  // 求 y=(f2-Δf2)/f2_scale

        /* 输入限幅 */
        if (x > 3.0f || x < -3.0f || y > 3.0f || y < -3.0f)
            return (s_last_valid != 0.0f) ? s_last_valid : 0.0f;  // x/y 越界则保持上一次有效温度

        /* 预计算 x 和 y 的各次幂 */
        float xp[6], yp[6];  // 预存 x、y 的 0~5 次幂
        xp[0] = 1.0f;  yp[0] = 1.0f;  // x^0 = y^0 = 1
        for (i = 1; i < 6; i++)  // 递推各次幂 i=1..5
        {
            xp[i] = xp[i - 1] * x;  // xp[i] = x^i
            yp[i] = yp[i - 1] * y;  // yp[i] = y^i
        }

        /* 多项式累加 */
        for (i = 0; i < 6; i++)  // 用 TS 系数做同样的 21 项下三角多项式累加
        {
            for (j = 0; j < 6 - i; j++)  // i+j≤5
            {
                result += s_ts_k[i][j] * xp[j] * yp[i];  // 累加 k[i][j]·x^j·y^i
            }
        }
    }

    s_last_valid = result;  // 记录本次有效温度
    return result;  // 返回温度（单位由标定系数决定）
}

/* ====================================================================================
 * 标定参数设置函数 (由protocol.c调用)
 * ==================================================================================== */

void pressure_calc_set_params(float delta_f1, float f1_scale,
                               float delta_f2, float f2_scale,
                               const float k[6][6])
{
    (void)delta_f1; (void)f1_scale; (void)delta_f2; (void)f2_scale; (void)k;  // (void) 占位避免"参数未使用"告警：此旧接口保留兼容，实际走 set_ps/pt
    /* 保留接口兼容性，实际使用set_ps/pt_params */
}

void pressure_calc_set_ps_params(const double params[25])
{
    float fparams[25];  // double→float 中转数组（Flash 读出的标定参数是 double，运算统一用 float）
    uint8_t i;
    for (i = 0; i < 25; i++) fparams[i] = (float)params[i];  // 25 个参数全部 double→float

    s_ps_delta_f1 = fparams[0];  // [0]=Δf1
    s_ps_f1_scale = fparams[1];  // [1]=f1_scale
    s_ps_delta_f2 = fparams[2];  // [2]=Δf2
    s_ps_f2_scale = fparams[3];  // [3]=f2_scale
    parse_params_to_k(fparams, s_ps_k);  // [4..24] 的 21 个系数按 TPC 顺序拆进 6×6 矩阵
    s_ps_loaded = 1;  // 标记 PS 系数已就绪
    s_flash_params_loaded = 1;  // 标记 Flash 标定参数已生效（区别于硬编码默认值）
}

void pressure_calc_set_pt_params(const double params[25])
{
    float fparams[25];  // double→float 中转数组
    uint8_t i;
    for (i = 0; i < 25; i++) fparams[i] = (float)params[i];  // 25 个参数全部 double→float

    s_pt_delta_f1 = fparams[0];  // [0]=Δf1
    s_pt_f1_scale = fparams[1];  // [1]=f1_scale
    s_pt_delta_f2 = fparams[2];  // [2]=Δf2
    s_pt_f2_scale = fparams[3];  // [3]=f2_scale
    parse_params_to_k(fparams, s_pt_k);  // [4..24] 拆进 PT 的 6×6 矩阵
    s_pt_loaded = 1;  // 标记 PT 系数已就绪（>1200hPa 分支从此可用）
}

uint8_t pressure_calc_has_flash_params(void)
{
    return s_flash_params_loaded;  // 返回 1=已用 Flash 参数，0=仍用硬编码默认参数
}

/* 内部函数: 从float数组设置PS参数 (用于默认参数初始化) */
static void set_ps_params_from_float(const float params[25])
{
    s_ps_delta_f1 = params[0];  // [0]=Δf1=65000
    s_ps_f1_scale = params[1];  // [1]=f1_scale=3800
    s_ps_delta_f2 = params[2];  // [2]=Δf2=59000
    s_ps_f2_scale = params[3];  // [3]=f2_scale=3700
    parse_params_to_k(params, s_ps_k);  // 拆 21 个系数进 PS 矩阵
    s_ps_loaded = 1;  // 标记 PS 就绪
}

/* 内部函数: 从float数组设置PT参数 (用于默认参数初始化) */
static void set_pt_params_from_float(const float params[25])
{
    s_pt_delta_f1 = params[0];  // [0]=Δf1
    s_pt_f1_scale = params[1];  // [1]=f1_scale
    s_pt_delta_f2 = params[2];  // [2]=Δf2
    s_pt_f2_scale = params[3];  // [3]=f2_scale
    parse_params_to_k(params, s_pt_k);  // 拆 21 个系数进 PT 矩阵（注意：此处不置 s_pt_loaded，故默认模式恒走 PS 段）
}

/* 内部函数: 从float数组设置TS参数 (用于默认参数初始化) */
static void set_ts_params_from_float(const float params[25])
{
    s_ts_delta_f1 = params[0];  // [0]=Δf1=67000
    s_ts_f1_scale = params[1];  // [1]=f1_scale=3400
    s_ts_delta_f2 = params[2];  // [2]=Δf2=57000
    s_ts_f2_scale = params[3];  // [3]=f2_scale=3500
    parse_params_to_k(params, s_ts_k);  // 拆 21 个系数进 TS 矩阵
    s_ts_loaded = 1;  // 标记 TS 就绪
}

void pressure_calc_set_ts_params(const double params[25])
{
    float fparams[25];  // double→float 中转数组
    uint8_t i;
    for (i = 0; i < 25; i++) fparams[i] = (float)params[i];  // 25 个参数全部 double→float

    s_ts_delta_f1 = fparams[0];  // [0]=Δf1
    s_ts_f1_scale = fparams[1];  // [1]=f1_scale
    s_ts_delta_f2 = fparams[2];  // [2]=Δf2
    s_ts_f2_scale = fparams[3];  // [3]=f2_scale
    parse_params_to_k(fparams, s_ts_k);  // [4..24] 拆进 TS 的 6×6 矩阵
    s_ts_loaded = 1;  // 标记 TS 系数已就绪
}
