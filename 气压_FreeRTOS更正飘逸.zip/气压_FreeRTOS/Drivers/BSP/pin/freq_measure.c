/* ====================================================================================
 * 文件: freq_measure.c
 * 描述: GD32F303 双通道等精度测频模块（每个通道各有一套独立的参考时基）
 * ====================================================================================
 *
 * 一、测量原理（多周期同步法 / 等精度测频）
 *
 *      频率 = 信号沿个数 N ÷ 参考计数 R × 参考时钟 f_ref
 *           = N × 120MHz ÷ R                    （f_ref = 120MHz = 系统主频）
 *
 *   要点：闸门的"起点"和"终点"都对齐在信号沿上，所以测量区间恰好是整数个信号周期，
 *   不存在传统的 ±1 计数误差。剩下的误差只有"参考计数 R 的 ±1 个字"：
 *      100ms 闸门 → R ≈ 12,000,000 → 1 个字 = 0.083 ppm（这就是本模块的分辨率地板）
 *
 *   实现方式：
 *     · 起点：start() 只启动信号计数；等第一个信号沿到来时，在同一个沿上清零并启动参考时基；
 *     · 终点：参考计数到达闸门目标后置 stop_pending="举手"，等下一个信号沿才真正停表。
 *
 * 二、定时器分工
 *   - TIMER0: 外部时钟模式0，PA8 输入，CH1 信号沿计数（16位 + 溢出中断扩展）
 *   - TIMER4: 内部时钟 120MHz，CH1 独立参考时基（16位 + 溢出中断扩展）
 *   - TIMER1: 外部时钟模式0，PA0 输入，CH2 信号沿计数
 *   - TIMER5: 内部时钟 120MHz，CH2 独立参考时基
 *   两通道完全独立、各自同步启停，互不干扰。
 *
 * 三、中断向量与抢占优先级（优先级数值越小越紧急，详见各 init 函数末尾）
 *   - TIMER0_UP_IRQn      (1): TIMER0 溢出 → CH1 信号计数扩展到 32 位
 *   - TIMER0_Channel_IRQn (0): TIMER0 捕获 → CH1 启动同步 + 停表（最高优先级）
 *   - TIMER1_IRQn         (1): TIMER1 统一入口 → CH2 溢出计数 + 捕获(启动同步/停表)
 *   - TIMER4_IRQn         (1): TIMER4 溢出 → CH1 参考计数扩展 + 闸门到点判断
 *   - TIMER5_IRQn         (1): TIMER5 溢出 → CH2 参考计数扩展 + 闸门到点判断
 *
 * 四、两处专门针对"高频抖动"的设计（都是实测定位出来的，别随手改掉）
 *
 *   ① 捕获中断只在两端各开一次（见 freq_measure_ch1_start 的注释）
 *      原来每个信号沿都进一次捕获中断，320kHz 时 CPU 占用 45%，参考计数被迫推迟读取，
 *      读数抖动达 267 个字（22 ppm）。改成"只在启动沿和停表沿开"之后，
 *      中断占用降到约 0.1%，抖动回到 2~6 个字（0.2~0.5 ppm）。
 *      依据：捕获寄存器 CH0CV 是硬件在每个沿锁存的，与中断开不开无关，关中断不会丢沿。
 *
 *   ② CH2 闸门比 CH1 多一个"错开量"= 60000 字 = 0.5 毫秒（见 freq_measure_ch2_start 的注释）
 *      两路同时启停时"停表"时刻只差几微秒，两个停表中断会互相挡，
 *      导致 [Ref2] 出现 +174/+258/+398 的离群值且成串出现；错开后离群值消失。
 *
 * 五、参考计数的原子读取（见 TIMER0_Channel_IRQHandler 的停表分支）
 *   读参考计数时必须保证"溢出次数"和"计数器当前值"属于同一时刻，否则会在进位边界上
 *   差 60000 个字（0.5%）。做法：__disable_irq() → 读两个值 → 二次检查溢出标志并补偿
 *   → __enable_irq()。
 * ==================================================================================== */

#include "freq_measure.h"
#include "led.h"
#include <stdio.h>

/* ====================================================================================
 * 通道1 (CH1) 变量
 *   signal_count = 信号沿个数 N（32位 = TIMER0溢出次数 << 16 | 捕获寄存器值+1）
 *   ref_count    = 参考计数 R（120MHz 计数，已减去延时补偿）
 * ==================================================================================== */
volatile uint8_t  g_ch1_measure_done = 0;   /* 1=本轮测量完成(已停表, 数据可读); 停表ISR置位, MeasureTask 取走后由 start() 清零 */
volatile uint32_t g_ch1_signal_count = 0;   /* CH1 信号沿个数 N */
volatile uint32_t g_ch1_ref_count = 0;      /* CH1 参考计数 R(已减 g_delay_comp_ch1) */

static volatile uint32_t g_timer0_overflow = 0;   /* TIMER0 溢出次数(信号计数高16位) */
static volatile uint32_t g_timer4_overflow = 0;   /* TIMER4 溢出次数(参考计数高16位) */
static volatile uint8_t  g_ch1_wait_start = 0;    /* 1=等启动同步沿; 捕获ISR在第一个沿上清零并启动 TIMER4 */

/* 【等精度: 时间闸门 + 两端信号沿同步】
 * 参考计数到达闸门时间后不立刻停表, 而是置 stop_pending "举手",
 * 等下一个信号沿到来才停 → 区间 [t0,t1] 恰为整数个信号周期, 无 ±1 误差。
 * 闸门目标拆成: gate_ovf 个整参考周期(REF_TIMER_PERIOD) + gate_cnt 余数 */
static volatile uint8_t  g_ch1_stop_pending = 0;   /* 1=闸门时间已到, 等下一个信号沿 */
static volatile uint32_t g_ch1_gate_ovf     = 0;   /* 闸门 = gate_ovf 个整参考周期 */
static volatile uint32_t g_ch1_gate_cnt     = 0;   /*      + gate_cnt 个计数 (0~59999) */
static volatile uint32_t g_ch1_cmp_cnt      = 0;   /* 已发生的比较匹配次数 */

/* ====================================================================================
 * 通道2 (CH2) 变量
 * ==================================================================================== */
volatile uint8_t  g_ch2_measure_done = 0;   /* 1=CH2 本轮测量完成 */
volatile uint32_t g_ch2_signal_count = 0;   /* CH2 信号沿个数 N */
volatile uint32_t g_ch2_ref_count = 0;      /* CH2 参考计数 R(已减 g_delay_comp_ch2) */
volatile uint32_t g_delay_comp = 62;        /* 兼容保留(未使用); 实际每路用下面的专用值 */
volatile uint32_t g_delay_comp_ch1 = 31;    /* CH1 延时补偿(参考时钟周期数): 2026-10 用真值反推重标 77->31; 原值含 +45.8 字的固定偏差(短闸门档放大成 +187ppm) */
volatile uint32_t g_delay_comp_ch2 = 17;    /* CH2 延时补偿(同上): 53->17; 原值含 +36.1 字的固定偏差 */
volatile uint8_t  g_comp_manual = 0;        /* 1=手动模式(温度补偿暂停) */
volatile uint32_t g_target_ref_count = RESOLUTION_BASE_REF_COUNT; /* 闸门目标参考计数: 默认100ms, 由 PR/PPI 指令动态调整 */

/* 信号计数闸门目标 — 以信号沿数定义闸门, 消除ref ISR异步抖动 */
volatile uint32_t g_target_signal_count_ch1 = DEFAULT_SIGNAL_COUNT_CH1;  /* 默认 ~100ms @65kHz */
volatile uint32_t g_target_signal_count_ch2 = DEFAULT_SIGNAL_COUNT_CH2;  /* 默认 ~100ms @59kHz */

static volatile uint32_t g_timer1_overflow = 0;   /* TIMER1 溢出次数(CH2 信号计数高16位) */
static volatile uint32_t g_timer5_overflow = 0;   /* TIMER5 溢出次数(CH2 参考计数高16位) */
static volatile uint8_t  g_ch2_wait_start = 0;    /* 1=CH2 等启动同步沿 */

/* CH2 同上: 时间闸门 + 两端信号沿同步 */
static volatile uint8_t  g_ch2_stop_pending = 0;  /* 1=闸门时间已到, 等下一个信号沿停表 */
static volatile uint32_t g_ch2_gate_ovf     = 0;  /* 闸门 = gate_ovf 个整参考周期 */
static volatile uint32_t g_ch2_gate_cnt     = 0;  /*      + gate_cnt 个计数(0~59999) */
static volatile uint32_t g_ch2_cmp_cnt      = 0;  /* 已发生的比较匹配次数 */

/* ====================================================================================
 * 静态函数声明
 * ==================================================================================== */
static void freq_gpio_init(void);
static void freq_timer0_init(void);     /* CH1 信号计数: TIMER0 外部时钟模式0 */
static void freq_timer4_init(void);     /* CH1 参考时基: TIMER4 内部 120MHz */
static void freq_timer1_init(void);     /* CH2 信号计数: TIMER1 外部时钟模式0 */
static void freq_timer5_init(void);     /* CH2 参考时基: TIMER5 内部 120MHz */

/* ====================================================================================
 * 公共函数（初始化 / 暂停恢复 / 启动 / 计算 / 打印）
 * ==================================================================================== */

/* ------------------------------------------------------------------------------------
 * 初始化: 配置 5 个定时器的 GPIO、计数模式、捕获通道、输出比较通道与中断优先级。
 * 调用时机: main() 里、启动调度器之前, 只需调用一次。
 * ------------------------------------------------------------------------------------ */
static volatile uint8_t s_freq_measure_initialized = 0;

void freq_measure_init(void)
{
    freq_gpio_init();
    freq_timer0_init();
    freq_timer4_init();
    freq_timer1_init();
    freq_timer5_init();
    s_freq_measure_initialized = 1;
}

/* ------------------------------------------------------------------------------------
 * 暂停/恢复测量: 供"内部 Flash 擦写"期间使用。
 *
 * 原因: Flash 擦写时驱动会 __disable_irq() 数毫秒, 这段时间 TIMER4/TIMER5 的溢出中断
 * 无法响应, 参考溢出次数会漏记, 导致 ref_count 偏小、频率算大。
 * 所以擦写前 pause() 停表并清干净标志, 写完再 resume() 重新启动一轮。
 * ------------------------------------------------------------------------------------ */
void freq_measure_pause(void)
{
    if (!s_freq_measure_initialized) return;

    timer_disable(TIMER0);
    timer_disable(TIMER4);
    timer_disable(TIMER1);
    timer_disable(TIMER5);
    timer_interrupt_disable(TIMER4, TIMER_INT_CH0);
    timer_interrupt_disable(TIMER5, TIMER_INT_CH0);

    timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);
    timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_CH0);
    timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
    timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_CH0);

    g_ch1_measure_done = 0;
    g_ch2_measure_done = 0;
    g_ch1_wait_start   = 0;
    g_ch2_wait_start   = 0;
    g_ch1_stop_pending = 0;
    g_ch2_stop_pending = 0;
    g_timer0_overflow  = 0;
    g_timer4_overflow  = 0;
    g_timer1_overflow  = 0;
    g_timer5_overflow  = 0;
}

/* 恢复测量: 重新启动两路(等价于各调一次 chX_start) */
void freq_measure_resume(void)
{
    if (!s_freq_measure_initialized) return;
    freq_measure_ch1_start();
    freq_measure_ch2_start();
}


/* ====================================================================================
 * 启动 CH1 一轮测量
 * ====================================================================================
 * 流程:
 *   1) 清零本轮所有计数与状态;
 *   2) 按闸门目标算好 TIMER4 的"到点"方式(整周期用溢出判定, 有余数用比较通道);
 *   3) 清捕获标志 → 打开捕获中断 → 使能 TIMER0。
 *      此时 TIMER4(参考时基)还不启动, 等第一个信号沿到来才启动 → 两端沿对齐。
 *
 * 【高频稳定性改动】为什么这里才开捕获中断:
 *   原来捕获中断是常开的, 每个信号沿都进一次 ISR。320kHz 时 CPU 占用 45%,
 *   而停表那一刻要读参考计数, 被别的中断挤住就会晚读 1~3µs → 读数抖 267 个字。
 *   现在只在"等启动沿"和"等停表沿"这两个时刻开中断, 中途完全静默;
 *   精度不受影响, 因为捕获寄存器是硬件锁存的, 与中断开关无关。
 * ==================================================================================== */
void freq_measure_ch1_start(void)
{
    g_ch1_signal_count = 0;
    g_ch1_ref_count    = 0;
    g_timer0_overflow  = 0;
    g_timer4_overflow  = 0;
    g_ch1_measure_done = 0;
    g_ch1_stop_pending = 0;
    g_ch1_wait_start   = 1;

    /* 闸门目标分解: 整参考周期数 + 余数 */
    g_ch1_gate_ovf = g_target_ref_count / REF_TIMER_PERIOD;
    g_ch1_gate_cnt = g_target_ref_count % REF_TIMER_PERIOD;
    g_ch1_cmp_cnt  = 0;

    /* 清残留中断标志 (否则上一轮的标志可能误触发本轮) */
    timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);
    timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_CH0);

    /* 时间闸门精确触发配置:
     *   余数=0 → 目标正好落在溢出点, 用溢出事件判定(硬件精确)
     *   余数!=0 → 用比较通道, CNT==gate_cnt 的瞬间精确触发     */
    if (g_ch1_gate_cnt == 0)
    {
        timer_interrupt_disable(TIMER4, TIMER_INT_CH0);
        timer_channel_output_pulse_value_config(TIMER4, TIMER_CH_0, 0xFFFF);
    }
    else
    {
        timer_channel_output_pulse_value_config(TIMER4, TIMER_CH_0, g_ch1_gate_cnt);
        timer_interrupt_enable(TIMER4, TIMER_INT_CH0);
    }

    timer_counter_value_config(TIMER0, 0);
    timer_counter_value_config(TIMER4, 0);
    /* 【高频稳定性改动】本次测量期间先关掉捕获中断, 只在闸门结束瞬间才打开。
     * 原来每个信号沿都进一次中断(320kHz 时 CPU 占用 45%), 参考计数被迫推迟读取 → 读数飘。
     * 改后中断次数从"每秒 f 次"降到"每次测量 2 次", 而精度不变:
     *   捕获寄存器 CH0CV 是硬件在每个沿锁存的, 与中断开关无关;
     *   停表时 CH0CV 和参考计数在同一时刻读取, 区间仍是整数个信号周期。 */
    timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);  /* 清掉待命期间积压的旧标志 */
    timer_interrupt_enable(TIMER0, TIMER_INT_CH0);           /* 等第一个沿做启动同步 */
    timer_enable(TIMER0);               /* 只启动信号计数, TIMER4 待命 */
}

/* ====================================================================================
 * 【抗串扰改动】CH2 闸门比 CH1 多一个"错开量" (60000 个参考计数 = 0.5 毫秒)
 *
 * 病因: 两路同时启动、同时到点, 所以两个"停表"中断几乎总在同一时刻发生。
 *       CH1 捕获中断是抢占优先级 0(最高), 它的 ISR + 里面的 __disable_irq() 临界区
 *       会把 CH2 读参考计数的那一刻推迟 1~3µs → [Ref2] 跳 +170/+260/+400 个计数。
 *       又因为两路相位缓慢漂移, 这些跳值会"成串"出现(连续几个样本同一个值)。
 *
 * 改法: CH2 闸门延长 0.5 毫秒, 两路停表时刻永久错开, 互不干扰。
 *       闸门变长不影响频率结果(频率是比值), 只让分辨率略微变好;
 *       代价是 [Ref2] 比 [Ref1] 大约 60000 个字, 属正常现象。
 * ==================================================================================== */
#define CH2_GATE_OFFSET_COUNTS  60000UL     /* 0.5毫秒 @120MHz。**必须是 REF_TIMER_PERIOD(60000) 的整数倍** */

/* ====================================================================================
 * 启动 CH2 一轮测量（流程与 CH1 相同，只有一处不同：闸门多一个"错开量"）
 *
 * 【抗串扰改动】为什么要错开：
 *   两路同时启动、闸门又一样长，所以两个"停表"时刻只差几微秒，CH2 读参考计数那一刻
 *   经常被 CH1 的捕获中断（抢占优先级 0，最高）挡住，[Ref2] 就会跳 +174/+258/+398 个字，
 *   而且因为两路相位缓慢漂移，这些跳值会"成串"出现（连续几个样本同一个值）。
 *   把 CH2 闸门延长一个"错开量"后两个停表时刻永久错开，离群值消失。
 *   注意：闸门变长不影响频率结果（频率是比值），只是 [Ref2] 会比 [Ref1] 大约 60000 个字。
 * ==================================================================================== */
void freq_measure_ch2_start(void)
{
    g_ch2_signal_count = 0;
    g_ch2_ref_count    = 0;
    g_timer1_overflow  = 0;
    g_timer5_overflow  = 0;
    g_ch2_measure_done = 0;
    g_ch2_stop_pending = 0;
    g_ch2_wait_start   = 1;

    /* 【抗串扰改动】CH2 闸门 = 目标 + 60000字(0.5毫秒), 与 CH1 错开 (原因见 CH2_GATE_OFFSET_COUNTS 注释) */
    g_ch2_gate_ovf = (g_target_ref_count + CH2_GATE_OFFSET_COUNTS) / REF_TIMER_PERIOD;
    g_ch2_gate_cnt = (g_target_ref_count + CH2_GATE_OFFSET_COUNTS) % REF_TIMER_PERIOD;
    g_ch2_cmp_cnt  = 0;

    timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
    timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_UP);
    timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_CH0);

    if (g_ch2_gate_cnt == 0)
    {
        timer_interrupt_disable(TIMER5, TIMER_INT_CH0);
        timer_channel_output_pulse_value_config(TIMER5, TIMER_CH_0, 0xFFFF);
    }
    else
    {
        timer_channel_output_pulse_value_config(TIMER5, TIMER_CH_0, g_ch2_gate_cnt);
        timer_interrupt_enable(TIMER5, TIMER_INT_CH0);
    }

    timer_counter_value_config(TIMER1, 0);
    timer_counter_value_config(TIMER5, 0);
    /* 【高频稳定性改动】同 CH1: 测量期间关闭捕获中断, 闸门结束才打开 (详见 CH1 处注释) */
    timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
    timer_interrupt_enable(TIMER1, TIMER_INT_CH0);           /* 等第一个沿做启动同步 */
    timer_enable(TIMER1);
}

/* ---------- CH1 ---------- */

/* ------------------------------------------------------------------------------------
 * 计算 CH1 频率，返回"频率×1000"的定点整数（例如 80000.093Hz → 80000093）
 *
 * 公式: f = N × 120MHz ÷ R
 *   分子先乘 1000（120000000000ULL）再做 64 位整数除法，全程无浮点：
 *   GD32F303 没有硬件 FPU，浮点除法要 100+ 周期，而 64 位整数除法只要约 12 周期。
 *   返回值除以 1000 就是 Hz。
 * ------------------------------------------------------------------------------------ */
uint32_t freq_measure_calculate(void)
{
    uint64_t v;
    if (g_ch1_ref_count == 0) return 0;
    v = (uint64_t)g_ch1_signal_count * REF_FREQ_X1000 / g_ch1_ref_count;
    v = v * FREQ_SCALE_NUM / FREQ_SCALE_DEN;   /* 【时基校准】抵消晶振 4.12ppm 比例误差 */
    return (uint32_t)v;
}


void freq_measure_print_result(void)
{
    uint32_t freq_x1000 = freq_measure_calculate();
    printf("[CH1] Signal=%u, Ref=%u\r\n", g_ch1_signal_count, g_ch1_ref_count);
    printf("[CH1] Freq=%u.%03u Hz\r\n", freq_x1000 / 1000, freq_x1000 % 1000);
}

/* ---------- CH2 ---------- */

/* 计算 CH2 频率，返回"频率×1000"的定点整数（算法与 CH1 相同） */
uint32_t freq_measure_ch2_calculate(void)
{
    uint64_t v;
    if (g_ch2_ref_count == 0) return 0;
    v = (uint64_t)g_ch2_signal_count * REF_FREQ_X1000 / g_ch2_ref_count;
    v = v * FREQ_SCALE_NUM / FREQ_SCALE_DEN;   /* 【时基校准】抵消晶振 4.12ppm 比例误差 */
    return (uint32_t)v;
}


void freq_measure_ch2_print_result(void)
{
    uint32_t freq_x1000 = freq_measure_ch2_calculate();
    printf("[CH2] Signal=%u, Ref=%u\r\n", g_ch2_signal_count, g_ch2_ref_count);
    printf("[CH2] Freq=%u.%03u Hz\r\n", freq_x1000 / 1000, freq_x1000 % 1000);
}

/* ---------- 便捷 ---------- */



/* ====================================================================================
 * 中断服务函数
 * ==================================================================================== */

/* ---------- TIMER0 溢出中断: CH1 信号计数扩展到 32 位 ---------- */
/* ------------------------------------------------------------------------------------
 * CH1 信号计数扩展: TIMER0 只有 16 位，每溢出一次高 16 位加一。
 * 32 位信号计数 = g_timer0_overflow << 16 | 捕获寄存器值(+1)
 * ------------------------------------------------------------------------------------ */
void TIMER0_UP_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
        g_timer0_overflow++;
    }
}

/* ---------- TIMER0 捕获（CH1 信号沿同步启停 + 闸门判断） ---------- */
/* ====================================================================================
 * CH1 捕获中断 —— 本模块最关键的一段代码，两种角色共用一个向量
 * ====================================================================================
 * 角色一(启动同步): g_ch1_wait_start=1 时第一个信号沿到来 → 在同一个沿上把 TIMER0/TIMER4
 *   都清零，再启动 TIMER4(参考时基)，于是"起点"精确落在信号沿上。
 *   完成后立刻关掉捕获中断(【高频稳定性改动】)，中途不再进 ISR。
 *
 * 角色二(停表): 参考计数到达闸门目标后 g_ch1_stop_pending=1("举手")，等下一个信号沿到来:
 *   · __disable_irq() 保证"溢出次数"与"计数器当前值"是同一时刻的快照;
 *   · 捕获寄存器 CH0CV 锁存的是"该沿之前"的 CNT，所以信号沿序号 = CH0CV + 1;
 *   · 读完要二次检查溢出标志: 若读取期间刚好进位，把溢出数补上并重读计数器，
 *     否则会在进位边界上差 60000 个字(0.5%);
 *   · ref_count 减去 g_delay_comp_ch1，抵消中断响应与读寄存器的固定延迟;
 *   · 最后置 g_ch1_measure_done=1，通知 MeasureTask 取数。
 * ==================================================================================== */
void TIMER0_Channel_IRQHandler(void)
{
    /* 启动同步: 等第一个上升沿, 在同一沿上清零并启动参考时基 */
    if (g_ch1_wait_start)
    {
        g_ch1_wait_start = 0;
        g_timer0_overflow = 0;
        g_timer4_overflow = 0;
        g_ch1_cmp_cnt = 0;              /* 同步起点也重置比较计数 */
        timer_counter_value_config(TIMER0, 0);
        timer_counter_value_config(TIMER4, 0);
        timer_enable(TIMER4);
        timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);
            /* 【高频稳定性改动】启动同步完成 → 立刻关掉捕获中断, 中途不再打扰 */
            timer_interrupt_disable(TIMER0, TIMER_INT_CH0);
        return;
    }

    if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_CH0) == SET)
    {
        timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);

        /* 终止同步: 闸门时间已到 → 就在这个信号沿上停表 */
        if (g_ch1_stop_pending)
        {
            uint32_t t0_ovf, t4_ovf;
            uint16_t t0_cnt, t4_cnt;

            __disable_irq();

            /* 信号计数用硬件捕获寄存器.
             * 【注意】外部时钟模式下 CH0CV 锁存的是"该信号沿之前"的 CNT,
             * 所以信号沿序号 = CH0CV + 1 (实测 65kHz 少 1 个计数即此故) */
            t0_cnt = (uint16_t)(timer_channel_capture_value_register_read(TIMER0, TIMER_CH_0) + 1u);
            t0_ovf = g_timer0_overflow;
            /* 原子读取参考计数器 */
            t4_ovf = g_timer4_overflow;
            t4_cnt = timer_counter_read(TIMER4);

            timer_disable(TIMER0);

            /* 二次检查溢出标志 (读计数→停表窗口内可能刚溢出) */
            if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_UP))
            {
                t0_ovf++;
                t0_cnt = (uint16_t)(timer_channel_capture_value_register_read(TIMER0, TIMER_CH_0) + 1u);
                timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
            }
            if (timer_interrupt_flag_get(TIMER4, TIMER_INT_FLAG_UP))
            {
                t4_ovf++;
                t4_cnt = timer_counter_read(TIMER4);
                timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_UP);
            }

            __enable_irq();

            g_ch1_signal_count = ((uint32_t)t0_ovf << 16) | t0_cnt;
            g_ch1_ref_count = t4_ovf * REF_TIMER_PERIOD + t4_cnt - g_delay_comp_ch1;
            g_ch1_measure_done = 1;
            g_ch1_stop_pending = 0;

            timer_disable(TIMER4);
            timer_interrupt_disable(TIMER4, TIMER_INT_CH0);
            timer_interrupt_disable(TIMER0, TIMER_INT_CH0);   /* 【高频稳定性改动】停表后保持关闭 */
        }
    }
}

/* ---------- TIMER4 溢出中断: CH1 参考计数扩展 + 闸门到点判断 ---------- */
/* ------------------------------------------------------------------------------------
 * CH1 参考时基溢出 + 闸门到点判断。
 * 闸门到点有两种判定方式(启动时按闸门余数二选一):
 *   · 余数=0  : 目标正好落在溢出点上，用溢出事件判定(硬件精确);
 *   · 余数!=0 : 用 CH0 输出比较通道，在 CNT==gate_cnt 的瞬间触发(精度 1 个参考时钟)。
 * 到点后置 stop_pending=1；并且【高频稳定性改动】先清掉积压的捕获标志、再打开捕获中断，
 * 让 ISR 只在"下一个真实信号沿"触发 —— 这两步顺序不能颠倒，否则会立刻误触发。
 * ------------------------------------------------------------------------------------ */
void TIMER4_IRQHandler(void)
{
    /* 溢出: 参考计数扩展到 32 位 */
    if (timer_interrupt_flag_get(TIMER4, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_UP);
        g_timer4_overflow++;

        /* 时间闸门(余数=0): 目标正好落在溢出点, 溢出事件本身即硬件精确时刻 */
        if (g_ch1_gate_cnt == 0 && g_ch1_stop_pending == 0
            && g_timer4_overflow >= g_ch1_gate_ovf)
        {
            g_ch1_stop_pending = 1;
            /* 【高频稳定性改动】闸门时间到 → 先清掉积压标志, 再开捕获中断, 等下一个真实信号沿停表 */
            timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);
            timer_interrupt_enable(TIMER0, TIMER_INT_CH0);
        }
    }

    /* 时间闸门(余数!=0): 比较通道在 CNT==gate_cnt 的瞬间触发, 精度 1 个参考时钟 */
    if (timer_interrupt_flag_get(TIMER4, TIMER_INT_FLAG_CH0) == SET)
    {
        timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_CH0);
        if (g_ch1_stop_pending == 0 && (++g_ch1_cmp_cnt) > g_ch1_gate_ovf)
        {
            g_ch1_stop_pending = 1;
            /* 【高频稳定性改动】闸门时间到 → 先清掉积压标志, 再开捕获中断, 等下一个真实信号沿停表 */
            timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);
            timer_interrupt_enable(TIMER0, TIMER_INT_CH0);
            timer_interrupt_disable(TIMER4, TIMER_INT_CH0);
        }
    }
}

/* ---------- TIMER1 统一（CH2 信号计数 + 同步启停 + 闸门判断） ---------- */
/* ------------------------------------------------------------------------------------
 * CH2 统一中断入口: 溢出计数 + 捕获(启动同步 / 停表) 都在这一个向量里。
 * 停表分支与 CH1 同理: __disable_irq 原子读 → CH0CV+1 得信号沿数 → 二次检查溢出补偿。
 * ------------------------------------------------------------------------------------ */
void TIMER1_IRQHandler(void)
{
    /* 溢出 */
    if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
        g_timer1_overflow++;
    }

    /* 捕获 */
    if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_CH0) == SET)
    {
        /* 启动同步: 等第一个上升沿, 在同一沿上清零并启动参考时基 */
        if (g_ch2_wait_start)
        {
            g_ch2_wait_start = 0;
            g_timer1_overflow = 0;
            g_timer5_overflow = 0;
            g_ch2_cmp_cnt = 0;
            timer_counter_value_config(TIMER1, 0);
            timer_counter_value_config(TIMER5, 0);
            timer_enable(TIMER5);
            timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
            /* 【高频稳定性改动】启动同步完成 → 立刻关掉捕获中断, 中途不再打扰 */
            timer_interrupt_disable(TIMER1, TIMER_INT_CH0);
            return;
        }

        timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);

        /* 终止同步: 闸门时间已到 → 就在这个信号沿上停表 */
        if (g_ch2_stop_pending)
        {
            uint32_t t1_ovf, t5_ovf;
            uint16_t t1_cnt, t5_cnt;

            __disable_irq();

            /* 信号计数用硬件捕获寄存器.
             * 【注意】外部时钟模式下 CH0CV 锁存的是"该信号沿之前"的 CNT,
             * 所以信号沿序号 = CH0CV + 1 (与 CH1 一致) */
            t1_cnt = (uint16_t)(timer_channel_capture_value_register_read(TIMER1, TIMER_CH_0) + 1u);
            t1_ovf = g_timer1_overflow;
            /* 原子读取参考计数器 */
            t5_ovf = g_timer5_overflow;
            t5_cnt = timer_counter_read(TIMER5);

            timer_disable(TIMER1);

            /* 二次检查溢出标志 */
            if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP))
            {
                t1_ovf++;
                t1_cnt = (uint16_t)(timer_channel_capture_value_register_read(TIMER1, TIMER_CH_0) + 1u);
                timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
            }
            if (timer_interrupt_flag_get(TIMER5, TIMER_INT_FLAG_UP))
            {
                t5_ovf++;
                t5_cnt = timer_counter_read(TIMER5);
                timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_UP);
            }

            __enable_irq();

            g_ch2_signal_count = ((uint32_t)t1_ovf << 16) | t1_cnt;
            g_ch2_ref_count = t5_ovf * REF_TIMER_PERIOD + t5_cnt - g_delay_comp_ch2;
            g_ch2_measure_done = 1;
            g_ch2_stop_pending = 0;

            timer_disable(TIMER5);
            timer_interrupt_disable(TIMER5, TIMER_INT_CH0);
            timer_interrupt_disable(TIMER1, TIMER_INT_CH0);   /* 【高频稳定性改动】停表后保持关闭 */
        }
    }
}

/* ---------- TIMER5 溢出中断: CH2 参考计数扩展 + 闸门到点判断 ---------- */
/* ------------------------------------------------------------------------------------
 * CH2 参考时基溢出 + 闸门到点判断（逻辑与 TIMER4 相同，作用于 CH2 的变量）。
 * ------------------------------------------------------------------------------------ */
void TIMER5_IRQHandler(void)
{
    /* 溢出: 参考计数扩展到 32 位 (CH2) */
    if (timer_interrupt_flag_get(TIMER5, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_UP);
        g_timer5_overflow++;

        /* 时间闸门(余数=0): 目标正好落在溢出点, 溢出事件本身即硬件精确时刻 */
        if (g_ch2_gate_cnt == 0 && g_ch2_stop_pending == 0
            && g_timer5_overflow >= g_ch2_gate_ovf)
        {
            g_ch2_stop_pending = 1;
            /* 【高频稳定性改动】闸门时间到 → 先清掉积压标志, 再开捕获中断, 等下一个真实信号沿停表 */
            timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
            timer_interrupt_enable(TIMER1, TIMER_INT_CH0);
        }
    }

    /* 时间闸门(余数!=0): 比较通道在 CNT==gate_cnt 的瞬间触发 */
    if (timer_interrupt_flag_get(TIMER5, TIMER_INT_FLAG_CH0) == SET)
    {
        timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_CH0);
        if (g_ch2_stop_pending == 0 && (++g_ch2_cmp_cnt) > g_ch2_gate_ovf)
        {
            g_ch2_stop_pending = 1;
            /* 【高频稳定性改动】闸门时间到 → 先清掉积压标志, 再开捕获中断, 等下一个真实信号沿停表 */
            timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
            timer_interrupt_enable(TIMER1, TIMER_INT_CH0);
            timer_interrupt_disable(TIMER5, TIMER_INT_CH0);
        }
    }
}

/* ====================================================================================
 * 静态函数实现
 * ==================================================================================== */

/* ------------------------------------------------------------------------------------
 * GPIO: PA8 = CH1 信号输入，PA0 = CH2 信号输入（都配成浮空输入）
 * ------------------------------------------------------------------------------------ */
static void freq_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_AF);
    gpio_init(FREQ_CH1_INPUT_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, FREQ_CH1_INPUT_PIN);
    gpio_init(FREQ_CH2_INPUT_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, FREQ_CH2_INPUT_PIN);
}

/* ---- TIMER0: CH1 信号计数, 外部时钟模式0, PA8 ---- */
/* ------------------------------------------------------------------------------------
 * TIMER0: CH1 信号计数。外部时钟模式0（用 PA8 上升沿驱动 CNT），
 * 配 CH0 输入捕获（硬件在每个沿锁存 CNT）+ 溢出中断（扩展成 32 位）。
 * 抢占优先级 1，好让捕获中断(0)能抢占它。
 * ------------------------------------------------------------------------------------ */
static void freq_timer0_init(void)
{
    timer_parameter_struct timer_initpara;
    timer_ic_parameter_struct icpara;

    rcu_periph_clock_enable(RCU_TIMER0);
    timer_deinit(TIMER0);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = 0xFFFF;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER0, &timer_initpara);

    timer_channel_input_struct_para_init(&icpara);
    icpara.icpolarity  = TIMER_IC_POLARITY_RISING;
    icpara.icselection = TIMER_IC_SELECTION_DIRECTTI;
    icpara.icprescaler = TIMER_IC_PSC_DIV1;
    icpara.icfilter    = 4;
    timer_input_capture_config(TIMER0, TIMER_CH_0, &icpara);

    timer_input_trigger_source_select(TIMER0, TIMER_SMCFG_TRGSEL_CI0FE0);
    timer_slave_mode_select(TIMER0, TIMER_SLAVE_MODE_EXTERNAL0);

    timer_interrupt_enable(TIMER0, TIMER_INT_UP);
    timer_interrupt_enable(TIMER0, TIMER_INT_CH0);
    nvic_irq_enable(TIMER0_UP_IRQn, 1, 1);        /* 溢出降级: 让捕获中断能抢占它 */
    nvic_irq_enable(TIMER0_Channel_IRQn, 0, 0);   /* 捕获最高: 读参考计数的时刻恒定 */
}

/* ---- TIMER4: CH1 参考时基, 内部 120MHz ---- */
/* ------------------------------------------------------------------------------------
 * TIMER4: CH1 参考时基。内部时钟 120MHz，周期 60000 个计数（0.5ms 溢出一次），
 * CH0 输出比较通道只用于"闸门精确触发"，不接任何引脚（GPIO 不配复用）。
 * 溢出中断默认打开；比较中断由 start() 按闸门余数按需打开。
 * ------------------------------------------------------------------------------------ */
static void freq_timer4_init(void)
{
    timer_parameter_struct timer_initpara;
    timer_oc_parameter_struct ocpara;

    rcu_periph_clock_enable(RCU_TIMER4);
    timer_deinit(TIMER4);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = REF_TIMER_PERIOD - 1;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER4, &timer_initpara);

    /* CH0 输出比较通道: 仅用于"闸门精确触发", 不接任何引脚(GPIO 不配 AF) */
    timer_channel_output_struct_para_init(&ocpara);
    ocpara.outputstate = TIMER_CCX_ENABLE;
    ocpara.ocpolarity  = TIMER_OC_POLARITY_HIGH;
    ocpara.ocidlestate = TIMER_OC_IDLE_STATE_LOW;
    timer_channel_output_config(TIMER4, TIMER_CH_0, &ocpara);
    timer_channel_output_mode_config(TIMER4, TIMER_CH_0, TIMER_OC_MODE_TIMING);
    timer_channel_output_pulse_value_config(TIMER4, TIMER_CH_0, 0xFFFF);

    timer_interrupt_enable(TIMER4, TIMER_INT_UP);
    /* CH0 比较中断默认关闭, 由 freq_measure_ch1_start() 按闸门余数按需开启 */
    nvic_irq_enable(TIMER4_IRQn, 1, 1);  /* 溢出降级: 让捕获(抢占级0)能抢占, 读 ref 时刻恒定 */
}

/* ---- TIMER1: CH2 信号计数, 外部时钟模式0, PA0 ---- */
/* ------------------------------------------------------------------------------------
 * TIMER1: CH2 信号计数。外部时钟模式0（PA0 上升沿驱动），
 * 捕获 + 溢出共用同一个中断向量(TIMER1_IRQn)。
 * ------------------------------------------------------------------------------------ */
static void freq_timer1_init(void)
{
    timer_parameter_struct timer_initpara;
    timer_ic_parameter_struct icpara;

    rcu_periph_clock_enable(RCU_TIMER1);
    timer_deinit(TIMER1);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = 0xFFFF;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER1, &timer_initpara);

    timer_channel_input_struct_para_init(&icpara);
    icpara.icpolarity  = TIMER_IC_POLARITY_RISING;
    icpara.icselection = TIMER_IC_SELECTION_DIRECTTI;
    icpara.icprescaler = TIMER_IC_PSC_DIV1;
    icpara.icfilter    = 4;
    timer_input_capture_config(TIMER1, TIMER_CH_0, &icpara);

    timer_input_trigger_source_select(TIMER1, TIMER_SMCFG_TRGSEL_CI0FE0);
    timer_slave_mode_select(TIMER1, TIMER_SLAVE_MODE_EXTERNAL0);

    timer_interrupt_enable(TIMER1, TIMER_INT_UP);
    timer_interrupt_enable(TIMER1, TIMER_INT_CH0);
    nvic_irq_enable(TIMER1_IRQn, 1, 0);   /* CH2 捕获降为1: 让CH1捕获(0)能抢占, 优先保证CH1读参考计数时刻恒定 */
}

/* ---- TIMER5: CH2 参考时基, 内部 120MHz ---- */
/* ------------------------------------------------------------------------------------
 * TIMER5: CH2 参考时基（与 TIMER4 对称，内部 120MHz，0.5ms 溢出一次）。
 * ------------------------------------------------------------------------------------ */
static void freq_timer5_init(void)
{
    timer_parameter_struct timer_initpara;
    timer_oc_parameter_struct ocpara;

    rcu_periph_clock_enable(RCU_TIMER5);
    timer_deinit(TIMER5);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = REF_TIMER_PERIOD - 1;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER5, &timer_initpara);

    /* CH0 输出比较通道: 仅用于"闸门精确触发", 不接任何引脚(GPIO 不配 AF) */
    timer_channel_output_struct_para_init(&ocpara);
    ocpara.outputstate = TIMER_CCX_ENABLE;
    ocpara.ocpolarity  = TIMER_OC_POLARITY_HIGH;
    ocpara.ocidlestate = TIMER_OC_IDLE_STATE_LOW;
    timer_channel_output_config(TIMER5, TIMER_CH_0, &ocpara);
    timer_channel_output_mode_config(TIMER5, TIMER_CH_0, TIMER_OC_MODE_TIMING);
    timer_channel_output_pulse_value_config(TIMER5, TIMER_CH_0, 0xFFFF);

    timer_interrupt_enable(TIMER5, TIMER_INT_UP);
    /* CH0 比较中断默认关闭, 由 freq_measure_ch2_start() 按闸门余数按需开启 */
    nvic_irq_enable(TIMER5_IRQn, 1, 1);  /* 溢出降级: 让捕获(抢占级0)能抢占, 读 ref 时刻恒定 */
}
