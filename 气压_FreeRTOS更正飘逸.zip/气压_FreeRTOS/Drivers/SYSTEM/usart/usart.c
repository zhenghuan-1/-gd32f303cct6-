/* ====================================================================================
 * 文件: usart.c
 * 描述: USART0(PA9=TX / PA10=RX) 串口驱动，本工程与上位机通讯的唯一物理口。
 *
 *   本模块四件事：
 *     1) printf 重定向：把 C 库 fputc 接到 USART0（轮询单字节发送），并关掉半主机；
 *     2) 发送互斥锁：printf(轮询) 与 协议回包(DMA) 共用一路 UART，用一个互斥量保证
 *        同一时刻只有一个任务在写，避免两个任务的字符互相穿插把协议帧撕开；
 *     3) DMA 接收：DMA0_CH4 把收到的字节持续搬进环形缓冲 g_usart_dma_rx_buf，
 *        靠 USART 的 IDLE 中断(总线空闲一字符时间)判定一帧结束，再从环里取出整帧；
 *     4) DMA 发送：DMA0_CH3 把 s_dma_tx_buf 整块搬到 USART0 数据寄存器，异步发送。
 *
 *   帧提取思路见 usart_dma_rx_frame_extract()：DMA 通道传输计数 CHCNT 是向下递减的，
 *   本次新到字节数 = (上次剩余 - 本次剩余 + 环长) % 环长，从而在环形缓冲里定位帧边界。
 *
 *   注意：本文件原为 UTF-8 主体夹 6 段 GBK 中文注释，本次已统一重写为 UTF-8；
 *        代码与字符串字面量保持原样未动。
 * ==================================================================================== */

#include "sys.h"
#include "usart.h"
#include "led.h"
#include "protocol.h"
#include <string.h>

/* ===== OS 相关头文件：只有开了 FreeRTOS(SYS_SUPPORT_OS) 才需要 ===== */
#if SYS_SUPPORT_OS
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

/* ------------------------------------------------------------------------------------
 * 【FreeRTOS 移植改动】串口发送互斥锁
 *
 *   printf(单字节轮询发送) 与 协议回包(DMA 整帧发送) 共用同一路 USART0。
 *   若两个任务同时输出，字符会被互相插入：DMA 发到一半被 fputc 插进几个字节，
 *   协议帧就被撕开，上位机按帧校验时 XOR 校验和必然对不上、整帧丢弃。
 *   下面这组函数保证"同一时刻只有一个任务在写 UART"：
 *     - usart_dma_send() 整帧持锁(锁只保护"提交 DMA"这一小段，发完由硬件异步完成)；
 *     - fputc() 取到锁后才发，并且等 DMA 不在忙时才插字节；
 *     - 锁在 usart_init() 里创建(调度器启动前创建互斥量是允许的)。
 *   另外：取锁前先判断调度器是否已启动，调度器未跑时裸调用 xSemaphoreTake 会出问题，
 *   此时直接退化成不加锁(初始化阶段单线程，本就无需互斥)。
 * ------------------------------------------------------------------------------------ */
#if SYS_SUPPORT_OS
static SemaphoreHandle_t s_uart_tx_mutex = NULL;   /* UART 发送互斥量句柄，NULL=尚未创建 */
#endif

/* 函数: usart_tx_lock
 * 功能: 获取 UART 发送互斥锁（拿不到就一直等）
 * 说明: 调度器未启动或锁未创建时直接返回——初始化阶段单线程，无需互斥。 */
static void usart_tx_lock(void)
{
#if SYS_SUPPORT_OS
    /* 锁已创建 且 调度器已启动，才真正去阻塞等待；否则(初始化阶段)跳过 */
    if (s_uart_tx_mutex != NULL && xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
        xSemaphoreTake(s_uart_tx_mutex, portMAX_DELAY);   /* portMAX_DELAY=永久等待，直到拿到锁 */
#endif
}

/* 函数: usart_tx_unlock
 * 功能: 释放 UART 发送互斥锁
 * 说明: 与 usart_tx_lock() 成对，同样先判断调度器状态，避免对未启动的内核操作。 */
static void usart_tx_unlock(void)
{
#if SYS_SUPPORT_OS
    if (s_uart_tx_mutex != NULL && xTaskGetSchedulerState() != taskSCHEDULER_NOT_STARTED)
        xSemaphoreGive(s_uart_tx_mutex);
#endif
}

/* 函数: usart_tx_mutex_create
 * 功能: 创建 UART 发送互斥量
 * 说明: 在 usart_init() 里、启动调度器之前调用；调度器未启动时创建互斥量是允许的。 */
static void usart_tx_mutex_create(void)
{
#if SYS_SUPPORT_OS
    s_uart_tx_mutex = xSemaphoreCreateMutex();   /* 递归/普通互斥量，用于保护 UART 发送 */
#endif
}
#endif

/******************************************************************************************/
/* 重定向 C 库 printf 到 USART0；以下代码由 Keil 提供，不勾选 use MicroLIB 也能用 printf */

#if 1

#if (__ARMCC_VERSION >= 6010050)            /* __ARMCC_VERSION>=6010050 即 AC6(armclang) 编译器 */
__asm(".global __use_no_semihosting\n\t");  /* 声明不使用半主机模式(不依赖调试器做 IO) */
__asm(".global __ARM_use_no_argv \n\t");    /* AC6 需要显式声明 main 为无参数入口 */
#else
/* AC5(armcc) 编译器：用 pragma 导入"不使用半主机"，并重定义 FILE 结构体 */
#pragma import(__use_no_semihosting)

struct __FILE
{
    int handle;
};
#endif

/* 半主机桩：这些函数被 C 库引用，板子上没有对应的主机服务，给空实现避免链接报错 */
int _ttywrch(int ch)
{
    ch = ch;
    return ch;
}

void _sys_exit(int x)
{
    x = x;
}

char *_sys_command_string(char *cmd, int len)
{
    return NULL;
}

FILE __stdout;   /* C 库标准输出对象，printf 默认写到它 */

/* 函数: fputc
 * 功能: printf 重定向的落点——把一个字节从 USART0 发出去
 * 参数: ch —— 待发送字节
 * 返回: 原样返回 ch(C 库约定)
 * 说明: 单字节轮询发送，供 printf 低频调用。三步防穿插：
 *        ① 先拿发送互斥锁，保证不和别的任务同时写；
 *        ② 等 DMA 不在忙(g_usart_dma_tx_busy==0)，即协议回包整帧提交完再插字节；
 *        ③ 等 TC(发送完成)标志，确保上一个字节真正移位发完再写下一个。 */
int fputc(int ch, FILE *f)
{
    usart_tx_lock();                                /* 拿锁：同一时刻只允许一个任务打印 */
    while (g_usart_dma_tx_busy);                    /* DMA 正在发协议帧时不插字节，保护整帧 */
    while(RESET == usart_flag_get(USART0, USART_FLAG_TC));   /* 等发送完成(TC)标志置起 */
    usart_data_transmit(USART0, (uint8_t)ch);       /* 把 ch 写入发送数据寄存器，启动移位发送 */
    usart_tx_unlock();                              /* 放锁 */
    return ch;
}
#endif
/******************************************************************************************/


/* ====================================================================================
 * DMA 接收环形缓冲 + 帧提取  相关全局变量
 * ==================================================================================== */
/* 接收环形缓冲：DMA0_CH4 循环模式把 USART0 收到的字节源源不断写进来。
 * 大小 USART_DMA_RX_BUF_SIZE=1024(=2^10)，必须是 2 的幂——GD32 DMA 循环模式
 * 靠计数回绕实现环形，2 的幂才能让 (start+i)%SIZE 这种取模取整高效且无歧义。 */
uint8_t  g_usart_dma_rx_buf[USART_DMA_RX_BUF_SIZE];

/* 发送忙标志：1=DMA 正在发送一帧。fputc/动态改波特率前都要等它变 0，
 * 也是 fputc 与 usart_dma_send 互斥的关键信号。volatile 因为 ISR 里也会改写。 */
volatile uint8_t  g_usart_dma_tx_busy    = 0;

/* 上次"DMA 剩余传输计数"快照。IDLE 中断里拿它和当前计数比较，
 * 差值就是两帧之间新收到的字节数。初值=环长 表示环里尚无有效数据。 */
static uint16_t s_dma_rx_last_cnt = USART_DMA_RX_BUF_SIZE;

/* DMA 发送源缓冲：usart_dma_send() 先把要发的数据 memcpy 到这里，再交给 DMA 搬走。
 * 长度 1200：一次协议回包最长不超过 PROTO_RX_BUF_SIZE(=1024) 等上限，
 * 1200 留足余量；usart_dma_send() 里也用 len>1200 做了越界保护。 */
static uint8_t s_dma_tx_buf[1200];

/* ====================================================================================
 * 静态函数声明
 * ==================================================================================== */
static void dma_rx_init(void);
static void dma_tx_init(void);
static void usart_dma_rx_frame_extract(void);

/* ====================================================================================
 * 公共: 串口初始化 (GPIO + USART + DMA + IDLE中断)
 * ==================================================================================== */
/**
 * @brief 初始化USART串口通信
 * @param bound 波特率设置值
 * @note 该函数完成GPIO、USART、DMA和中断的初始化配置
 */
void usart_init(uint32_t bound)
{
    usart_tx_mutex_create();        /* 【FreeRTOS 改动】先创建串口发送互斥锁(调度器尚未启动，此时创建合法) */
    /* GPIO + USART 基础时钟 */
    rcu_periph_clock_enable(RCU_GPIOA);   /* 使能 GPIOA 时钟(PA9/PA10 在 PORTA) */
    rcu_periph_clock_enable(RCU_AF);      /* 使能复用功能时钟(串口复用必须开 AF) */
    rcu_periph_clock_enable(RCU_USART0);  /* 使能 USART0 时钟 */

    gpio_init(GPIOA, GPIO_MODE_AF_PP,      GPIO_OSPEED_50MHZ, GPIO_PIN_9);    /* PA9=TX：复用推挽输出 */
    gpio_init(GPIOA, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_10);  /* PA10=RX：浮空输入 */

    usart_deinit(USART0);               /* 复位 USART0 各寄存器到默认值 */
    usart_baudrate_set(USART0, bound);  /* 设波特率(默认 9600，运行中可由 BR 指令改) */
    usart_stop_bit_set(USART0, USART_STB_1BIT);   /* 停止位=1 位 */
    usart_word_length_set(USART0, USART_WL_8BIT); /* 数据位=8 位 */
    usart_parity_config(USART0, USART_PM_NONE);   /* 无校验 */
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);    /* 使能接收 */
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);/* 使能发送 */

    /* 用 IDLE 空闲中断代替"每字节中断"判帧：来字节不打扰 CPU，只在一帧发完(总线空闲)时进一次 ISR */
    usart_interrupt_enable(USART0, USART_INT_IDLE);
    nvic_irq_enable(USART0_IRQn, 3, 3);  /* 抢占优先级3/子优先级3：低于测频捕获中断(0/1)，不干扰测频 */

    /* 配置接收/发送两条 DMA 通道 */
    dma_rx_init();
    dma_tx_init();

    usart_enable(USART0);   /* 最后使能 USART0，开始收发 */
}

/* ====================================================================================
 * DMA0 CH4: USART0_RX → g_usart_dma_rx_buf (循环/环形模式)
 * ==================================================================================== */
static void dma_rx_init(void)
{
    rcu_periph_clock_enable(RCU_DMA0);   /* 使能 DMA0 时钟(收发都在 DMA0 上) */

    dma_deinit(DMA0, DMA_CH4);           /* 复位 DMA0 通道4 */

    dma_parameter_struct cfg;
    dma_struct_para_init(&cfg);
    cfg.periph_addr  = (uint32_t)(&USART_DATA(USART0));  /* 外设地址=USART0 数据寄存器(源) */
    cfg.memory_addr  = (uint32_t)g_usart_dma_rx_buf;     /* 内存地址=接收环形缓冲(目的) */
    cfg.direction    = DMA_PERIPHERAL_TO_MEMORY;         /* 方向：外设→内存(接收) */
    cfg.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;     /* 外设地址不自增：每次都写同一个数据寄存器 */
    cfg.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;      /* 内存地址自增：字节依次填进环形缓冲 */
    cfg.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;        /* 外设数据宽度=8 位(一字节) */
    cfg.memory_width = DMA_MEMORY_WIDTH_8BIT;           /* 内存数据宽度=8 位 */
    cfg.number       = USART_DMA_RX_BUF_SIZE;           /* 单次传输量=环长1024；循环模式下填满后自动回卷 */
    cfg.priority     = DMA_PRIORITY_HIGH;                /* 接收通道优先级高：丢一个字节就丢一帧 */
    dma_init(DMA0, DMA_CH4, &cfg);

    dma_circulation_enable(DMA0, DMA_CH4);   /* 开循环模式：传输计数到 0 后自动重装、地址回卷，永不停止 */
    dma_channel_enable(DMA0, DMA_CH4);       /* 使能 DMA0_CH4 */
    usart_dma_receive_config(USART0, USART_RECEIVE_DMA_ENABLE);  /* 让 USART0 收到字节后触发 DMA 写 */

    s_dma_rx_last_cnt = USART_DMA_RX_BUF_SIZE;   /* 复位"上次计数"快照：从满量(=刚启动)开始算 */
}

/* ====================================================================================
 * DMA0 CH3: s_dma_tx_buf → USART0_TX (单次模式，发完即停)
 * ==================================================================================== */
static void dma_tx_init(void)
{
    dma_deinit(DMA0, DMA_CH3);   /* 复位 DMA0 通道3 */

    dma_parameter_struct cfg;
    dma_struct_para_init(&cfg);
    cfg.periph_addr  = (uint32_t)(&USART_DATA(USART0));  /* 外设地址=USART0 数据寄存器(目的) */
    cfg.memory_addr  = (uint32_t)s_dma_tx_buf;           /* 内存地址=发送缓冲(源) */
    cfg.direction    = DMA_MEMORY_TO_PERIPHERAL;         /* 方向：内存→外设(发送) */
    cfg.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;     /* 外设地址不自增 */
    cfg.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;      /* 内存地址自增：依次取出发送缓冲里的字节 */
    cfg.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    cfg.memory_width = DMA_MEMORY_WIDTH_8BIT;
    cfg.number       = 0;                               /* 本通道循环模式不开，传输量每次由 usart_dma_send 现填 */
    cfg.priority     = DMA_PRIORITY_MEDIUM;             /* 发送优先级中：发送慢、丢帧也可重发，低于接收 */
    dma_init(DMA0, DMA_CH3, &cfg);

    dma_interrupt_enable(DMA0, DMA_CH3, DMA_INT_FTF);   /* 开"传输完成(FTF)"中断，发完清忙标志 */
    nvic_irq_enable(DMA0_Channel3_IRQn, 2, 2);           /* 抢占2/子2：高于 USART0_IDLE(3) */

    usart_dma_transmit_config(USART0, USART_TRANSMIT_DMA_ENABLE);  /* 让 USART0 发数据寄存器空时触发 DMA 读 */
}

/* ====================================================================================
 * DMA0 CH3 传输完成中断：一帧发完，清发送忙标志
 * ==================================================================================== */
void DMA0_Channel3_IRQHandler(void)
{
    if (dma_interrupt_flag_get(DMA0, DMA_CH3, DMA_INT_FLAG_FTF) != RESET)   /* FTF=整批数据已从内存搬到外设 */
    {
        dma_interrupt_flag_clear(DMA0, DMA_CH3, DMA_INT_FLAG_FTF);   /* 先清中断标志(否则会重复进) */
        dma_channel_disable(DMA0, DMA_CH3);                          /* 停通道：本通道是单次模式，发完即关 */
        g_usart_dma_tx_busy = 0;                                     /* 标记发送空闲，允许下一帧/fputc 再用 */
    }
}

/* ====================================================================================
 * 公共: 动态切换波特率 (对应上位机 BR 指令)
 * ==================================================================================== */
void usart_baud_set(uint32_t baud)
{
    /* 必须等"在发的最后一个字节真正发完"再改波特率，否则该字节的位时序会被改乱 */
    while (g_usart_dma_tx_busy);              /* 先等 DMA 把整帧提交完 */
    while (RESET == usart_flag_get(USART0, USART_FLAG_TC));  /* 再等 TC=移位寄存器空 */

    usart_baudrate_set(USART0, baud);         /* 写波特率分频寄存器 */
}

/* 函数: usart_parity_set
 * 功能: 动态切换校验位
 * 参数: parity —— 0=无校验, 1=奇校验, 2=偶校验
 * 说明: 帧格式位(PCEN/PM/WL)硬件规定必须在 UEN=0(USART 关闭)时才能改，
 *       所以先等发送结束→关 USART→改 CTL0→再开 USART。 */
void usart_parity_set(uint8_t parity)
{
    /* 等待当前发送完全结束:
     * 只等 g_usart_dma_tx_busy 不够 —— DMA 完成仅表示最后一个字节
     * 已写入发送数据寄存器, 移位寄存器还需约1个字符时间才发完.
     * 若不等 TC 就改帧格式, 正在发送的最后一个字节会被截断/损坏 */
    while (g_usart_dma_tx_busy);
    while (RESET == usart_flag_get(USART0, USART_FLAG_TC));

    /* 先停 USART: 帧格式位(PCEN/PM/WL)必须在 UEN=0 时修改 */
    usart_disable(USART0);

    /* 重新读取寄存器(此刻 UEN=0), 先清空三个位再按需设置 */
    {
        uint32_t ctl0 = USART_CTL0(USART0);
        ctl0 &= ~(USART_CTL0_PCEN | USART_CTL0_PM | USART_CTL0_WL);   /* 先把校验使能/校验极性/字长三位清零 */

        if (parity == 1)       /* 奇校验 */
        {
            ctl0 |= USART_CTL0_PCEN;   /* PCEN=1：使能硬件校验 */
            ctl0 |= USART_CTL0_PM;     /* PM=1：奇校验(奇=数据位+校验位中1的个数为奇数) */
            ctl0 |= USART_CTL0_WL;     /* WL=1：9位帧 = 8数据位 + 1校验位 */
        }
        else if (parity == 2)  /* 偶校验 */
        {
            ctl0 |= USART_CTL0_PCEN;   /* PCEN=1：使能校验 */
            ctl0 |= USART_CTL0_WL;     /* WL=1：9位=8数据+1校验(PM=0 即偶校验) */
        }
        /* parity=0 无校验：三位保持清空，回到 8 位数据、无校验 */

        /* UEN 仍为 0 时一次性写回配置 */
        USART_CTL0(USART0) = ctl0;
    }

    usart_enable(USART0);   /* 重新使能 USART，新帧格式生效 */

    /* 清掉切换窗口内可能置起的接收错误标志 (STAT0 bit0~3: PERR/FERR/NERR/ORERR),
     * 防止残留错误状态影响后续帧的接收判断 */
    USART_STAT0(USART0) &= ~(BIT(0) | BIT(1) | BIT(2) | BIT(3));
}

/* ====================================================================================
 * 公共: 动态切换数据位 (仅无校验时生效)
 *   data_bits: 0=8bit, 1=9bit
 *   校验使能时 WL 由 usart_parity_set 控制, 本函数不操作
 * ==================================================================================== */
void usart_data_bits_set(uint8_t data_bits)
{
    uint32_t ctl0 = USART_CTL0(USART0);

    /* 有校验时 WL 必须为 1 (8数据+1校验), 数据位设置无意义，直接返回 */
    if (ctl0 & USART_CTL0_PCEN)
        return;

    usart_disable(USART0);   /* 改字长同样要先关 USART */

    ctl0 = USART_CTL0(USART0);
    if (data_bits == 1)      /* 9bit 数据位 */
        ctl0 |= USART_CTL0_WL;
    else                     /* 8bit 数据位 */
        ctl0 &= ~USART_CTL0_WL;

    USART_CTL0(USART0) = ctl0;   /* 关 USART 状态下写回 */
    usart_enable(USART0);
}

/* ====================================================================================
 * 公共: 动态切换停止位
 *   stop_bits: 0=1bit, 1=2bit
 * ==================================================================================== */
void usart_stop_bits_set(uint8_t stop_bits)
{
    /* 等待在发字节完全结束, 避免改帧格式截断发送 */
    while (g_usart_dma_tx_busy);
    while (RESET == usart_flag_get(USART0, USART_FLAG_TC));

    usart_disable(USART0);

    if (stop_bits == 1)
        usart_stop_bit_set(USART0, USART_STB_2BIT);   /* 2 个停止位 */
    else
        usart_stop_bit_set(USART0, USART_STB_1BIT);   /* 1 个停止位(默认) */

    usart_enable(USART0);
}

/* ====================================================================================
 * 公共: DMA发送数据块（协议回包的统一出口）
 * ==================================================================================== */
/* 函数: usart_dma_send
 * 参数: buf —— 待发送数据首地址; len —— 长度(字节)
 * 说明: 先持发送互斥锁，把数据拷进 s_dma_tx_buf，再配 DMA0_CH3 一次搬完。
 *       锁只在"配置并启动 DMA"这一小段持有，发完由硬件在后台完成(异步)，
 *       不阻塞任务；发完靠 DMA 完成中断清 g_usart_dma_tx_busy。 */
void usart_dma_send(uint8_t *buf, uint16_t len)
{
    if (len == 0 || len > 1200) return;   /* 空包或超过 s_dma_tx_buf 容量(1200)直接丢弃 */

    usart_tx_lock();                    /* 【FreeRTOS 改动】整帧持锁, 防止被 printf 插字节 */
    while (g_usart_dma_tx_busy);   /* 等待上次发送完成(忙标志由 DMA 完成中断清零) */

    memcpy(s_dma_tx_buf, buf, len);   /* 拷进发送缓冲：DMA 必须从内存搬，不能直接指向调用者栈/堆 */

    dma_channel_disable(DMA0, DMA_CH3);                       /* 改 DMA 配置前必须先停通道 */
    dma_memory_address_config(DMA0, DMA_CH3, (uint32_t)s_dma_tx_buf);  /* 设源地址(每次重设，循环关闭后地址不自动回卷) */
    dma_transfer_number_config(DMA0, DMA_CH3, len);           /* 设本次传输长度 */

    g_usart_dma_tx_busy = 1;          /* 先置忙，再启动通道(顺序：先标忙再开，避免完成中断先到) */
    dma_channel_enable(DMA0, DMA_CH3);/* 启动 DMA，后台发送 */

    usart_tx_unlock();                  /* 放锁, DMA 后台继续发完(与原逻辑一样是异步的) */
}

/* ====================================================================================
 * USART0 IDLE 中断: 总线空闲 → 一帧结束
 *
 * 原理:
 *   DMA 持续把字节写入环形缓冲区(CPU 不参与逐字节)。
 *   当 RX 线连续空闲超过约 1 个字符时间，硬件自动置 IDLE 标志，进本中断。
 *   在中断里计算本帧新到字节数、从环形缓冲拷出、按帧头 '#' 路由到协议接收缓冲。
 *   这样上位机每发完一帧才进一次中断，而不是每字节进一次，CPU 占用极低。
 * ==================================================================================== */
void USART0_IRQHandler(void)
{
#if SYSTEM_SUPPORT_OS
    OSIntEnter();   /* 旧版移植钩子：通知 FreeRTOS"进入中断"。本工程该宏通常未定义，此段不参与编译 */
#endif

    if (usart_interrupt_flag_get(USART0, USART_INT_FLAG_IDLE) != RESET)   /* 只处理 IDLE(空闲)事件 */
    {
        /* 读STAT0检查错误标志, 再读DATA清IDLE。
         * GD32/STM32 系要求：清 IDLE 的顺序是"先读 STAT0，再读 DATA"，两读完成硬件清零 */
        volatile uint32_t stat = USART_STAT0(USART0);
        volatile uint32_t data = USART_DATA(USART0);
        (void)data;   /* 读 DATA 仅为清 IDLE，不需要其值，这里显式忽略避免警告 */

        /* bit0=PERR(校验错) bit1=FERR(帧错) bit2=NERR(噪声) bit3=ORERR(溢出) */
        if (stat & (BIT(0) | BIT(1) | BIT(2) | BIT(3)))
        {
            /* 有校验/帧/噪声/溢出错误 → 本帧数据不可信，丢弃：只把"上次计数"对齐到当前，不提取 */
            s_dma_rx_last_cnt = dma_transfer_number_get(DMA0, DMA_CH4);
        }
        else
        {
            /* 无错误 → 正常从环形缓冲提取一帧 */
            usart_dma_rx_frame_extract();
            LED1_TOGGLE();   /* 翻转 LED1：有合法串口帧进出的运行指示 */
        }
    }

#if SYSTEM_SUPPORT_OS
    OSIntExit();    /* 旧版移植钩子：通知"退出中断"，必要时触发一次任务调度 */
#endif
}

/* ====================================================================================
 * 静态: 从DMA环形缓冲区提取一帧
 *
 * DMA CHCNT(剩余传输计数)是向下递减的。
 *   本次新到字节数 rx_len = (last - curr + SIZE) % SIZE
 *     · 若 last>=curr(没回卷)：rx_len = last - curr；
 *     · 若 last<curr(中间计数回卷过)：rx_len = SIZE - curr + last。
 *   读取起始位置 start = (SIZE - last) % SIZE：
 *     "last 时已传输数 = SIZE - last"，即最早未被消费的那个字节在环里的下标。
 *
 * 路由:
 *   首字节 '#' 或当前缓冲在拼新帧 → 按"新帧覆盖 / 续帧追加"拷进 g_proto_rx_buf；
 *   拷完扫描是否含 '\r'(0x0D)，含则认为一帧完整，置 g_proto_frame_ready 通知 ProtocolTask。
 * ==================================================================================== */
static void usart_dma_rx_frame_extract(void)
{
    uint16_t curr_cnt = dma_transfer_number_get(DMA0, DMA_CH4);   /* 当前 DMA 剩余计数 */
    uint16_t last_cnt = s_dma_rx_last_cnt;                        /* 上次记录的剩余计数 */
    uint16_t rx_len;
    uint16_t start;
    uint16_t i;

    /* 两帧之间新到的字节数：按计数方向(递减)分两种情况算差值，自动处理回卷 */
    if (last_cnt >= curr_cnt)
        rx_len = last_cnt - curr_cnt;                 /* 本帧期间计数未回卷：直接相减 */
    else
        rx_len = USART_DMA_RX_BUF_SIZE - curr_cnt + last_cnt;   /* 计数从 SIZE 回卷到 0 附近：环长补差 */

    s_dma_rx_last_cnt = curr_cnt;   /* 更新"上次计数"为本帧的当前值，供下帧计算 */

    if (rx_len == 0) return;        /* 没有新字节(IDLE 误触发/纯噪声)，直接退出 */

    /* 本帧最早那个字节在环形缓冲里的下标：last 时刻已传输 (SIZE-last) 个字节 */
    start = (USART_DMA_RX_BUF_SIZE - last_cnt) % USART_DMA_RX_BUF_SIZE;

    /* ---- 帧路由：判断是新帧开头还是上一帧的延续 ---- */
    {
        uint8_t first = g_usart_dma_rx_buf[start];   /* 本帧首字节 */

        /* 首字节是协议帧头 '#'，或当前正在拼一帧(索引>0)时按续帧处理 */
        if (first == '#' || g_proto_rx_idx == 0)
        {
            /* === 新帧: 从缓冲头部开始覆盖旧内容 === */
            if (rx_len < PROTO_RX_BUF_SIZE)   /* 不越界才拷 */
            {
                for (i = 0; i < rx_len; i++)
                    /* 环形取下标：(start+i) 可能越过环尾，对 SIZE 取模回卷到头部 */
                    g_proto_rx_buf[i] = g_usart_dma_rx_buf[(start + i) % USART_DMA_RX_BUF_SIZE];
                g_proto_rx_idx = rx_len;      /* 写入索引移到本帧末尾 */
            }
        }
        else
        {
            /* === 续帧: 追加到已有 g_proto_rx_buf 后面(一帧被拆成多次IDLE到达) === */
            uint16_t new_len = g_proto_rx_idx + rx_len;
            if (new_len < PROTO_RX_BUF_SIZE)   /* 拼完后仍不越界才追加 */
            {
                for (i = 0; i < rx_len; i++)
                    g_proto_rx_buf[g_proto_rx_idx + i] = g_usart_dma_rx_buf[(start + i) % USART_DMA_RX_BUF_SIZE];
                g_proto_rx_idx = new_len;
            }
        }
    }

    /* 协议帧以 '\r'(0x0D) 结尾；只有收齐到 '\r' 才算完整帧，才通知主循环去解析执行 */
    {
        uint8_t has_cr = 0;
        for (i = 0; i < g_proto_rx_idx; i++)
        {
            if (g_proto_rx_buf[i] == 0x0D) { has_cr = 1; break; }   /* 找到回车即认为帧完整 */
        }
        if (has_cr) g_proto_frame_ready = 1;   /* 置就绪标志，ProtocolTask 轮询到后解析回包 */
    }
}
