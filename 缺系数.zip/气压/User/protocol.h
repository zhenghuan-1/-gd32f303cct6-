/**
 * ====================================================================================
 * @file     protocol.h
 * @brief    串口通信协议模块 - ASCII助记符指令 + XOR校验
 * ====================================================================================
 *
 * 帧格式:
 *   请求: #01XX<CMD>[DATA]\r<CKSUM>
 *   响应: *01XX<DATA>\r\n<CKSUM>
 *
 *   CKSUM = XOR(帧头..\r前一个字节) , 2 ASCII hex 大写字符, 放在帧尾
 *
 * 指令码:
 *   读指令: 2 ASCII 字符 (ST, VG, P3, T3, H3, F5, SN, FS, BR, PR)
 *   写指令: 3 ASCII 字符 (ACC, ADR, EWO, PPI, PAA, PMB, TPC), ID 为 2 字符
 * ====================================================================================
 */

#ifndef __PROTOCOL_H__
#define __PROTOCOL_H__

#include "gd32f30x.h"

/* ====================================================================================
 * 常量定义
 * ==================================================================================== */
#define PROTO_RX_BUF_SIZE      64       /* 接收缓冲(含帧头+\r+校验和) */
#define PROTO_TX_BUF_SIZE      128      /* 发送缓冲 */
#define PROTO_DEV_ADDR         0x01     /* 本机设备地址 */
#define PROTO_FW_VERSION       "XSTK-GQY03-2026.01"   /* 固件默认版本号 */

/* ====================================================================================
 * 内部Flash存储配置 (GD32F303CCT6 256KB, 代码区226KB + 配置区30KB)
 *
 * 代码区: 0x08000000 ~ 0x080387FF (226KB, IROM1 Size=0x38800)
 * 配置区: 0x08038800 ~ 0x0803FBFF (15页×2KB = 30KB)
 *
 * 布局 (已用9页, 预留6页):
 *   页 0: 0x08038800  加法器一区 (生效)
 *   页 1: 0x08039000  加法器二区 (待生效)
 *   页 2: 0x08039800  乘法器一区 (生效)
 *   页 3: 0x0803A000  乘法器二区 (待生效)
 *   页 4: 0x0803A800  序列号
 *   页 5: 0x0803B000  版本号
 *   页 6: 0x0803B800  运行参数
 *   页 7: 0x0803C000  站号
 *   页 8: 0x0803C800  分辨率
 *   页 9~14: 预留 (6页 = 12KB)
 * ==================================================================================== */
#define INTFLASH_BASE           0x08038800UL            /* 内部Flash配置区基址 (15页) */
#define INTFLASH_PAGE_SIZE      2048UL                  /* 内部Flash页大小 2KB (GD32F303CCT6) */

/* Flash 校准区 */
#define FLASH_CALIB_ADDER1_ADDR (INTFLASH_BASE + 0 * INTFLASH_PAGE_SIZE)   /* 0x08038800 加法器一区(生效) */
#define FLASH_CALIB_ADDER2_ADDR (INTFLASH_BASE + 1 * INTFLASH_PAGE_SIZE)   /* 0x08039000 加法器二区(待生效) */
#define FLASH_CALIB_MULT1_ADDR  (INTFLASH_BASE + 2 * INTFLASH_PAGE_SIZE)   /* 0x08039800 乘法器一区(生效) */
#define FLASH_CALIB_MULT2_ADDR  (INTFLASH_BASE + 3 * INTFLASH_PAGE_SIZE)   /* 0x0803A000 乘法器二区(待生效) */
#define FLASH_CALIB_MAGIC       0xA5F3                  /* 魔数, 标识有效校准数据 */

/* Flash 序列号存储 */
#define FLASH_SERIAL_ADDR       (INTFLASH_BASE + 4 * INTFLASH_PAGE_SIZE)   /* 0x0803A800 */
#define FLASH_SERIAL_MAGIC      0xA5F3                  /* 魔数, 标识有效记录 */

/* Flash 版本号存储 */
#define FLASH_STORE_ADDR        (INTFLASH_BASE + 5 * INTFLASH_PAGE_SIZE)   /* 0x0803B000 */
#define FLASH_STORE_MAGIC       0xA5F3                  /* 魔数, 标识有效配置 */

/* Flash 运行参数存储 (磨损均衡, 每页64条) */
#define FLASH_CFG_ADDR          (INTFLASH_BASE + 6 * INTFLASH_PAGE_SIZE)   /* 0x0803B800 */
#define FLASH_CFG_MAGIC         0xA5F3                  /* 魔数, 与版本号共用 */

/* Flash 站号独立存储 */
#define FLASH_STATION_ADDR      (INTFLASH_BASE + 7 * INTFLASH_PAGE_SIZE)   /* 0x0803C000 */

/* Flash 分辨率独立存储 */
#define FLASH_RESOLUTION_ADDR   (INTFLASH_BASE + 8 * INTFLASH_PAGE_SIZE)   /* 0x0803C800 */
#define FLASH_RESOLUTION_MAGIC  0xA5F3                  /* 魔数, 标识有效记录 */

/* Flash 精度独立存储 (PW/PS/PT) */
#define FLASH_PRECISION_PW_ADDR (INTFLASH_BASE + 9 * INTFLASH_PAGE_SIZE)   /* 0x0803D000 PW精度 */
#define FLASH_PRECISION_PS_ADDR (INTFLASH_BASE + 10 * INTFLASH_PAGE_SIZE)  /* 0x0803D800 PS精度 */
#define FLASH_PRECISION_PT_ADDR (INTFLASH_BASE + 11 * INTFLASH_PAGE_SIZE)  /* 0x0803E000 PT精度 */
#define FLASH_PRECISION_MAGIC   0xA5F3                  /* 魔数, 标识有效记录 */

/* Flash 气压上限独立存储 */
#define FLASH_PRESSURE_LIMIT_ADDR (INTFLASH_BASE + 12 * INTFLASH_PAGE_SIZE) /* 0x0803E800 气压上限 */
#define FLASH_PRESSURE_LIMIT_MAGIC 0xA5F3               /* 魔数, 标识有效记录 */

/* 预留: 页 13~14 (0x0803F000 ~ 0x0803FBFF) 共2页 = 4KB */

/* 配置区内偏移 */
#define FLASH_CFG_OFF_BAUD      3                       /* 波特率 uint32_t */
#define FLASH_CFG_OFF_STATION   7                       /* 站号 uint8_t   */
#define FLASH_CFG_OFF_PARITY    8                       /* 校验位 uint8_t (0=无 1=奇 2=偶) */
#define FLASH_CFG_OFF_DATA_BITS 9                       /* 数据位 uint8_t (0=8bit 1=9bit) */
#define FLASH_CFG_OFF_STOP_BITS 10                      /* 停止位 uint8_t (0=1bit 1=2bit) */
#define FLASH_CFG_RECORD_SIZE   32                      /* 每条记录 32 字节 */
#define FLASH_CFG_MAX_RECORDS   (INTFLASH_PAGE_SIZE / FLASH_CFG_RECORD_SIZE)  /* 每页 64 条 */

/* 校验位常量 */
#define PROTO_PARITY_NONE       0
#define PROTO_PARITY_ODD        1
#define PROTO_PARITY_EVEN       2

/* 数据位常量 */
#define PROTO_DATA_BITS_8       0
#define PROTO_DATA_BITS_9       1

/* 停止位常量 */
#define PROTO_STOP_BITS_1       0
#define PROTO_STOP_BITS_2       1

/* ====================================================================================
 * 指令类型枚举
 * ==================================================================================== */
typedef enum {
    CMD_TYPE_READ_2  = 0,   /* 2字符读指令 */
    CMD_TYPE_WRITE_2 = 1,   /* 2字符写指令 (仅 ID) */
    CMD_TYPE_WRITE_3 = 2,   /* 3字符写指令 */
} proto_cmd_type_t;

/* ====================================================================================
 * 指令表条目结构
 * ==================================================================================== */
typedef struct {
    const char     *code;           /* 指令字符串 (2或3字符) */
    uint8_t         len;            /* 指令长度: 2 或 3 */
    proto_cmd_type_t type;          /* 读/写类型 */
    void          (*handler)(uint8_t station, const char *data, uint8_t data_len);
                                    /* 处理函数: 站号 + 数据指针 + 数据长度 */
} proto_cmd_entry_t;

/* ====================================================================================
 * ISR 接口变量 (由 usart.c 中断服务程序操作)
 * ==================================================================================== */
extern volatile uint8_t  g_proto_rx_buf[PROTO_RX_BUF_SIZE];   /* 协议帧接收缓冲 */
extern volatile uint8_t  g_proto_rx_idx;                       /* 缓冲写入索引 */
extern volatile uint8_t  g_proto_rx_mode;                      /* 1=正在接收协议帧 */
extern volatile uint8_t  g_proto_rx_need_cksum;                /* \r后还需收的字节数(0/2) */
extern volatile uint8_t  g_proto_frame_ready;                  /* 1=完整帧就绪 */

/* ====================================================================================
 * 公共函数声明
 * ==================================================================================== */
void protocol_init(void);              /* 模块初始化 */
void protocol_process(void);           /* 主循环调用: 解析帧→执行→发送响应 */

/* ====================================================================================
 * 辅助函数 (供内部使用, 也可外部调用)
 * ==================================================================================== */
uint8_t proto_xor_checksum(const uint8_t *buf, uint8_t len);  /* 计算XOR校验和 */
void    proto_send_response(const char *data);                 /* 发送响应帧 */
void    proto_send_str(const char *str);                       /* 裸发字符串(不带帧包装) */
uint8_t proto_get_stream_enable(void);                         /* SC流式输出开关状态 */

/* Flash 版本号存储 */
void        flash_store_init(void);          /* 上电初始化: 从Flash读版本, 首次写默认 */
const char* flash_store_version(void);       /* 返回当前版本号 */

/* Flash 运行参数存储 */
void        flash_cfg_init(void);            /* 上电加载配置; 首次写默认; 并切换波特率 */
uint32_t    flash_cfg_get_baud(void);        /* 返回已保存的波特率 */
uint8_t     flash_cfg_get_parity(void);      /* 返回已保存的校验位 */
uint8_t     flash_cfg_get_data_bits(void);   /* 返回已保存的数据位 */
uint8_t     flash_cfg_get_stop_bits(void);   /* 返回已保存的停止位 */

/* Flash 站号独立存储 */
void        flash_station_init(void);         /* 上电加载站号 */
void        flash_station_save(void);         /* 保存站号到独立扇区 */

/* Flash 分辨率独立存储 */
void        flash_resolution_init(void);       /* 上电加载分辨率 → 更新 g_target_ref_count */
void        flash_resolution_save(void);       /* 保存分辨率到独立扇区 */
uint8_t     flash_resolution_get_idx(void);    /* 返回当前分辨率索引 (0~9) */

/* Flash 校准参数 (加法器/乘法器, 双区机制) */
void        flash_calib_init(void);            /* 上电: 读一区, 检查二区合并 */
float       proto_get_calib_adder(void);       /* 返回当前生效的加法器值 */
float       proto_get_calib_mult(void);        /* 返回当前生效的乘法器值 */
float       proto_get_pressure_limit(void);    /* 返回当前气压上限 */

#endif /* __PROTOCOL_H__ */
