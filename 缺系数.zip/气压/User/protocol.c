/* ====================================================================================
 * 文件: protocol.c
 * 描述: 串口通信协议模块 - ASCII助记符指令解析 + XOR校验 + 响应构建
 * ====================================================================================
 *
 * 【协议格式说明】
 *   请求帧: #01XX<CMD>[DATA]\r<CKSUM>
 *     - #      : 帧头，固定为 #
 *     - 01     : 设备地址，固定为 01
 *     - XX     : 站号，2字符HEX，默认00
 *     - CMD    : 指令码，2字符(读)或3字符(写)
 *     - DATA   : 数据部分，可选
 *     - \r     : 回车，帧结束符
 *     - CKSUM  : 校验和，2字符HEX大写，XOR(帧头到\r前所有字节)
 *
 *   响应帧: *01XX<DATA>\r\n<CKSUM>
 *     - *      : 帧头，固定为 *
 *     - 01     : 设备地址
 *     - XX     : 站号
 *     - DATA   : 响应数据
 *     - \r\n   : 回车换行
 *     - CKSUM  : 校验和
 *
 * 【XOR校验说明】
 *   XOR(异或)运算：相同为0，不同为1
 *   计算方法：将所有字节逐个异或，得到校验值
 *   示例：0x01 XOR 0x02 XOR 0x03 = 0x00
 *
 * 【指令分类】
 *   读指令：2字符，如P3、F5、ST等，读取数据
 *   写指令：3字符，如ACC、PAA、PMB等，写入数据
 *   特殊指令：EW(写入使能)、ID(写序列号)
 *
 * 【写入使能(EW)机制】
 *   写入Flash前必须先发送EW指令
 *   一次EW只能写一个指令，写完自动失效
 *   防止误操作导致Flash被意外修改
 *
 * ==================================================================================== */

#include "protocol.h"
#include "usart.h"
#include "freq_measure.h"
#include "pressure_calc.h"

/* 主循环缓存的频率值 (避免 re-calculate 拿到已清零的数据) */
extern uint32_t g_freq_ch1_x1000;
extern uint32_t g_freq_ch2_x1000;
#include "adc.h"
#include "dac.h"
#include "gd32f30x_fmc.h"
#include "gd32f30x_bkp.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ====================================================================================
 * 内部Flash读写封装
 *
 * 【GD32F303CCT6 内部Flash特性】
 *   - 页大小: 2KB (2048字节)
 *   - 写入: 按32位字(4字节)，只能 1→0，不能 0→1 (需先擦除)
 *   - 擦除: 按页，耗时~2ms，期间CPU暂停
 *   - 擦写时需关中断保护，防止中断打断导致数据损坏
 *
 * 【Flash地址布局】
 *   代码区: 0x08000000 ~ 0x080387FF (227KB)
 *   配置区: 0x08038800 ~ 0x0803FBFF (30KB，15页)
 *
 * ==================================================================================== */

/* 内部Flash读取
 * 参数: pbuf-读取缓冲区, addr-Flash地址, len-读取长度
 * 说明: Flash读取就是直接内存访问，不需要特殊操作
 */
static void intflash_read(uint8_t *pbuf, uint32_t addr, uint16_t len)
{
    memcpy(pbuf, (const void *)addr, len);
}

/* 内部Flash页擦除
 * 参数: page_addr-页起始地址
 * 说明: 擦除整页(2KB)，所有字节变为0xFF
 *       擦除期间CPU暂停，需要关中断保护
 *       __DSB/__ISB是ARM屏障指令，确保操作完成
 */
static void intflash_erase_page(uint32_t page_addr)
{
    __disable_irq();                        /* 关中断，防止打断 */
    fmc_unlock();                           /* 解锁Flash控制器 */
    fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT); /* 等待Flash就绪 */
    fmc_page_erase(page_addr);              /* 擦除整页 */
    fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT); /* 等待擦除完成 */
    fmc_lock();                             /* 锁定Flash控制器 */
    __enable_irq();                         /* 开中断 */
    __DSB();                                /* 数据同步屏障 */
    __ISB();                                /* 指令同步屏障 */
}

/* 内部Flash写入
 * 参数: pbuf-写入数据, addr-Flash地址, len-写入长度
 * 说明: 按32位字写入，需要4字节对齐
 *       写入前必须先擦除(只能1→0，不能0→1)
 *       写入期间CPU暂停，需要关中断保护
 */
static void intflash_write(const uint8_t *pbuf, uint32_t addr, uint16_t len)
{
    uint32_t i;
    __disable_irq();                        /* 关中断 */
    fmc_unlock();                           /* 解锁Flash */
    for (i = 0; i < len; i += 4)            /* 按4字节循环 */
    {
        uint32_t word = 0xFFFFFFFF;         /* 默认值0xFF(空) */
        uint16_t remaining = len - i;       /* 剩余字节数 */
        if (remaining >= 4)
            memcpy(&word, pbuf + i, 4);     /* 完整4字节 */
        else
            memcpy(&word, pbuf + i, remaining); /* 不足4字节，高位补0xFF */
        fmc_word_program(addr + i, word);   /* 写入一个字 */
        fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT); /* 等待写入完成 */
    }
    fmc_lock();                             /* 锁定Flash */
    __enable_irq();                         /* 开中断 */
    __DSB();                                /* 数据同步屏障 */
    __ISB();                                /* 指令同步屏障 */
}

/* ====================================================================================
 * ISR 接口变量定义
 * 说明: 这些变量在串口中断服务程序(ISR)中修改，在主循环中读取
 *       使用volatile关键字防止编译器优化
 * ==================================================================================== */
volatile uint8_t  g_proto_rx_buf[PROTO_RX_BUF_SIZE];  /* 接收缓冲区，存放收到的数据 */
volatile uint8_t  g_proto_rx_idx        = 0;          /* 接收索引，当前收到的字节位置 */
volatile uint8_t  g_proto_rx_mode       = 0;          /* 接收状态机: 0=空闲, 1=正在接收 */
volatile uint8_t  g_proto_rx_need_cksum = 0;          /* 是否需要校验和: 0=不需要, 1=需要 */
volatile uint8_t  g_proto_frame_ready   = 0;          /* 帧就绪标志: 0=未就绪, 1=收到完整帧 */

/* ====================================================================================
 * 模块内部变量
 * 说明: 这些变量只在本文件内使用，外部无法访问
 *       使用static关键字限制作用域
 * ==================================================================================== */
static uint8_t   s_station      = 0;      /* 当前设备站号 (0~255) */
static char      s_serial[16]   = "XSTK00000000";  /* 序列号，格式: XSTK + 8位后缀 */
static char      s_tx_buf[PROTO_TX_BUF_SIZE];   /* 发送缓冲区，存放要发送的数据 */

/* Flash 版本号存储 */
static char      s_fw_version[24] = PROTO_FW_VERSION;  /* 当前固件版本号 */

/* Flash 运行参数 */
static uint32_t  s_baud_rate    = 9600;   /* 串口波特率，可选: 2400/4800/9600/19200等 */
static uint8_t   s_parity       = PROTO_PARITY_NONE; /* 校验位: 0=无校验, 1=奇校验, 2=偶校验 */
static uint8_t   s_data_bits    = PROTO_DATA_BITS_8;  /* 数据位: 8位或9位 */
static uint8_t   s_stop_bits    = PROTO_STOP_BITS_1;  /* 停止位: 1位或2位 */

/* 允许的波特率列表 */
static const uint32_t s_baud_table[] = {2400, 4800, 9600, 19200, 38400, 57600, 115200};
#define BAUD_TABLE_SIZE  (sizeof(s_baud_table) / sizeof(s_baud_table[0]))

/* 【校准参数说明】
 * 加法器和乘法器用于校准气压值
 * 计算公式: 最终气压 = 原始气压 × 乘法器 + 加法器
 *
 * 【双区存储机制】
 * 一区(生效区): 当前正在使用的校准值
 * 二区(待生效区): 新写入的校准值，下次上电时合并到一区
 *
 * 合并规则:
 *   加法器: 一区值 + 二区值 → 一区值
 *   乘法器: 一区值 × 二区值 → 一区值
 *
 * 这样设计的好处:
 *   1. 可以累积多个校准值
 *   2. 防止误操作直接覆盖生效值
 *   3. 重启后自动合并，无需手动操作
 */
static float     s_calib_adder  = 0.0f;   /* 加法器校准值 (PAA指令写入) */
static float     s_calib_mult   = 1.0f;   /* 乘法器校准值 (PMB指令写入) */
static float     s_range_low    = 0.0f;   /* 量程下限 (暂未使用) */
static float     s_range_high   = 1000.0f;/* 量程上限 (暂未使用) */

/* 【精度存储说明】
 * PW/PS/PT分别代表不同类型的精度
 * 精度值: 0=0.0‰, 1=0.1‰, 2=0.2‰, 3=0.3‰
 * 单位是千分号(‰)，用/1000表示
 */
static uint8_t   s_precision_pw = 0;      /* PW精度 (压力精度?) */
static uint8_t   s_precision_ps = 0;      /* PS精度 */
static uint8_t   s_precision_pt = 0;      /* PT精度 */

/* 【气压上限说明】
 * 当气压值超过上限时，按上限值输出
 * 防止异常高气压值导致显示溢出
 * 默认值: 10000 (单位取决于气压计算模块)
 */
static float     s_pressure_limit = 10000.0f; /* 气压上限 (默认10000) */

/* 【写入使能标志说明】
 * 为了防止误操作修改Flash，所有写入Flash的指令
 * 都需要先发送EW指令使能
 * 一次EW只能写一个指令，写完自动失效
 * 这样即使误发写入指令，也不会损坏Flash数据
 */
static uint8_t   s_write_enable = 0;      /* EW指令使能标志: 0=禁止, 1=允许 */
/* 【分辨率查表说明】
 * 分辨率决定频率测量的精度和速度
 * 分辨率越高(数值越小)，测量越快，但精度越低
 * 分辨率越低(数值越大)，测量越慢，但精度越高
 *
 * 闸门时间 = 参考计数值 / 12000000 (12MHz时钟)
 * 例如: 12000000 / 12000000 = 1秒闸门时间
 */
#define RESOLUTION_IDX_DEFAULT   6           /* 默认分辨率索引: "1" (100ms闸门) */
#define RESOLUTION_TABLE_SIZE    10          /* 分辨率表大小 */

/* 分辨率名称字符串 (用于协议显示和解析) */
static const char *s_resolution_names[RESOLUTION_TABLE_SIZE] = {
    "1/100", "1/50", "1/20", "1/10", "1/5", "1/2", "1", "2", "5", "10"
};

/* 对应闸门参考计数值 (系统时钟12MHz)
 * 计数越大，闸门时间越长，测量精度越高
 */
static const uint32_t s_resolution_ref_counts[RESOLUTION_TABLE_SIZE] = {
       120000UL,    /* 1/100 → 1ms闸门   (最快，精度最低) */
       240000UL,    /* 1/50  → 2ms闸门   */
       600000UL,    /* 1/20  → 5ms闸门   */
      1200000UL,    /* 1/10  → 10ms闸门  */
      2400000UL,    /* 1/5   → 20ms闸门  */
      6000000UL,    /* 1/2   → 50ms闸门  */
     12000000UL,    /* 1     → 100ms闸门 (默认) */
     24000000UL,    /* 2     → 200ms闸门  */
     60000000UL,    /* 5     → 500ms闸门  */
    120000000UL,    /* 10    → 1s闸门    (最慢，精度最高) */
};

static uint8_t  s_resolution_idx = RESOLUTION_IDX_DEFAULT;  /* 当前分辨率索引 */
static float     s_accuracy     = 0.1f;   /* 精度值 (暂未使用) */
static uint8_t   s_eeprom_en    = 0;      /* EEPROM写使能标志 (暂未使用) */
static uint8_t   s_stream_enable = 0;     /* 串口自动流式输出开关: 0=关, 1=开 */
static float     s_mult_merged_val = 0.0f; /* 调试用: 记录合并后的乘法器值 */

/* ====================================================================================
 * 静态函数声明(前向)
 * ==================================================================================== */
static void flash_serial_init(void);
static void flash_serial_save(void);
static void flash_calib_save_adder_zone2(float val);
static void flash_calib_save_mult_zone2(float val);
static uint8_t calib_read_zone(uint32_t addr, float *out);
static void handler_st (uint8_t station, const char *data, uint8_t data_len);
static void handler_vg (uint8_t station, const char *data, uint8_t data_len);
static void handler_p3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_h3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_f5 (uint8_t station, const char *data, uint8_t data_len);
static void handler_sn_read (uint8_t station, const char *data, uint8_t data_len);
static void handler_fs (uint8_t station, const char *data, uint8_t data_len);
static void handler_dr (uint8_t station, const char *data, uint8_t data_len);
static void handler_br (uint8_t station, const char *data, uint8_t data_len);
static void handler_pt (uint8_t station, const char *data, uint8_t data_len);
static void handler_bt (uint8_t station, const char *data, uint8_t data_len);
static void handler_sb (uint8_t station, const char *data, uint8_t data_len);
static void handler_p1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_pr (uint8_t station, const char *data, uint8_t data_len);
static void handler_acc (uint8_t station, const char *data, uint8_t data_len);
static void handler_adr (uint8_t station, const char *data, uint8_t data_len);
static void handler_ew (uint8_t station, const char *data, uint8_t data_len);
static void handler_ewo (uint8_t station, const char *data, uint8_t data_len);
static void handler_ppi (uint8_t station, const char *data, uint8_t data_len);
static void handler_paa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pmb (uint8_t station, const char *data, uint8_t data_len);

/* 精度Flash操作 */
static uint8_t flash_precision_read(uint32_t addr, uint8_t *val);
static void flash_precision_save(uint32_t addr, uint8_t val);
static void flash_precision_init(void);

/* 气压上限Flash操作 */
static uint8_t flash_pressure_limit_read(float *val);
static void flash_pressure_limit_save(float val);
static void flash_pressure_limit_init(void);
static void handler_tpc (uint8_t station, const char *data, uint8_t data_len);
static void handler_wvr (uint8_t station, const char *data, uint8_t data_len);
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len);
static void handler_sc (uint8_t station, const char *data, uint8_t data_len);
static void handler_pa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pm (uint8_t station, const char *data, uint8_t data_len);
static void handler_md (uint8_t station, const char *data, uint8_t data_len);
static void handler_ut (uint8_t station, const char *data, uint8_t data_len);

/* ====================================================================================
 * 指令表
 * 说明: 定义所有支持的指令，包括指令码、长度、类型和处理函数
 *       指令表按长度降序排列(3字符在前，2字符在后)，便于解析匹配
 *
 * 指令类型:
 *   CMD_TYPE_READ_2  : 2字符读指令，如P3、F5、ST等
 *   CMD_TYPE_WRITE_2 : 2字符写指令，如ID
 *   CMD_TYPE_WRITE_3 : 3字符写指令，如ACC、PAA、PMB等
 *
 * 每条指令的结构:
 *   - 指令码: 2或3个字符
 *   - 长度: 指令码的字符数
 *   - 类型: 读指令或写指令
 *   - 处理函数: 收到该指令时调用的函数
 * ==================================================================================== */
static const proto_cmd_entry_t s_cmd_table[] = {
    /* ---- 3字符写指令 (需要EW使能) ---- */
    { "ACC", 3, CMD_TYPE_WRITE_3, handler_acc },   /* 写精度值 */
    { "ADR", 3, CMD_TYPE_WRITE_3, handler_adr },   /* 写站号 */
    { "EWO", 3, CMD_TYPE_WRITE_3, handler_ewo },   /* 写EEPROM使能 */
    { "PPI", 3, CMD_TYPE_WRITE_3, handler_ppi },   /* 写分辨率 */
    { "PAA", 3, CMD_TYPE_WRITE_3, handler_paa },   /* 写加法器校准 */
    { "PMB", 3, CMD_TYPE_WRITE_3, handler_pmb },   /* 写乘法器校准 */
    { "TPC", 3, CMD_TYPE_WRITE_3, handler_tpc },   /* 写标定系数 */
    { "WVR", 3, CMD_TYPE_WRITE_3, handler_wvr },   /* 写版本号 */

    /* ---- 2字符读指令 (无需EW) ---- */
    { "ST", 2, CMD_TYPE_READ_2,  handler_st },     /* 读状态(通讯检验) */
    { "VG", 2, CMD_TYPE_READ_2,  handler_vg },     /* 读版本号 */
    { "P3", 2, CMD_TYPE_READ_2,  handler_p3 },     /* 读气压值 */
    { "T3", 2, CMD_TYPE_READ_2,  handler_t3 },     /* 读温度值 */
    { "H3", 2, CMD_TYPE_READ_2,  handler_h3 },     /* 读高度值 */
    { "F5", 2, CMD_TYPE_READ_2,  handler_f5 },     /* 读频率(5个F1+5个F2) */
    { "SN", 2, CMD_TYPE_READ_2,  handler_sn_read },/* 读序列号 */
    { "FS", 2, CMD_TYPE_READ_2,  handler_fs },     /* 读精度值 */
    { "BR", 2, CMD_TYPE_READ_2,  handler_br },     /* 读/写波特率 */
    { "DR", 2, CMD_TYPE_READ_2,  handler_dr },     /* 读站号 */
    { "PT", 2, CMD_TYPE_READ_2,  handler_pt },     /* 读/写校验位 */
    { "BT", 2, CMD_TYPE_READ_2,  handler_bt },     /* 读数据位 */
    { "SB", 2, CMD_TYPE_READ_2,  handler_sb },     /* 读/写停止位 */
    { "P1", 2, CMD_TYPE_READ_2,  handler_p1 },     /* 读详细数据(频率+气压) */
    { "T1", 2, CMD_TYPE_READ_2,  handler_t1 },     /* 读详细数据(频率+温度) */
    { "PR", 2, CMD_TYPE_READ_2,  handler_pr },     /* 读/写分辨率 */
    { "SC", 2, CMD_TYPE_READ_2,  handler_sc },     /* 串口流式输出开关 */
    { "PA", 2, CMD_TYPE_READ_2,  handler_pa },     /* 读加法器(一区+二区) */
    { "PM", 2, CMD_TYPE_READ_2,  handler_pm },     /* 读乘法器(一区+二区) */
    { "MD", 2, CMD_TYPE_READ_2,  handler_md },     /* 读调试信息 */
    { "UT", 2, CMD_TYPE_READ_2,  handler_ut },     /* 读/写气压上限 */
    { "EW", 2, CMD_TYPE_READ_2,  handler_ew },     /* 写入使能 */

    /* ---- 2字符写指令 (需要EW使能) ---- */
    { "ID", 2, CMD_TYPE_WRITE_2, handler_id_write },/* 写序列号 */
};

#define CMD_TABLE_SIZE  (sizeof(s_cmd_table) / sizeof(s_cmd_table[0]))

/* ====================================================================================
 * 公共函数: 模块初始化
 * 说明: 系统启动时调用，从Flash加载所有配置参数
 *       按顺序加载各个配置项，确保依赖关系正确
 * ==================================================================================== */
void protocol_init(void)
{
    uint8_t i;

    /* 【加载顺序说明】
     * 1. 站号: 最先加载，其他指令可能需要站号
     * 2. 分辨率: 频率测量的基础参数
     * 3. 序列号: 设备标识
     * 4. 校准参数: 气压计算需要，会合并二区
     * 5. 精度参数: PW/PS/PT精度值
     * 6. 气压上限: 气压值限制
     */
    flash_station_init();         /* 从Flash加载站号 */
    flash_resolution_init();      /* 从Flash加载分辨率，同步到全局变量 */
    flash_serial_init();          /* 从Flash加载序列号 */
    flash_calib_init();           /* 从Flash加载校准参数，合并二区到一区 */
    flash_precision_init();       /* 从Flash加载精度参数(PW/PS/PT) */
    flash_pressure_limit_init();  /* 从Flash加载气压上限 */

    /* 清空接收缓冲区，准备接收新数据 */
    for (i = 0; i < PROTO_RX_BUF_SIZE; i++)
        g_proto_rx_buf[i] = 0;
    g_proto_rx_idx        = 0;
    g_proto_rx_mode       = 0;
    g_proto_rx_need_cksum = 0;
    g_proto_frame_ready   = 0;
    /* s_station 由 flash_station_init 加载, 不清零 */
}

/* ====================================================================================
 * Flash 版本号存储
 *
 * 存储格式 (内部Flash 0x0803F000):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 版本字符串长度
 *   偏移3~: 版本字符串 (ASCII, 以\0结尾)
 * ==================================================================================== */
void flash_store_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    intflash_read(buf, FLASH_STORE_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_STORE_MAGIC)
    {
        /* Flash 中有有效版本号, 加载 */
        len = buf[2];
        if (len > 23) len = 23;
        for (i = 0; i < len && i < 23; i++)
            s_fw_version[i] = (char)buf[3 + i];
        s_fw_version[len] = '\0';
    }
    else
    {
        /* 首次上电或Flash为空, 写入默认版本号 */
        len = 0;
        while (PROTO_FW_VERSION[len] && len < 23) len++;

        /* 擦除页后写入 */
        intflash_erase_page(FLASH_STORE_ADDR);

        buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);   /* 魔数高位 */
        buf[1] = (uint8_t)(FLASH_STORE_MAGIC);         /* 魔数低位 */
        buf[2] = len;                                   /* 版本长度 */
        for (i = 0; i < len; i++)
            buf[3 + i] = (uint8_t)PROTO_FW_VERSION[i];
        for (; i < 29; i++)
            buf[3 + i] = 0xFF;                          /* 剩余填 0xFF */

        intflash_write(buf, FLASH_STORE_ADDR, 32);
    }
}

const char* flash_store_version(void)
{
    return s_fw_version;
}

/* ====================================================================================
 * Flash 配置区存储 (内部Flash, 2KB页)
 *
 * 【磨损均衡写入策略】
 *   普通写入: 每次修改都要擦除整页再写入
 *   磨损均衡: 不擦除，直接追加写入到下一个空位
 *   一页可以存很多条记录(约64条)
 *   只有页满了才擦除一次
 *   好处: Flash寿命延长64倍
 *
 * 【存储格式】每条记录 32 字节:
 *   偏移0~1: 魔数 0xA5 0xF3 (标识有效记录)
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 波特率 uint32_t (小端序)
 *   偏移  7: 保留 (站号已迁至独立页)
 *   偏移  8: 校验位 uint8_t (0=无, 1=奇, 2=偶)
 *   偏移  9: 数据位 uint8_t (8或9)
 *   偏移 10: 停止位 uint8_t (1或2)
 *   偏移11~31: 填充 0xFF (预留)
 *
 * 【小端序说明】
 *   低字节在前，高字节在后
 *   例如: 9600 = 0x00002580
 *   存储为: 80 25 00 00
 * ==================================================================================== */

/* 前向声明 (usart.c) */
extern void usart_baud_set(uint32_t baud);

/* 【flash_cfg_save函数说明】
 * 功能: 保存串口配置到Flash
 * 时机: 修改波特率、校验位、数据位、停止位时调用
 * 策略: 磨损均衡，追加写入，页满才擦除
 */
static void flash_cfg_save(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];  /* 记录缓冲区 */
    uint8_t  i;
    int16_t  last_slot = -1;      /* 最后一条有效记录的槽号 */
    int16_t  next_slot;           /* 下一个要写入的槽号 */
    uint16_t magic;               /* 魔数 */
    uint32_t addr;                /* Flash地址 */

    /* ---- 第1步: 打包数据到缓冲区 ---- */
    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);  /* 魔数高位 */
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);        /* 魔数低位 */
    buf[2] = 0x01;                              /* 格式版本 */

    /* 波特率: 4字节小端序 */
    buf[3] = (uint8_t)(s_baud_rate);            /* 波特率字节0(最低) */
    buf[4] = (uint8_t)(s_baud_rate >> 8);       /* 波特率字节1 */
    buf[5] = (uint8_t)(s_baud_rate >> 16);      /* 波特率字节2 */
    buf[6] = (uint8_t)(s_baud_rate >> 24);      /* 波特率字节3(最高) */

    buf[7] = 0xFF;                              /* 保留(站号已迁至独立页) */
    buf[8] = s_parity;                          /* 校验位 */
    buf[9] = s_data_bits;                       /* 数据位 */
    buf[10] = s_stop_bits;                      /* 停止位 */

    /* 剩余字节填充0xFF(空) */
    for (i = 11; i < FLASH_CFG_RECORD_SIZE; i++)
        buf[i] = 0xFF;

    /* ---- 第2步: 找最后一条有效记录的位置 ----
     * 从前往后扫描，找到最后一条有效记录
     * 这样就知道下一个要写入的槽号
     */
    {
        uint8_t magic_buf[2];
        for (i = 0; i < FLASH_CFG_MAX_RECORDS; i++)
        {
            addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
            intflash_read(magic_buf, addr, 2);  /* 只读2字节魔数 */
            magic = ((uint16_t)magic_buf[0] << 8) | magic_buf[1];
            if (magic == FLASH_CFG_MAGIC)
                last_slot = (int16_t)i;         /* 记录最后有效槽号 */
        }
    }

    /* ---- 第3步: 计算下一个槽号 ---- */
    next_slot = last_slot + 1;

    /* ---- 第4步: 检查是否需要擦除 ----
     * 如果页满了(所有槽都用完了)，需要擦除整页
     * 擦除后从槽0重新开始写入
     */
    if (next_slot >= (int16_t)FLASH_CFG_MAX_RECORDS)
    {
        intflash_erase_page(FLASH_CFG_ADDR);  /* 擦除整页 */
        next_slot = 0;                         /* 从槽0开始 */
    }

    /* ---- 第5步: 追加写入新记录 ----
     * 内部Flash特性: 目标字节为0xFF时可以直接写入
     * 如果目标字节不是0xFF，需要先擦除才能写入
     * 这就是为什么我们用追加写入的方式
     */
    addr = FLASH_CFG_ADDR + (uint32_t)next_slot * FLASH_CFG_RECORD_SIZE;
    intflash_write(buf, addr, FLASH_CFG_RECORD_SIZE);
}

void flash_cfg_init(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];
    uint16_t magic;
    uint8_t  need_save = 0;
    int16_t  i;

    /* ---- 从后往前扫, 找最新一条有效记录 ---- */
    for (i = (int16_t)(FLASH_CFG_MAX_RECORDS - 1); i >= 0; i--)
    {
        uint32_t addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
        intflash_read(buf, addr, FLASH_CFG_RECORD_SIZE);
        magic = ((uint16_t)buf[0] << 8) | buf[1];

        if (magic == FLASH_CFG_MAGIC)
        {
            /* 找到! 加载配置 */
            s_baud_rate = (uint32_t)buf[3]
                        | ((uint32_t)buf[4] << 8)
                        | ((uint32_t)buf[5] << 16)
                        | ((uint32_t)buf[6] << 24);

            /* 合法性检查: 必须在允许列表中 */
            {
                uint8_t j, valid = 0;
                for (j = 0; j < BAUD_TABLE_SIZE; j++)
                {
                    if (s_baud_rate == s_baud_table[j]) { valid = 1; break; }
                }
                if (!valid)
                {
                    s_baud_rate = 9600;
                    need_save = 1;
                }
            }

            /* 加载校验位 */
            s_parity = buf[8];
            if (s_parity > PROTO_PARITY_EVEN)
            {
                s_parity = PROTO_PARITY_NONE;
                need_save = 1;
            }

            /* 加载数据位 */
            s_data_bits = buf[9];
            if (s_data_bits > PROTO_DATA_BITS_9)
            {
                s_data_bits = PROTO_DATA_BITS_8;
                need_save = 1;
            }

            /* 加载停止位 */
            s_stop_bits = buf[10];
            if (s_stop_bits > PROTO_STOP_BITS_2)
            {
                s_stop_bits = PROTO_STOP_BITS_1;
                need_save = 1;
            }

            /* 站号由 flash_station_init() 独立加载, 不从这里读取 */

            if (need_save)
            {
                flash_cfg_save();
            }
            /* UART 尚未初始化 */
            return;
        }
    }

    /* 扇区全空或全无效 → 首次上电 */
    s_baud_rate = 9600;
    s_parity    = PROTO_PARITY_NONE;
    s_data_bits = PROTO_DATA_BITS_8;
    s_stop_bits = PROTO_STOP_BITS_1;
    /* 站号由 flash_station_init() 独立初始化 */
    flash_cfg_save();
}

uint32_t flash_cfg_get_baud(void)
{
    return s_baud_rate;
}

uint8_t flash_cfg_get_parity(void)
{
    return s_parity;
}

uint8_t flash_cfg_get_data_bits(void)
{
    return s_data_bits;
}

uint8_t flash_cfg_get_stop_bits(void)
{
    return s_stop_bits;
}

/* ====================================================================================
 * Flash 站号独立存储 (扇区 2045)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 站号 uint8_t
 *   偏移4~31: 填充 0xFF
 *
 * 站号极少变更, 不使用追加磨损均衡, 每次擦除后单条写入
 * ==================================================================================== */
void flash_station_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_STATION_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_CFG_MAGIC)
    {
        /* 有效记录 → 加载站号 */
        s_station = buf[3];
    }
    else
    {
        /* 首次上电 → 默认站号 0x01, 写入内部Flash */
        s_station = 0x01;
        flash_station_save();
    }
}

void flash_station_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    intflash_erase_page(FLASH_STATION_ADDR);

    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);
    buf[2] = 0x01;
    buf[3] = s_station;

    for (i = 4; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_STATION_ADDR, 32);
}

/* ---- Flash 分辨率存储 (内部Flash 0x0803FC00) ---- */
void flash_resolution_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_RESOLUTION_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_RESOLUTION_MAGIC && buf[2] < RESOLUTION_TABLE_SIZE)
    {
        /* 有效记录 → 加载分辨率 */
        s_resolution_idx = buf[2];
    }
    else
    {
        /* 首次上电 → 默认分辨率 "1" (100ms), 写入内部Flash */
        s_resolution_idx = RESOLUTION_IDX_DEFAULT;
        flash_resolution_save();
    }

    /* 同步到频率测量模块的闸门目标 */
    g_target_ref_count = s_resolution_ref_counts[s_resolution_idx];
    /* 同步信号计数闸门目标: signal = ref × est_freq / 120MHz */
    g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);
    g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);
}

void flash_resolution_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    intflash_erase_page(FLASH_RESOLUTION_ADDR);

    buf[0] = (uint8_t)(FLASH_RESOLUTION_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_RESOLUTION_MAGIC);
    buf[2] = s_resolution_idx;

    for (i = 3; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_RESOLUTION_ADDR, 32);
}

uint8_t flash_resolution_get_idx(void)
{
    return s_resolution_idx;
}

/* ====================================================================================
 * Flash 序列号存储 (内部Flash 0x0803EC00)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 序列号字符串长度 (不含\0)
 *   偏移4~15: 序列号字符串 (ASCII, "XSTK" + 8位后缀, 共12字符)
 *   偏移16~31: 填充 0xFF
 * ==================================================================================== */

static void flash_serial_save(void)
{
    uint8_t buf[32];
    uint8_t len, i;

    len = (uint8_t)strlen(s_serial);
    if (len > 12) len = 12;

    intflash_erase_page(FLASH_SERIAL_ADDR);

    buf[0] = (uint8_t)(FLASH_SERIAL_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_SERIAL_MAGIC);
    buf[2] = 0x01;
    buf[3] = len;
    for (i = 0; i < len; i++)
        buf[4 + i] = (uint8_t)s_serial[i];
    for (; i < 12; i++)
        buf[4 + i] = 0xFF;
    for (i = 16; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_SERIAL_ADDR, 32);
}

static void flash_serial_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    intflash_read(buf, FLASH_SERIAL_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_SERIAL_MAGIC)
    {
        /* 有效记录 → 加载序列号 */
        len = buf[3];
        if (len > 12) len = 12;
        for (i = 0; i < len; i++)
            s_serial[i] = (char)buf[4 + i];
        s_serial[len] = '\0';
    }
    else
    {
        /* 首次上电 → 默认序列号, 写入内部Flash */
        strcpy(s_serial, "XSTK00000000");
        flash_serial_save();
    }
}

/* ====================================================================================
 * Flash 校准参数存储 (加法器/乘法器, 双区机制)
 *
 * 每个参数有两区 (各1KB独立页):
 *   一区: 当前生效值, 上电读取直接用于计算
 *   二区: 待生效值, 串口指令写入, 下次上电合并到一区
 *
 * 合并规则:
 *   加法器: 一区 + 二区 → 一区
 *   乘法器: 一区 × 二区 → 一区
 *
 * 存储格式 (32字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: float值 (little-endian)
 *   偏移7~31: 填充 0xFF
 * ==================================================================================== */

/* 读取校准区的float值, 返回1=有效, 0=无效(全0xFF或魔数不对) */
/* 【calib_read_zone函数说明】
 * 功能: 从Flash读取校准值
 * 参数: addr-Flash地址, out-输出缓冲区
 * 返回: 1=读取成功, 0=无有效数据
 *
 * 【存储格式】32字节:
 *   偏移0~1: 魔数 0xA5 0xF3 (标识有效数据)
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 校准值 float (4字节)
 *   偏移7~31: 填充 0xFF
 *
 * 【float存储说明】
 *   float类型占4字节，直接memcpy拷贝
 *   避免内存对齐问题
 */
static uint8_t calib_read_zone(uint32_t addr, float *out)
{
    uint8_t buf[32];    /* 读取缓冲区 */
    uint16_t magic;     /* 魔数 */

    /* 读取32字节 */
    intflash_read(buf, addr, 32);

    /* 检查魔数是否正确 */
    magic = ((uint16_t)buf[0] << 8) | buf[1];
    if (magic != FLASH_CALIB_MAGIC)
        return 0;  /* 魔数不匹配，无有效数据 */

    /* 拷贝4字节float值 */
    memcpy(out, &buf[3], 4);
    return 1;  /* 读取成功 */
}

/* 【calib_write_zone函数说明】
 * 功能: 写入校准值到Flash
 * 参数: addr-Flash地址, val-要写入的校准值
 * 返回: 1=写入成功, 0=写入失败
 *
 * 【写入流程】
 *   1. 擦除整页(2KB)
 *   2. 构造32字节数据
 *   3. 写入Flash
 *   4. 读回验证
 *   5. 如果验证失败，重试最多3次
 *
 * 【为什么需要验证】
 *   Flash写入可能因为干扰或硬件问题失败
 *   读回验证确保数据正确写入
 *   3次重试提高成功率
 *
 * 【为什么擦除整页】
 *   Flash只能1→0，不能0→1
 *   要写入新数据，必须先擦除(全变0xFF)
 *   擦除是按页进行的，所以擦除整页
 */
static uint8_t calib_write_zone(uint32_t addr, float val)
{
    uint8_t buf[32];    /* 写入缓冲区 */
    uint8_t rbuf[32];   /* 读回验证缓冲区 */
    uint8_t i;
    uint8_t retry;      /* 重试计数器 */

    /* 最多重试3次 */
    for (retry = 0; retry < 3; retry++)
    {
        /* 第1步: 擦除整页 */
        intflash_erase_page(addr);

        /* 第2步: 构造32字节数据 */
        buf[0] = (uint8_t)(FLASH_CALIB_MAGIC >> 8);  /* 魔数高位 */
        buf[1] = (uint8_t)(FLASH_CALIB_MAGIC);        /* 魔数低位 */
        buf[2] = 0x01;                                /* 格式版本 */
        memcpy(&buf[3], &val, 4);                     /* float校准值(4字节) */
        for (i = 7; i < 32; i++)                      /* 剩余填充0xFF */
            buf[i] = 0xFF;

        /* 第3步: 写入Flash */
        intflash_write(buf, addr, 32);

        /* 第4步: 读回验证 */
        intflash_read(rbuf, addr, 32);

        /* 第5步: 比较写入和读回的数据 */
        if (rbuf[0] == buf[0] && rbuf[1] == buf[1] && rbuf[2] == buf[2] &&
            memcmp(&rbuf[3], &buf[3], 4) == 0)
        {
            return 1;  /* 写入成功 */
        }
        /* 验证失败，继续重试 */
    }

    return 0;  /* 3次重试全部失败 */
}

/* 清零校准区 (擦除整页, 全变0xFF) */
static void calib_clear_zone(uint32_t addr)
{
    intflash_erase_page(addr);
}

/* 【flash_calib_init函数说明】
 * 功能: 从Flash加载校准参数，合并二区到一区
 * 时机: 系统启动时调用
 *
 * 【双区存储机制】
 * 一区(生效区): 当前正在使用的校准值
 * 二区(待生效区): 新写入的校准值，下次上电时合并到一区
 *
 * 【合并规则】
 * 加法器: 一区值 + 二区值 → 一区值
 * 乘法器: 一区值 × 二区值 → 一区值
 *
 * 【合并流程】
 * 1. 读取一区和二区的值
 * 2. 如果一区有效，二区有数据，执行合并
 * 3. 合并后写入一区，清除二区
 * 4. 如果一区无效(首次上电)，用二区值作为一区
 * 5. 如果都空，写入默认值
 *
 * 【为什么写成功才清二区】
 * 防止合并写入失败时丢失二区数据
 * 如果写入失败，二区数据保留，下次启动重试
 */
void flash_calib_init(void)
{
    float zone1_val, zone2_val;  /* 一区和二区的值 */
    float final_val;             /* 最终使用的值 */
    uint8_t need_write = 0;      /* 是否需要写入(暂未使用) */

    /* ---- 处理加法器 ---- */
    if (calib_read_zone(FLASH_CALIB_ADDER1_ADDR, &zone1_val))
    {
        /* 一区有效 */
        if (calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 合并: 一区 + 二区 */
            final_val = zone1_val + zone2_val;
            /* 写入一区，成功后清除二区 */
            if (calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_ADDER2_ADDR);
        }
        else
        {
            /* 二区空 → 直接使用一区值 */
            final_val = zone1_val;
        }
    }
    else
    {
        /* 一区无效(首次上电) */
        if (calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 用二区值作为一区 */
            final_val = zone2_val;
            if (calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_ADDER2_ADDR);
        }
        else
        {
            /* 都空 → 写默认值0.0 */
            final_val = 0.0f;
            calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val);
        }
    }
    s_calib_adder = final_val;  /* 保存到全局变量 */

    /* ---- 处理乘法器 ---- */
    if (calib_read_zone(FLASH_CALIB_MULT1_ADDR, &zone1_val))
    {
        /* 一区有效 */
        if (calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 合并: 一区 × 二区 */
            final_val = zone1_val * zone2_val;
            s_mult_merged_val = final_val;  /* 记录合并值用于调试 */
            /* 写入一区，成功后清除二区 */
            if (calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_MULT2_ADDR);
        }
        else
        {
            /* 二区空 → 直接使用一区值 */
            final_val = zone1_val;
        }
    }
    else
    {
        /* 一区无效(首次上电) */
        if (calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 用二区值作为一区 */
            final_val = zone2_val;
            if (calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_MULT2_ADDR);
        }
        else
        {
            /* 都空 → 写默认值1.0(乘法器默认1.0，不影响计算) */
            final_val = 1.0f;
            calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val);
        }
    }
    s_calib_mult = final_val;  /* 保存到全局变量 */
}

float proto_get_calib_adder(void)
{
    return s_calib_adder;
}

float proto_get_calib_mult(void)
{
    return s_calib_mult;
}

/* 串口写入: 只存二区, 本次上电不影响一区 */
static void flash_calib_save_adder_zone2(float val)
{
    calib_write_zone(FLASH_CALIB_ADDER2_ADDR, val);
}

static void flash_calib_save_mult_zone2(float val)
{
    calib_write_zone(FLASH_CALIB_MULT2_ADDR, val);
}

/* ====================================================================================
 * 精度Flash存储 (PW/PS/PT)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 精度值 (uint8_t, 0=0.0, 1=0.1, 2=0.2, 3=0.3)
 *   偏移4~31: 填充 0xFF
 *
 * 精度值极少变更, 不使用追加磨损均衡, 每次擦除后单条写入
 * ==================================================================================== */

/* 读取精度值, 返回1=成功 0=失败 */
static uint8_t flash_precision_read(uint32_t addr, uint8_t *val)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, addr, 32);
    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic != FLASH_PRECISION_MAGIC)
        return 0;

    *val = buf[3];
    return 1;
}

/* 保存精度值 */
static void flash_precision_save(uint32_t addr, uint8_t val)
{
    uint8_t buf[32];
    uint8_t i;

    /* 擦除 */
    intflash_erase_page(addr);

    /* 构造数据 */
    buf[0] = (uint8_t)(FLASH_PRECISION_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_PRECISION_MAGIC);
    buf[2] = 0x01;
    buf[3] = val;
    for (i = 4; i < 32; i++)
        buf[i] = 0xFF;

    /* 写入 */
    intflash_write(buf, addr, 32);
}

/* 初始化精度 */
static void flash_precision_init(void)
{
    uint8_t val;

    if (flash_precision_read(FLASH_PRECISION_PW_ADDR, &val))
        s_precision_pw = val;
    else
        s_precision_pw = 0;

    if (flash_precision_read(FLASH_PRECISION_PS_ADDR, &val))
        s_precision_ps = val;
    else
        s_precision_ps = 0;

    if (flash_precision_read(FLASH_PRECISION_PT_ADDR, &val))
        s_precision_pt = val;
    else
        s_precision_pt = 0;
}

/* ====================================================================================
 * 气压上限Flash存储
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 气压上限 float
 *   偏移7~31: 填充 0xFF
 * ==================================================================================== */

/* 读取气压上限, 返回1=成功 0=失败 */
static uint8_t flash_pressure_limit_read(float *val)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_PRESSURE_LIMIT_ADDR, 32);
    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic != FLASH_PRESSURE_LIMIT_MAGIC)
        return 0;

    memcpy(val, &buf[3], 4);
    return 1;
}

/* 保存气压上限 */
static void flash_pressure_limit_save(float val)
{
    uint8_t buf[32];
    uint8_t i;

    /* 擦除 */
    intflash_erase_page(FLASH_PRESSURE_LIMIT_ADDR);

    /* 构造数据 */
    buf[0] = (uint8_t)(FLASH_PRESSURE_LIMIT_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_PRESSURE_LIMIT_MAGIC);
    buf[2] = 0x01;
    memcpy(&buf[3], &val, 4);
    for (i = 7; i < 32; i++)
        buf[i] = 0xFF;

    /* 写入 */
    intflash_write(buf, FLASH_PRESSURE_LIMIT_ADDR, 32);
}

/* 初始化气压上限 */
static void flash_pressure_limit_init(void)
{
    float val;

    if (flash_pressure_limit_read(&val))
        s_pressure_limit = val;
    else
        s_pressure_limit = 10000.0f;
}

/* ====================================================================================
 * 辅助函数: 计算 XOR 校验和
 *   buf: 待校验数据
 *   len: 字节数
 *   返回: XOR 结果 (0x00~0xFF)
 * ==================================================================================== */
uint8_t proto_xor_checksum(const uint8_t *buf, uint8_t len)
{
    uint8_t ck = 0;
    uint8_t i;
    for (i = 0; i < len; i++)
    {
        ck ^= buf[i];
    }
    return ck;
}

/* ====================================================================================
 * 辅助函数: 构建并发送响应帧
 *   自动计算校验和, 组装为 *01XX<data>\r\n<CK>
 *   data: 响应数据字符串 (不含帧头帧尾校验和)
 * ==================================================================================== */
void proto_send_response(const char *data)
{
    uint8_t  frame[PROTO_TX_BUF_SIZE];
    uint8_t  idx = 0;
    uint8_t  i;
    uint8_t  ck;

    /* ---------- 构建帧 ---------- */
    frame[idx++] = '*';                     /* 帧头 */
    frame[idx++] = '0';                     /* 地址高位 */
    frame[idx++] = '0' + PROTO_DEV_ADDR;    /* 地址低位: '1' */
    frame[idx++] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];  /* 站号高位 */
    frame[idx++] = "0123456789ABCDEF"[s_station & 0x0F];         /* 站号低位 */

    /* 数据部分 (前面加空格, 与帧头分隔) */
    frame[idx++] = ' ';
    if (data != NULL)
    {
        while (*data && idx < PROTO_TX_BUF_SIZE - 6)
        {
            frame[idx++] = (uint8_t)(*data++);
        }
    }

    /* 帧尾 \r\n */
    frame[idx++] = 0x0D;
    frame[idx++] = 0x0A;

    /* 校验和 (范围: 帧头 '*' 到 \r\n 前, 即 idx-2 个字节) */
    ck = proto_xor_checksum(frame, idx - 2);
    frame[idx++] = "0123456789ABCDEF"[(ck >> 4) & 0x0F];
    frame[idx++] = "0123456789ABCDEF"[ck & 0x0F];

    /* ---------- DMA 发送 ---------- */
    usart_dma_send(frame, idx);
}

/* ====================================================================================
 * 辅助函数: 发错误响应
 * ==================================================================================== */
static void proto_send_error(const char *err_msg)
{
    proto_send_response(err_msg);
}

/* ====================================================================================
 * 辅助函数: 2位 hex 字符 → uint8
 *   hex: 指向2个ASCII hex字符的指针
 *   返回: 0x00~0xFF
 * ==================================================================================== */
static uint8_t hex2u8(const char *hex)
{
    uint8_t val = 0;
    uint8_t i;
    for (i = 0; i < 2; i++)
    {
        val <<= 4;
        if (hex[i] >= '0' && hex[i] <= '9')
            val |= hex[i] - '0';
        else if (hex[i] >= 'A' && hex[i] <= 'F')
            val |= hex[i] - 'A' + 10;
        else if (hex[i] >= 'a' && hex[i] <= 'f')
            val |= hex[i] - 'a' + 10;
    }
    return val;
}

/* ====================================================================================
 * 核心函数: 协议帧解析与处理 (主循环中调用)
 * ==================================================================================== */
void protocol_process(void)
{
    uint8_t  frame_len;
    uint8_t  data_end;       /* \r 的位置 (数据部分结束) */
    uint8_t  payload_start;  /* 指令码起始位置 = 5 */
    uint8_t  payload_len;    /* 指令码+数据总长度 */
    uint8_t  ck_calc, ck_recv;
    uint8_t  dev_addr;
    uint8_t  station;
    uint8_t  i;

    /* ---------- 第1步: 找 \r, 定位校验和 ---------- */
    frame_len = g_proto_rx_idx;
    if (frame_len < 10)   /* 最短帧: #01XXCC\rCC = 10字节 */
    {
        proto_send_error("ER1");  /* 帧太短 */
        return;
    }

    /* 找 \r 位置 */
    data_end = 0xFF;
    for (i = 0; i < frame_len; i++)
    {
        if (g_proto_rx_buf[i] == 0x0D)
        {
            data_end = i;
            break;
        }
    }
    if (data_end == 0xFF || data_end + 3 > frame_len)
    {
        /* 无 \r 或 校验和不完整 (\r后需要2字节校验和) */
        proto_send_error("ER2");  /* 帧格式错误 */
        return;
    }
    /* 校验和在 data_end+1 和 data_end+2 */

    /* ---------- 第2步: 校验和验证 ---------- */
    ck_recv = hex2u8((const char *)&g_proto_rx_buf[data_end + 1]);
    ck_calc = proto_xor_checksum((const uint8_t *)g_proto_rx_buf, data_end + 1);  /* 范围: '#'..\r 含\r */
    if (ck_recv != ck_calc)
    {
        proto_send_error("ER3");  /* 校验和错误 */
        return;
    }

    /* ---------- 第3步: 校验帧头 ---------- */
    if (g_proto_rx_buf[0] != '#')
    {
        proto_send_error("ER4");  /* 帧头错误 */
        return;
    }

    /* ---------- 第4步: 校验设备地址 ---------- */
    dev_addr = hex2u8((const char *)&g_proto_rx_buf[1]);
    if (dev_addr != PROTO_DEV_ADDR)
    {
        /* 地址不匹配, 不响应 */
        return;
    }

    /* ---------- 第5步: 解析站号并过滤 ---------- */
    station = hex2u8((const char *)&g_proto_rx_buf[3]);

    /* 00 = 广播 (全体响应), 其他 = 仅匹配自身站号, 不匹配则静默丢弃 */
    if (station != 0x00 && station != s_station)
        return;

    /* ---------- 第6步: 提取指令码+数据 ---------- */
    payload_start = 5;                                        /* 跳过 # + 01 + XX */
    payload_len   = data_end - payload_start;                 /* 指令码+数据总长度 */

    if (payload_len < 2)
    {
        proto_send_error("ER5");  /* 无指令码 */
        return;
    }

    /* ---------- 第7步: 查表匹配指令 ---------- */
    for (i = 0; i < CMD_TABLE_SIZE; i++)
    {
        const proto_cmd_entry_t *cmd = &s_cmd_table[i];

        if (payload_len < cmd->len)
            continue;

        /* 比较指令码 (大小写不敏感 — 接收一律转大写对比) */
        {
            uint8_t match = 1;
            uint8_t j;
            for (j = 0; j < cmd->len; j++)
            {
                char c = (char)g_proto_rx_buf[payload_start + j];
                if (c >= 'a' && c <= 'z') c -= 32;  /* 小写转大写 */
                if (c != cmd->code[j]) { match = 0; break; }
            }
            if (!match) continue;
        }

        /* 命中! 提取数据部分 */
        {
            const char *data_ptr = NULL;
            uint8_t     data_len = 0;

            if (payload_len > cmd->len)
            {
                data_ptr = (const char *)&g_proto_rx_buf[payload_start + cmd->len];
                data_len = payload_len - cmd->len;
            }

            /* 执行处理函数 */
            cmd->handler(station, data_ptr, data_len);
        }
        return;   /* 已处理, 退出 */
    }

    /* 未匹配任何指令 */
    proto_send_error("ER6");  /* 未知指令 */
}

/* ====================================================================================
 * 读指令处理函数
 * ==================================================================================== */

/* ---- ST: 通讯查验 ---- */
static void handler_st(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response("OK");
}

/* ---- VG: 读版本 ---- */
static void handler_vg(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(flash_store_version());
}

/* ---- P3: 读气压 (含加法器/乘法器校准) ---- */
static void handler_p3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    if (pressure > s_pressure_limit)
        pressure = s_pressure_limit;
    sprintf(buf, "%.2f", (double)pressure);
    proto_send_response(buf);
}

/* ---- P1: 单次采集 (F1频率 + F2频率 + 气压, 含校准) ---- */
static void handler_p1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    if (pressure > s_pressure_limit)
        pressure = s_pressure_limit;
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)pressure);
    proto_send_response(buf);
}

/* ---- T1: 单次采集 (F1频率 + F2频率 + 温度) ---- */
static void handler_t1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    short temp_raw;
    float temp_c;
    (void)data; (void)data_len;
    (void)station;

    temp_raw = Get_Temprate();
    temp_c   = (float)temp_raw / 100.0f;
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)temp_c);
    proto_send_response(buf);
}

/* ---- T3: 读温度 ---- */
static void handler_t3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    short temp_raw;
    float temp_c;
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */

    temp_raw = Get_Temprate();                    /* ×100 如 3524 = 35.24°C */
    temp_c   = (float)temp_raw / 100.0f;
    sprintf(buf, "%.2f", (double)temp_c);
    proto_send_response(buf);
}

/* ---- H3: 读高度 (气压含校准) ---- */
static void handler_h3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure, altitude;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    if (pressure > s_pressure_limit)
        pressure = s_pressure_limit;
    altitude = pressure_to_altitude(pressure);
    sprintf(buf, "%.2f", (double)altitude);
    proto_send_response(buf);
}

/* ---- F5: 读频率组 (5个CH1 + 5个CH2, 窗口原始数据, 最旧→最新) ---- */
static void handler_f5(uint8_t station, const char *data, uint8_t data_len)
{
    char     buf[200];
    uint32_t ch1[PRESSURE_WINDOW_SIZE];
    uint32_t ch2[PRESSURE_WINDOW_SIZE];
    uint8_t  cnt, i, pos = 0;
    (void)data; (void)data_len;
    (void)station;

    cnt = pressure_calc_get_window(ch1, ch2);  /* 时间顺序: [0]=最旧, [cnt-1]=最新 */

    /* F1 标签 */
    pos += sprintf(&buf[pos], "F1:");

    /* 输出5个F1: 取最新5个, 不足则在前面补 0.000 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }

    /* F2 标签 */
    buf[pos++] = ',';
    pos += sprintf(&buf[pos], "F2:");

    /* 输出5个F2: 同上 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    buf[pos] = '\0';
    proto_send_response(buf);
}

/* ---- SN: 读序列号 ---- */
static void handler_sn_read(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(s_serial);
}

/* ---- FS: 读量程 ---- */
static void handler_fs(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */

    /* PW:0.1/1000 PS:0.2/1000 PT:0.3/1000 */
    sprintf(buf, "PW:%.1f/1000 PS:%.1f/1000 PT:%.1f/1000",
            s_precision_pw * 0.1f,
            s_precision_ps * 0.1f,
            s_precision_pt * 0.1f);
    proto_send_response(buf);
}

/* ---- BR: 读波特率 ---- */
/* ---- DR: 读站号 (返回设备自身站号, 不修改) ---- */
static void handler_dr(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[3];
    (void)station; (void)data; (void)data_len;
    buf[0] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];
    buf[1] = "0123456789ABCDEF"[s_station & 0x0F];
    buf[2] = '\0';
    proto_send_response(buf);
}

/* ---- BR: 读/写波特率 ---- */
static void handler_br(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[16];
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data != NULL && data_len > 0)
    {
        /* 检查写入使能 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");
            return;
        }
        s_write_enable = 0;  /* 消耗使能 */

        /* ---- 写模式: 设置新波特率 ---- */
        uint32_t new_baud = 0;
        uint8_t  i;

        for (i = 0; i < data_len; i++)
        {
            if (data[i] >= '0' && data[i] <= '9')
                new_baud = new_baud * 10 + (uint32_t)(data[i] - '0');
            else
                break;
        }

        /* 校验: 必须在允许列表中 */
        {
            uint8_t j, valid = 0;
            for (j = 0; j < BAUD_TABLE_SIZE; j++)
            {
                if (new_baud == s_baud_table[j]) { valid = 1; break; }
            }
            if (!valid)
            {
                proto_send_response("ER8");  /* 无效波特率 */
                return;
            }
        }

        s_baud_rate = new_baud;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧波特率发完响应, 再切硬件 */
        proto_send_response("OK");

        /* 等待 DMA 发送完成, 然后切换到新波特率 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_baud_set(s_baud_rate);
    }
    else
    {
        /* ---- 读模式: 返回当前波特率 ---- */
        sprintf(buf, "%lu", (unsigned long)s_baud_rate);
        proto_send_response(buf);
    }
}

/* ---- PT: 读/写校验位 ---- */
static void handler_pt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data != NULL && data_len > 0)
    {
        /* 检查写入使能 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");
            return;
        }
        s_write_enable = 0;  /* 消耗使能 */

        /* ---- 写模式: 设置校验位 ---- */
        uint8_t new_parity;
        char    c = data[0];

        /* 大小写不敏感 */
        if (c >= 'a' && c <= 'z') c -= 32;

        if (c == 'N')
            new_parity = PROTO_PARITY_NONE;
        else if (c == 'O')
            new_parity = PROTO_PARITY_ODD;
        else if (c == 'E')
            new_parity = PROTO_PARITY_EVEN;
        else
        {
            proto_send_response("ER8");  /* 无效校验位 */
            return;
        }

        s_parity = new_parity;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧校验位发完响应, 再切硬件 */
        proto_send_response("OK");

        /* 等待 DMA 发送完成, 然后切换到新校验位 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_parity_set(s_parity);
    }
    else
    {
        /* ---- 读模式: 返回当前校验位 ---- */
        const char *p;
        if (s_parity == PROTO_PARITY_ODD)
            p = "O";
        else if (s_parity == PROTO_PARITY_EVEN)
            p = "E";
        else
            p = "N";
        proto_send_response(p);
    }
}

/* ---- BT: 只读数据位 ---- */
static void handler_bt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;
    (void)data;
    (void)data_len;

    /* 读模式: 返回 "8" 或 "9" */
    if (s_data_bits == PROTO_DATA_BITS_9)
        proto_send_response("9");
    else
        proto_send_response("8");
}

/* ---- SB: 读/写停止位 ---- */
static void handler_sb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    if (data != NULL && data_len > 0)
    {
        /* 检查写入使能 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");
            return;
        }
        s_write_enable = 0;  /* 消耗使能 */

        /* ---- 写模式: 设置停止位 ---- */
        uint8_t new_stop;
        char    c = data[0];

        if (c == '1')
            new_stop = PROTO_STOP_BITS_1;
        else if (c == '2')
            new_stop = PROTO_STOP_BITS_2;
        else
        {
            proto_send_response("ER8");  /* 无效停止位 */
            return;
        }

        s_stop_bits = new_stop;
        flash_cfg_save();                /* 持久化到 Flash */

        proto_send_response("OK");
        usart_stop_bits_set(s_stop_bits);
    }
    else
    {
        /* ---- 读模式: 返回当前停止位 ---- */
        if (s_stop_bits == PROTO_STOP_BITS_2)
            proto_send_response("2");
        else
            proto_send_response("1");
    }
}

/* ---- PR: 读分辨率 ---- */
static void handler_pr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(s_resolution_names[s_resolution_idx]);
}

/* ---- MD: 调试 - 输出全部校准相关参数 ---- */
static void handler_md(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[200];
    uint16_t flag;
    float m_z1, m_z2, a_z1, a_z2;
    uint8_t m_z1_ok, m_z2_ok, a_z1_ok, a_z2_ok;
    uint8_t m_z1_raw[8], m_z2_raw[8];
    uint8_t pos = 0;
    (void)data; (void)data_len;
    (void)station;

    rcu_periph_clock_enable(RCU_PMU);
    rcu_periph_clock_enable(RCU_BKPI);
    flag = bkp_read_data(BKP_DATA_0);

    /* 读取各区域原始数据 */
    a_z1_ok = calib_read_zone(FLASH_CALIB_ADDER1_ADDR, &a_z1);
    a_z2_ok = calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &a_z2);
    m_z1_ok = calib_read_zone(FLASH_CALIB_MULT1_ADDR, &m_z1);
    m_z2_ok = calib_read_zone(FLASH_CALIB_MULT2_ADDR, &m_z2);

    /* 读各区域原始8字节 (魔数+版本+float) */
    uint8_t a_z1_raw[8], a_z2_raw[8];
    intflash_read(a_z1_raw, FLASH_CALIB_ADDER1_ADDR, 8);
    intflash_read(a_z2_raw, FLASH_CALIB_ADDER2_ADDR, 8);
    intflash_read(m_z1_raw, FLASH_CALIB_MULT1_ADDR, 8);
    intflash_read(m_z2_raw, FLASH_CALIB_MULT2_ADDR, 8);

    pos += sprintf(&buf[pos], "BKP:%04X ", flag);
    pos += sprintf(&buf[pos], "Mrg:%.4f ", (double)s_mult_merged_val);
    pos += sprintf(&buf[pos], "RunM:%.4f ", (double)s_calib_mult);
    pos += sprintf(&buf[pos], "RunA:%.4f ", (double)s_calib_adder);
    pos += sprintf(&buf[pos], "A1:%s%.4f ", a_z1_ok ? "" : "X", (double)a_z1);
    pos += sprintf(&buf[pos], "A2:%s%.4f ", a_z2_ok ? "" : "X", (double)a_z2);
    pos += sprintf(&buf[pos], "M1:%s%.4f ", m_z1_ok ? "" : "X", (double)m_z1);
    pos += sprintf(&buf[pos], "M2:%s%.4f ", m_z2_ok ? "" : "X", (double)m_z2);
    pos += sprintf(&buf[pos], "A1R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   a_z1_raw[0], a_z1_raw[1], a_z1_raw[2], a_z1_raw[3],
                   a_z1_raw[4], a_z1_raw[5], a_z1_raw[6], a_z1_raw[7]);
    pos += sprintf(&buf[pos], " A2R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   a_z2_raw[0], a_z2_raw[1], a_z2_raw[2], a_z2_raw[3],
                   a_z2_raw[4], a_z2_raw[5], a_z2_raw[6], a_z2_raw[7]);
    pos += sprintf(&buf[pos], " M1R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   m_z1_raw[0], m_z1_raw[1], m_z1_raw[2], m_z1_raw[3],
                   m_z1_raw[4], m_z1_raw[5], m_z1_raw[6], m_z1_raw[7]);
    pos += sprintf(&buf[pos], " M2R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   m_z2_raw[0], m_z2_raw[1], m_z2_raw[2], m_z2_raw[3],
                   m_z2_raw[4], m_z2_raw[5], m_z2_raw[6], m_z2_raw[7]);

    /* 测试: 直接写0x0803E800并读回 */
    {
        uint8_t test_buf[8] = {0xA5, 0xF3, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40}; /* 2.0的前8字节 */
        uint8_t test_read[8];
        intflash_erase_page(0x0803D800);
        intflash_write(test_buf, 0x0803D800, 8);
        intflash_read(test_read, 0x0803D800, 8);
        pos += sprintf(&buf[pos], " TST:%02X%02X%02X%02X%02X%02X%02X%02X",
                       test_read[0], test_read[1], test_read[2], test_read[3],
                       test_read[4], test_read[5], test_read[6], test_read[7]);
    }

    proto_send_response(buf);
}

/* ---- UT: 读/写气压上限 ---- */
/* 【handler_ut函数说明】
 * 功能: 读取或写入气压上限
 * 指令: UT
 * 格式: 读取-UT, 写入-UT<值>
 * 示例: 读取-#0100UT\r<CKSUM>, 写入-#0100UT5000\r<CKSUM>
 *
 * 【功能说明】
 * 读取: 返回当前气压上限值
 * 写入: 设置新的气压上限值，需要EW使能
 *
 * 【气压上限作用】
 * 当气压值超过上限时，按上限值输出
 * 防止异常高气压值导致显示溢出
 *
 * 【存储位置】
 * Flash page 12
 *
 * 【使用示例】
 * 1. 读取: #0100UT\r<CKSUM> → *0101 10000.0\r\n<CKSUM>
 * 2. 写入: #0100EW\r<CKSUM> → *0101 OK\r\n<CKSUM>
 * 3. 写入: #0100UT5000\r<CKSUM> → *0101 OK\r\n<CKSUM>
 */
static void handler_ut(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    (void)station;

    if (data != NULL && data_len > 0)
    {
        /* 写模式: 检查写入使能 */
        if (!s_write_enable)
        {
            proto_send_response("DENY");  /* 拒绝写入 */
            return;
        }
        s_write_enable = 0;  /* 消耗使能 */

        /* 解析新上限值 */
        float new_limit = (float)atof(data);
        if (new_limit > 0.0f)  /* 上限必须大于0 */
        {
            s_pressure_limit = new_limit;  /* 更新内存 */
            flash_pressure_limit_save(new_limit);  /* 保存到Flash */
        }
    }

    /* 返回当前上限值 */
    sprintf(buf, "%.1f", (double)s_pressure_limit);
    proto_send_response(buf);
}

float proto_get_pressure_limit(void)
{
    return s_pressure_limit;
}

/* ---- EW: 写入使能 (只对下一个写入指令有效) ---- */
/* 【handler_ew函数说明】
 * 功能: 写入使能指令
 * 指令: EW
 * 说明: 发送EW后，允许执行下一个写入Flash的指令
 *       一次EW只能写一个指令，写完自动失效
 *       这样设计防止误操作损坏Flash数据
 *
 * 【使用示例】
 * 1. 发送: #0100EW\r<CKSUM>
 * 2. 接收: *0101 OK\r\n<CKSUM>
 * 3. 发送: #0100PAA1.5\r<CKSUM> (现在可以写入)
 * 4. 接收: *0101 OK\r\n<CKSUM>
 * 5. 发送: #0100PMB2.0\r<CKSUM> (拒绝，需要重新EW)
 * 6. 接收: *0101 DENY\r\n<CKSUM>
 */
static void handler_ew(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;  /* 未使用参数 */
    (void)station;

    s_write_enable = 1;  /* 设置写入使能标志 */
    proto_send_response("OK");
}

/* ====================================================================================
 * 写指令处理函数
 * ==================================================================================== */

/* ---- SC: 串口流式输出开关 (切换, 返回当前状态) ---- */
static void handler_sc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;

    s_stream_enable = !s_stream_enable;  /* 切换开关 */
    proto_send_response(s_stream_enable ? "ON" : "OFF");
}

uint8_t proto_get_stream_enable(void)
{
    return s_stream_enable;
}

/* ---- PA: 读加法器 (一区生效值, 二区待生效值) ---- */
static void handler_pa(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    float zone2_val;
    (void)data; (void)data_len;
    (void)station;

    if (!calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        zone2_val = 0.0f;
    sprintf(buf, "%.4f,%.4f", (double)s_calib_adder, (double)zone2_val);
    proto_send_response(buf);
}

/* ---- PM: 读乘法器 (一区生效值, 二区待生效值) ---- */
static void handler_pm(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    float zone2_val;
    (void)data; (void)data_len;
    (void)station;

    if (!calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        zone2_val = 0.0f;
    sprintf(buf, "%.4f,%.4f", (double)s_calib_mult, (double)zone2_val);
    proto_send_response(buf);
}

/* ---- ACC: 写量程精度 ---- */
/* 【handler_acc函数说明】
 * 功能: 写入精度值
 * 指令: ACC
 * 格式: ACC<类型><值> (无空格)
 * 示例: ACCPW0.1, ACCPS0.2, ACCPT0.3
 *
 * 【参数说明】
 * 类型: PW(压力精度), PS(?), PT(?)
 * 值: 0.0, 0.1, 0.2, 0.3 (单位: 千分号‰)
 *
 * 【存储位置】
 * PW: Flash page 9
 * PS: Flash page 10
 * PT: Flash page 11
 *
 * 【使用示例】
 * 1. 发送: #0100EW\r<CKSUM> (先使能)
 * 2. 接收: *0101 OK\r\n<CKSUM>
 * 3. 发送: #0100ACCPW0.1\r<CKSUM>
 * 4. 接收: *0101 OK\r\n<CKSUM>
 */
static void handler_acc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");  /* 拒绝写入 */
        return;
    }
    s_write_enable = 0;  /* 消耗使能，一次EW只能写一个指令 */

    if (data != NULL && data_len >= 4)
    {
        /* 格式: PW0.1, PS0.2, PT0.3 (无空格) */
        uint8_t type = 0;  /* 0=PW, 1=PS, 2=PT */
        float val;
        uint8_t precision_val;

        /* 第1步: 解析类型 (前2个字符) */
        if (data[0] == 'P' && data[1] == 'W')
            type = 0;  /* PW: 压力精度 */
        else if (data[0] == 'P' && data[1] == 'S')
            type = 1;  /* PS: ? */
        else if (data[0] == 'P' && data[1] == 'T')
            type = 2;  /* PT: ? */
        else
        {
            proto_send_response("ERR");  /* 类型错误 */
            return;
        }

        /* 第2步: 解析数值 (第3个字符开始) */
        val = (float)atof(&data[2]);  /* 字符串转浮点数 */
        if (val == 0.0f)
            precision_val = 0;  /* 0.0‰ */
        else if (val == 0.1f)
            precision_val = 1;  /* 0.1‰ */
        else if (val == 0.2f)
            precision_val = 2;  /* 0.2‰ */
        else if (val == 0.3f)
            precision_val = 3;  /* 0.3‰ */
        else
        {
            proto_send_response("ERR");  /* 数值错误 */
            return;
        }

        /* 第3步: 保存到对应的Flash */
        switch (type)
        {
            case 0:  /* PW */
                s_precision_pw = precision_val;  /* 更新内存 */
                flash_precision_save(FLASH_PRECISION_PW_ADDR, precision_val);  /* 保存到Flash */
                break;
            case 1:  /* PS */
                s_precision_ps = precision_val;
                flash_precision_save(FLASH_PRECISION_PS_ADDR, precision_val);
                break;
            case 2:  /* PT */
                s_precision_pt = precision_val;
                flash_precision_save(FLASH_PRECISION_PT_ADDR, precision_val);
                break;
        }
    }
    proto_send_response("OK");
}

/* ---- ADR: 写站号 ---- */
static void handler_adr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data != NULL && data_len >= 2)
    {
        uint8_t new_station = hex2u8(data);
        s_station = new_station;
        flash_station_save();       /* 持久化到独立扇区 2045 */
    }
    proto_send_response("OK");
}

/* ---- EWO: 写 EEPROM 使能 ---- */
static void handler_ewo(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data != NULL && data_len > 0)
    {
        s_eeprom_en = (data[0] == '1') ? 1 : 0;
    }
    proto_send_response("OK");
}

/* ---- PPI: 写压力分辨率 ---- */
static void handler_ppi(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;           /* 只读自身站号, 不覆盖 */

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");   /* 缺少数据 */
        return;
    }

    /* 遍历查表, 匹配分辨率字符串 */
    for (i = 0; i < RESOLUTION_TABLE_SIZE; i++)
    {
        if (strncmp(data, s_resolution_names[i], data_len) == 0
            && s_resolution_names[i][data_len] == '\0')
        {
            /* 合法值: 更新全局闸门目标 */
            s_resolution_idx = i;
            g_target_ref_count = s_resolution_ref_counts[i];
            /* 同步信号计数闸门目标 */
            g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);
            g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);

            /* 持久化到 Flash */
            flash_resolution_save();

            proto_send_response("OK");
            return;
        }
    }

    /* 未匹配 → 无效参数 */
    proto_send_response("ER8");
}

/* ---- PAA: 写加法器校准 (写入二区, 下次上电合并到一区) ---- */
static void handler_paa(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data != NULL && data_len > 0)
    {
        float val = (float)atof(data);
        if (!calib_write_zone(FLASH_CALIB_ADDER2_ADDR, val))
        {
            proto_send_response("ER9");  /* Flash写入失败 */
            return;
        }
    }
    proto_send_response("OK");
}

/* ---- PMB: 写乘法器校准 (写入二区, 下次上电合并到一区) ---- */
static void handler_pmb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data != NULL && data_len > 0)
    {
        float val = (float)atof(data);
        if (!calib_write_zone(FLASH_CALIB_MULT2_ADDR, val))
        {
            proto_send_response("ER9");  /* Flash写入失败 */
            return;
        }
    }
    proto_send_response("OK");
}

/* ---- TPC: 写标定系数 (暂存, 后续可更新多项式矩阵) ---- */
static void handler_tpc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    /* TPC 系数格式较复杂, 暂只返回 OK, 后续实现具体解析 */
    (void)data; (void)data_len;
    proto_send_response("OK");
}

/* ---- WVR: 写版本号 (3字符写指令) ---- */
static void handler_wvr(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t buf[32];
    uint8_t len, i;

    (void)station;           /* 只读自身站号, 不覆盖 */

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");  /* 缺少版本号 */
        return;
    }

    /* 限制长度 */
    len = (data_len > 23) ? 23 : data_len;

    /* 更新内存 */
    for (i = 0; i < len; i++)
        s_fw_version[i] = data[i];
    s_fw_version[len] = '\0';

    /* 写入内部Flash */
    intflash_erase_page(FLASH_STORE_ADDR);

    buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_STORE_MAGIC);
    buf[2] = len;
    for (i = 0; i < len; i++)
        buf[3 + i] = (uint8_t)s_fw_version[i];
    for (; i < 29; i++)
        buf[3 + i] = 0xFF;

    intflash_write(buf, FLASH_STORE_ADDR, 32);
    proto_send_response("OK");
}

/* ---- ID: 写序列号 (2字符写指令) ----
 *
 * 格式: #01XXID<12位序列号>\r<CK>
 * 序列号: "XSTK" + 8位后缀 (0-9 A-Z a-z, 存储时统一转大写)
 * 示例: #0100IDXSTK24505322\rXX
 * ---- */
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;

    /* 检查写入使能 */
    if (!s_write_enable)
    {
        proto_send_response("DENY");
        return;
    }
    s_write_enable = 0;  /* 消耗使能 */

    if (data == NULL || data_len != 12)
    {
        proto_send_response("ER8");  /* 长度必须为12 */
        return;
    }

    /* 验证前缀 "XSTK" (大小写不敏感) */
    for (i = 0; i < 4; i++)
    {
        char c = data[i];
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c != "XSTK"[i])
        {
            proto_send_response("ER8");  /* 前缀错误 */
            return;
        }
    }

    /* 验证后缀8位: 0-9 A-Z a-z, 统一转大写存入 */
    for (i = 4; i < 12; i++)
    {
        char c = data[i];
        if (c >= 'a' && c <= 'z') c -= 32;  /* 小写转大写 */
        if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z')))
        {
            proto_send_response("ER8");  /* 后缀含非法字符 */
            return;
        }
        s_serial[i] = c;
    }
    s_serial[0] = 'X';
    s_serial[1] = 'S';
    s_serial[2] = 'T';
    s_serial[3] = 'K';
    s_serial[12] = '\0';

    flash_serial_save();  /* 持久化到内部Flash */
    proto_send_response("OK");
}
