/**
 * ====================================================================================
 * @file     freq_measure.h
 * @brief    GD32F303频率测量模块 - 等精度测频法（双通道，独立参考时基）
 * ====================================================================================
 *
 * @version  V3.0
 * @date     2024-01-01
 *
 * ------------------------------------------------------------------------------
 * @details  双通道完全独立的等精度测频方案
 *
 * 测量原理：
 *   - CH1: TIMER0 计数 PA8 信号脉冲，TIMER4 作为独立参考时钟
 *   - CH2: TIMER1 计数 PA0 信号脉冲，TIMER5 作为独立参考时钟
 *   - 等精度公式: 频率 = (信号计数 / 参考计数) × 参考时钟频率
 *
 * 两通道完全独立，各自同步启动，互不干扰。
 *
 * 引脚配置：
 *   - PA8: TIMER0_CH0，通道1信号输入
 *   - PA0: TIMER1_ETI，通道2信号输入
 * ====================================================================================
 */

#ifndef __FREQ_MEASURE_H__
#define __FREQ_MEASURE_H__

#include "gd32f30x.h"

/* ====================================================================================
 * 通道1 (CH1) 引脚配置 - PA8 / TIMER0
 * ==================================================================================== */
#define FREQ_CH1_INPUT_PORT     GPIOA
#define FREQ_CH1_INPUT_PIN      GPIO_PIN_8

/* ====================================================================================
 * 通道2 (CH2) 引脚配置 - PA0 / TIMER1
 * ==================================================================================== */
#define FREQ_CH2_INPUT_PORT     GPIOA
#define FREQ_CH2_INPUT_PIN      GPIO_PIN_0

/* ====================================================================================
 * 参考时钟配置
 * - CH1 参考: TIMER4 (120MHz)
 * - CH2 参考: TIMER5 (120MHz)
 * - g_target_ref_count: 目标参考计数, 决定闸门时间, 由分辨率指令 PR/PPI 动态调整
 *   默认: 12000000 / 120000000 = 0.1秒 (100ms, 分辨率=1)
 *   基准: RESOLUTION_BASE_REF_COUNT = 12000000 (对应 100ms 闸门)
 * ==================================================================================== */
#define REF_FREQUENCY              120000700UL   /* 精确校准 */
#define RESOLUTION_BASE_REF_COUNT  12000000UL   /* 分辨率=1时的基准, 对应100ms闸门 */
#define REF_FREQ_X1000             120000700000ULL /* REF_FREQUENCY * 1000, 计算用 */

/* 参考定时器周期（16位定时器，每次溢出计数值 = 0.5ms @120MHz） */
#define REF_TIMER_PERIOD           60000U

/* 动态闸门目标 (替代原 TARGET_REF_COUNT 宏), 默认 100ms */
extern volatile uint32_t g_target_ref_count;

/* 信号计数闸门目标 — 等精度测频法核心参数
 * gate由信号沿数定义(f=N_signal/N_ref×f_ref), 消除ref异步ISR抖动
 * 默认值按100ms闸门 × 各通道典型频率估算 */
#define DEFAULT_SIGNAL_COUNT_CH1  6500UL   /* ~100ms @ 65kHz (CH1气压传感器典型值) */
#define DEFAULT_SIGNAL_COUNT_CH2  5900UL   /* ~100ms @ 59kHz (CH2气压传感器典型值) */
extern volatile uint32_t g_target_signal_count_ch1;
extern volatile uint32_t g_target_signal_count_ch2;

/**
 * 测量延时补偿值（参考时钟周期数）
 * 由 main.c 根据温度动态调整: C = 319.7 - 3.8235*T, 限幅[5, 200]
 */
extern volatile uint32_t g_delay_comp;
extern volatile uint8_t  g_comp_manual;    /* 1=手动模式, 温度补偿暂停 */

/* 频率校准系数 (×1,000,000 定点, 默认 1000000 = ×1.0) */
extern uint32_t g_calib_ch1;
extern uint32_t g_calib_ch2;

/* ====================================================================================
 * 通道1 (CH1) 全局变量声明
 * ==================================================================================== */
extern volatile uint8_t  g_ch1_measure_done;
extern volatile uint32_t g_ch1_signal_count;
extern volatile uint32_t g_ch1_ref_count;

/* ====================================================================================
 * 通道2 (CH2) 全局变量声明
 * ==================================================================================== */
extern volatile uint8_t  g_ch2_measure_done;
extern volatile uint32_t g_ch2_signal_count;
extern volatile uint32_t g_ch2_ref_count;

/* ====================================================================================
 * 兼容旧代码的宏定义
 * ==================================================================================== */
#define g_measure_done      g_ch1_measure_done
#define g_signal_count      g_ch1_signal_count
#define g_ref_count         g_ch1_ref_count

/* ====================================================================================
 * 函数声明
 * ==================================================================================== */
void freq_measure_init(void);
void freq_measure_start(void);
void freq_measure_ch1_start(void);
void freq_measure_ch2_start(void);

/* CH1 - 返回频率×1000（整数定点，保留3位小数） */
uint32_t freq_measure_calculate(void);
uint8_t freq_measure_is_done(void);
void freq_measure_print_result(void);

/* CH2 - 返回频率×1000（整数定点，保留3位小数） */
uint32_t freq_measure_ch2_calculate(void);
uint8_t freq_measure_ch2_is_done(void);
void freq_measure_ch2_print_result(void);

/* 便捷 */
uint8_t freq_measure_all_done(void);
void freq_measure_print_all(void);

#endif
