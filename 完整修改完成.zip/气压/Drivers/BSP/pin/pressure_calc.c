/* ====================================================================================
 * 文件: pressure_calc.c
 * 描述: 气压计算模块 - 6点滑动窗口 + 2D多项式标定
 * ====================================================================================
 *
 * 传感器: 24505322#
 * 公式:   P = Σ k[i][j] * x^j * y^i
 * 其中:   x = (f1/1000 - 65000) / 3800
 *         y = (f2/1000 - 59000) / 3700
 *
 * 优化: 先对6个样本的频率取均值, 再算一次多项式, 精度无损, 计算量降为1/6
 *       频率滤波由 main.c 中值窗口统一处理, 此处仅做均值平均
 * ==================================================================================== */

#include "pressure_calc.h"
#include <math.h>
#include <string.h>

/* 函数前向声明 */
static void set_ps_params_from_float(const float params[25]);
static void set_pt_params_from_float(const float params[25]);
static void set_ts_params_from_float(const float params[25]);

/* ====================================================================================
 * 默认标定参数 (三组: PS/TS/PT)
 *
 * 参数布局 (25个double):
 *   [0] = Δf1, [1] = f1_scale, [2] = Δf2, [3] = f2_scale
 *   [4-24] = 21个k[i][j]多项式系数 (下三角展开)
 *
 * TPC参数顺序:
 *   Δf1,f1_scale,Δf2,f2_scale,k14,k05,k04,k03,k13,k23,
 *   k02,k12,k22,k32,k01,k11,k21,k31,k41,k00,k10,k20,k30,k40,k50
 * ==================================================================================== */

/* PS默认参数 (Δf1=65000, f1_scale=3800, Δf2=59000, f2_scale=3700) */
static const float s_default_ps_params[25] = {
    65000.0f, 3800.0f, 59000.0f, 3700.0f,
    23392.128518f, 4781.604294f, 894.836195f, -80.166787f, 3521.446816f, 45853.375261f,
    -31.061953f, -225.548104f, 5228.960876f, 45020.691682f,
    -538.863937f, -11.107721f, -210.360991f, 3472.179803f, 22136.615546f,
    661.933891f, 628.383544f, 19.318891f, -65.337509f, 869.761164f, 4363.371597f
};

/* TS默认参数 (Δf1=67000, f1_scale=3400, Δf2=57000, f2_scale=3500) */
static const float s_default_ts_params[25] = {
    67000.0f, 3400.0f, 57000.0f, 3500.0f,
    -51540.666802f, -10639.306226f, -8574.159444f, -1192.055229f, -33349.524963f, -100950.282909f,
    62.531171f, -3451.915184f, -49029.201003f, -99943.395118f,
    -198.060965f, 134.729419f, -3351.636471f, -32289.226921f, -50012.792114f,
    17.709475f, -194.948391f, 64.674796f, -1090.735473f, -8038.003013f, -10118.257036f
};

/* PT默认参数 (Δf1=69000, f1_scale=3500, Δf2=55000, f2_scale=3900) */
static const float s_default_pt_params[25] = {
    69000.0f, 3500.0f, 55000.0f, 3900.0f,
    27012.526537f, 5530.603019f, 1652.604618f, 23.328971f, 6446.174426f, 52894.765013f,
    -34.398654f, 67.879673f, 9479.932671f, 51909.653386f,
    -512.135010f, -15.992962f, 67.368365f, 6230.225024f, 25533.491431f,
    1904.967029f, 628.062869f, 13.823200f, 23.709267f, 1544.080372f, 5036.415497f
};

/* ====================================================================================
 * Flash标定参数 (PS/PT双区间)
 *
 * PS: 用于 ≤1200hPa 的气压计算
 * PT: 用于 >1200hPa 时重新计算
 *
 * 参数布局 (25个double):
 *   [0] = Δf1, [1] = f1_scale, [2] = Δf2, [3] = f2_scale
 *   [4-24] = 21个k[i][j]多项式系数 (下三角展开)
 *
 * TPC指令参数顺序:
 *   Δf1,f1_scale,Δf2,f2_scale,k14,k05,k04,k03,k13,k23,
 *   k02,k12,k22,k32,k01,k11,k21,k31,k41,k00,k10,k20,k30,k40,k50
 * ==================================================================================== */

/* PS参数 (≤1200hPa) */
static float    s_ps_delta_f1   = DELTA_PS1;
static float    s_ps_f1_scale   = PS1;
static float    s_ps_delta_f2   = DELTA_PS2;
static float    s_ps_f2_scale   = PS2;
static float    s_ps_k[6][6];
static uint8_t  s_ps_loaded     = 0;

/* PT参数 (>1200hPa) */
static float    s_pt_delta_f1   = DELTA_PS1;
static float    s_pt_f1_scale   = PS1;
static float    s_pt_delta_f2   = DELTA_PS2;
static float    s_pt_f2_scale   = PS2;
static float    s_pt_k[6][6];
static uint8_t  s_pt_loaded     = 0;

/* TS参数 (温度计算) */
static float    s_ts_delta_f1   = 67000.0f;
static float    s_ts_f1_scale   = 3400.0f;
static float    s_ts_delta_f2   = 57000.0f;
static float    s_ts_f2_scale   = 3500.0f;
static float    s_ts_k[6][6];
static uint8_t  s_ts_loaded     = 0;

/* Flash参数是否已加载 */
static uint8_t  s_flash_params_loaded = 0;

/* ====================================================================================
 * TPC参数索引到k[i][j]的映射表
 *
 * TPC参数顺序: k14,k05,k04,k03,k13,k23,k02,k12,k22,k32,k01,k11,k21,k31,k41,k00,k10,k20,k30,k40,k50
 * 索引4~24对应k[i][j]:
 *   [4] =k[1][4], [5] =k[0][5], [6] =k[0][4], [7] =k[0][3]
 *   [8] =k[1][3], [9] =k[2][3], [10]=k[0][2], [11]=k[1][2]
 *   [12]=k[2][2], [13]=k[3][2], [14]=k[0][1], [15]=k[1][1]
 *   [16]=k[2][1], [17]=k[3][1], [18]=k[4][1], [19]=k[0][0]
 *   [20]=k[1][0], [21]=k[2][0], [22]=k[3][0], [23]=k[4][0]
 *   [24]=k[5][0]
 * ==================================================================================== */
static void parse_params_to_k(const float params[25], float k_out[6][6])
{
    memset(k_out, 0, sizeof(float) * 36);

    /* k_out[i][j] = y^i * x^j 的系数
     * i=行=y的幂次, j=列=x的幂次
     * 与 Python pressure_calc.py 的 K[i][j] 布局一致 */
    k_out[0][0] = params[19];   /* k00 */
    k_out[0][1] = params[20];   /* k01 */
    k_out[0][2] = params[21];   /* k02 */
    k_out[0][3] = params[22];   /* k03 */
    k_out[0][4] = params[23];   /* k04 */
    k_out[0][5] = params[24];   /* k05 */
    k_out[1][0] = params[14];   /* k10 */
    k_out[1][1] = params[15];   /* k11 */
    k_out[1][2] = params[16];   /* k12 */
    k_out[1][3] = params[17];   /* k13 */
    k_out[1][4] = params[18];   /* k14 */
    k_out[2][0] = params[10];   /* k20 */
    k_out[2][1] = params[11];   /* k21 */
    k_out[2][2] = params[12];   /* k22 */
    k_out[2][3] = params[13];   /* k23 */
    k_out[3][0] = params[7];    /* k30 */
    k_out[3][1] = params[8];    /* k31 */
    k_out[3][2] = params[9];    /* k32 */
    k_out[4][0] = params[6];    /* k40 */
    k_out[4][1] = params[4];    /* k41 */
    k_out[5][0] = params[5];    /* k50 */
}

/* ====================================================================================
 * 滑动窗口
 * ==================================================================================== */
static uint32_t s_ch1_buf[PRESSURE_WINDOW_SIZE];
static uint32_t s_ch2_buf[PRESSURE_WINDOW_SIZE];
static uint8_t  s_count     = 0;
static uint8_t  s_write_idx = 0;

/* ====================================================================================
 * 公共函数实现
 * ==================================================================================== */

void pressure_calc_init(void)
{
    uint8_t i;
    for (i = 0; i < PRESSURE_WINDOW_SIZE; i++)
    {
        s_ch1_buf[i] = 0;
        s_ch2_buf[i] = 0;
    }
    s_count     = 0;
    s_write_idx = 0;

    /* 使用默认参数初始化 */
    set_ps_params_from_float(s_default_ps_params);
    set_pt_params_from_float(s_default_pt_params);
    set_ts_params_from_float(s_default_ts_params);
}

void pressure_calc_push(uint32_t ch1_freq_x1000, uint32_t ch2_freq_x1000)
{
    s_ch1_buf[s_write_idx] = ch1_freq_x1000;
    s_ch2_buf[s_write_idx] = ch2_freq_x1000;

    s_write_idx++;
    if (s_write_idx >= PRESSURE_WINDOW_SIZE)
        s_write_idx = 0;

    if (s_count < PRESSURE_WINDOW_SIZE)
        s_count++;
}

/* 内部多项式计算: 使用指定的参数计算气压 */
static float calc_polynomial(const float k[6][6], float delta_f1, float f1_scale,
                              float delta_f2, float f2_scale)
{
    float result = 0.0f;
    uint8_t i, j;
    uint64_t sum1 = 0, sum2 = 0;

    for (i = 0; i < s_count; i++)
    {
        sum1 += s_ch1_buf[i];
        sum2 += s_ch2_buf[i];
    }

    float f1 = (float)(sum1 / s_count) / 1000.0f;
    float f2 = (float)(sum2 / s_count) / 1000.0f;
    float x  = (f1 - delta_f1) / f1_scale;
    float y  = (f2 - delta_f2) / f2_scale;

    /* 输入限幅: x,y超出[-3,3]说明窗口有异常值 */
    if (x > 3.0f || x < -3.0f || y > 3.0f || y < -3.0f)
        return -9999.0f;  /* 异常标记 */

    /* 预计算 x 和 y 的各次幂 */
    float xp[6], yp[6];
    xp[0] = 1.0f;  yp[0] = 1.0f;
    for (i = 1; i < 6; i++)
    {
        xp[i] = xp[i - 1] * x;
        yp[i] = yp[i - 1] * y;
    }

    /* 多项式累加: result += k[i][j] * x^j * y^i */
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6 - i; j++)
        {
            result += k[i][j] * xp[j] * yp[i];
        }
    }

    return result;
}

float pressure_calc_get(void)
{
    float result;
    static float s_last_valid = 0.0f;  /* 上一次有效气压值 */

    if (s_count == 0)
        return 0.0f;

    /* PS/PT双区间逻辑:
     * 1. 先用PS系数计算
     * 2. 如果结果>1200，改用PT系数重新计算
     */
    result = calc_polynomial(s_ps_k, s_ps_delta_f1, s_ps_f1_scale,
                             s_ps_delta_f2, s_ps_f2_scale);

    /* 异常检查 */
    if (result < -9000.0f)
        return (s_last_valid > 0.0f) ? s_last_valid : 0.0f;

    /* 如果PS结果>1200且PT参数已加载，改用PT重新计算 */
    if (result > 1200.0f && s_pt_loaded)
    {
        result = calc_polynomial(s_pt_k, s_pt_delta_f1, s_pt_f1_scale,
                                 s_pt_delta_f2, s_pt_f2_scale);
        if (result < -9000.0f)
            return (s_last_valid > 0.0f) ? s_last_valid : 0.0f;
    }

    if (result > 0.0f) s_last_valid = result;
    return result;
}

uint8_t pressure_calc_count(void)
{
    return s_count;
}

/* ====================================================================================
 * 气压→高度转换 (三层大气模型, ISA标准)
 * ====================================================================================
 *
 * 常数:
 *   R  = 287.05287 m²/(K·s²)    干空气气体常数
 *   gn = 9.80665   m/s²          标准重力加速度
 *
 * 第一层 对流层: 226.32 < Ps < 1277.74 hPa, H = -2000 ~ 11000 m
 *   β=-0.0065 K/m, Hb=-2000m, Tb=301.15K, Pb=1277.74 hPa
 *   H = (Tb/β) × [(Ps/Pb)^(-βR/gn) - 1] + Hb
 *
 * 第二层 等温层: 54.75 ≤ Ps ≤ 226.32 hPa, H = 11000 ~ 20000 m
 *   β=0, Hb=11000m, Tb=216.65K, Pb=226.32 hPa
 *   H = (R·Tb/gn) × ln(Pb/Ps) + Hb
 *
 * 第三层 逆温层: Ps < 54.75 hPa, H = 20000 ~ 32000 m
 *   β=0.001 K/m, Hb=20000m, Tb=216.65K, Pb=54.7487 hPa
 *   H = (Tb/β) × [(Ps/Pb)^(-βR/gn) - 1] + Hb
 * ==================================================================================== */

/* 预计算的无量纲指数 */
#define L1_EXPONENT   0.1902631f   /* -βR/gn = 0.0065*287.05287/9.80665 */
#define L3_EXPONENT  -0.02927125f  /* -βR/gn = -0.001*287.05287/9.80665 */

float pressure_to_altitude(float pressure_hpa)
{
    float h;

    if (pressure_hpa <= 0.0f)
        return 0.0f;

    if (pressure_hpa > 226.32f)
    {
        /* 第一层: 对流层, β=-0.0065, Tb/β = -46330.77 */
        float ratio = pressure_hpa / 1277.74f;
        h = -(301.15f / 0.0065f) * (powf(ratio, L1_EXPONENT) - 1.0f) - 2000.0f;
    }
    else if (pressure_hpa >= 54.75f)
    {
        /* 第二层: 等温层 */
        h = (287.05287f * 216.65f / 9.80665f) * logf(226.32f / pressure_hpa) + 11000.0f;
    }
    else
    {
        /* 第三层: 逆温层 */
        float ratio = pressure_hpa / 54.7487f;
        h = (216.65f / 0.001f) * (powf(ratio, L3_EXPONENT) - 1.0f) + 20000.0f;
    }

    return h;
}

uint8_t pressure_calc_get_window(uint32_t *ch1_out, uint32_t *ch2_out)
{
    uint8_t i;
    for (i = 0; i < s_count; i++)
    {
        uint8_t idx = (s_write_idx + PRESSURE_WINDOW_SIZE - s_count + i) % PRESSURE_WINDOW_SIZE;
        ch1_out[i] = s_ch1_buf[idx];
        ch2_out[i] = s_ch2_buf[idx];
    }
    return s_count;
}

/* ====================================================================================
 * 温度计算 (使用TS参数)
 *
 * 公式: T = Σ k[i][j] * x^j * y^i
 * 其中: x = (f1 - Δf1) / f1_scale
 *       y = (f2 - Δf2) / f2_scale
 * ==================================================================================== */
float temperature_calc_get(void)
{
    float result = 0.0f;
    uint8_t i, j;
    static float s_last_valid = 0.0f;

    if (s_count == 0 || !s_ts_loaded)
        return 0.0f;

    /* 求频率均值 */
    {
        uint64_t sum1 = 0, sum2 = 0;
        for (i = 0; i < s_count; i++)
        {
            sum1 += s_ch1_buf[i];
            sum2 += s_ch2_buf[i];
        }

        float f1 = (float)(sum1 / s_count) / 1000.0f;
        float f2 = (float)(sum2 / s_count) / 1000.0f;
        float x  = (f1 - s_ts_delta_f1) / s_ts_f1_scale;
        float y  = (f2 - s_ts_delta_f2) / s_ts_f2_scale;

        /* 输入限幅 */
        if (x > 3.0f || x < -3.0f || y > 3.0f || y < -3.0f)
            return (s_last_valid != 0.0f) ? s_last_valid : 0.0f;

        /* 预计算 x 和 y 的各次幂 */
        float xp[6], yp[6];
        xp[0] = 1.0f;  yp[0] = 1.0f;
        for (i = 1; i < 6; i++)
        {
            xp[i] = xp[i - 1] * x;
            yp[i] = yp[i - 1] * y;
        }

        /* 多项式累加 */
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 6 - i; j++)
            {
                result += s_ts_k[i][j] * xp[j] * yp[i];
            }
        }
    }

    s_last_valid = result;
    return result;
}

/* ====================================================================================
 * 标定参数设置函数 (由protocol.c调用)
 * ==================================================================================== */

void pressure_calc_set_params(float delta_f1, float f1_scale,
                               float delta_f2, float f2_scale,
                               const float k[6][6])
{
    (void)delta_f1; (void)f1_scale; (void)delta_f2; (void)f2_scale; (void)k;
    /* 保留接口兼容性，实际使用set_ps/pt_params */
}

void pressure_calc_set_ps_params(const double params[25])
{
    float fparams[25];
    uint8_t i;
    for (i = 0; i < 25; i++) fparams[i] = (float)params[i];

    s_ps_delta_f1 = fparams[0];
    s_ps_f1_scale = fparams[1];
    s_ps_delta_f2 = fparams[2];
    s_ps_f2_scale = fparams[3];
    parse_params_to_k(fparams, s_ps_k);
    s_ps_loaded = 1;
    s_flash_params_loaded = 1;
}

void pressure_calc_set_pt_params(const double params[25])
{
    float fparams[25];
    uint8_t i;
    for (i = 0; i < 25; i++) fparams[i] = (float)params[i];

    s_pt_delta_f1 = fparams[0];
    s_pt_f1_scale = fparams[1];
    s_pt_delta_f2 = fparams[2];
    s_pt_f2_scale = fparams[3];
    parse_params_to_k(fparams, s_pt_k);
    s_pt_loaded = 1;
}

uint8_t pressure_calc_has_flash_params(void)
{
    return s_flash_params_loaded;
}

/* 内部函数: 从float数组设置PS参数 (用于默认参数初始化) */
static void set_ps_params_from_float(const float params[25])
{
    s_ps_delta_f1 = params[0];
    s_ps_f1_scale = params[1];
    s_ps_delta_f2 = params[2];
    s_ps_f2_scale = params[3];
    parse_params_to_k(params, s_ps_k);
    s_ps_loaded = 1;
}

/* 内部函数: 从float数组设置PT参数 (用于默认参数初始化) */
static void set_pt_params_from_float(const float params[25])
{
    s_pt_delta_f1 = params[0];
    s_pt_f1_scale = params[1];
    s_pt_delta_f2 = params[2];
    s_pt_f2_scale = params[3];
    parse_params_to_k(params, s_pt_k);
}

/* 内部函数: 从float数组设置TS参数 (用于默认参数初始化) */
static void set_ts_params_from_float(const float params[25])
{
    s_ts_delta_f1 = params[0];
    s_ts_f1_scale = params[1];
    s_ts_delta_f2 = params[2];
    s_ts_f2_scale = params[3];
    parse_params_to_k(params, s_ts_k);
    s_ts_loaded = 1;
}

void pressure_calc_set_ts_params(const double params[25])
{
    float fparams[25];
    uint8_t i;
    for (i = 0; i < 25; i++) fparams[i] = (float)params[i];

    s_ts_delta_f1 = fparams[0];
    s_ts_f1_scale = fparams[1];
    s_ts_delta_f2 = fparams[2];
    s_ts_f2_scale = fparams[3];
    parse_params_to_k(fparams, s_ts_k);
    s_ts_loaded = 1;
}
