#ifndef __USART_H
#define __USART_H

#include "stdio.h"
#include "sys.h"
/* DMA 接收环形缓冲区大小 (必须是2的幂, DMA循环模式要求) */
#define USART_DMA_RX_BUF_SIZE       1024

/* DMA 接收缓冲区 + 帧提取接口 */
extern uint8_t  g_usart_dma_rx_buf[USART_DMA_RX_BUF_SIZE];

extern volatile uint8_t  g_usart_dma_tx_busy;     /* 1=TX DMA忙 */

void usart_init(uint32_t bound);                 /* 串口初始化函数 */
void usart_baud_set(uint32_t baud);              /* 动态切换波特率 */
void usart_parity_set(uint8_t parity);           /* 动态切换校验位 (0=无 1=奇 2=偶) */
void usart_data_bits_set(uint8_t data_bits);     /* 动态切换数据位 (0=8bit 1=9bit, 仅无校验时生效) */
void usart_stop_bits_set(uint8_t stop_bits);     /* 动态切换停止位 (0=1bit 1=2bit) */
void usart_dma_send(uint8_t *buf, uint16_t len); /* DMA发送数据 */

#endif
