#include "sys.h"
#include "usart.h"
#include "led.h"
#include "protocol.h"
#include <string.h>

/* 使用OS时的头文件包含 */
#if SYS_SUPPORT_OS
#include "includes.h" /* os 使用 */
#endif

/******************************************************************************************/
/* 加入以下代码, 支持printf函数, 不需要选择use MicroLIB */

#if 1

#if (__ARMCC_VERSION >= 6010050)            /* 使用AC6编译器时 */
__asm(".global __use_no_semihosting\n\t");  /* 声明不使用半主机模式 */
__asm(".global __ARM_use_no_argv \n\t");    /* AC6需要声明main函数为无参数形式 */
#else
/* 使用AC5编译器时, 在这里定义__FILE 和不使用半主机模式 */
#pragma import(__use_no_semihosting)

struct __FILE
{
    int handle;
};
#endif

int _ttywrch(int ch)
{
    ch = ch;
    return ch;
}

void _sys_exit(int x)
{
    x = x;
}

char *_sys_command_string(char *cmd, int len)
{
    return NULL;
}

FILE __stdout;

/* printf 重定向: 单字节TC轮询 (低频调用, 保留) */
int fputc(int ch, FILE *f)
{
    while(RESET == usart_flag_get(USART0, USART_FLAG_TC));
    usart_data_transmit(USART0, (uint8_t)ch);
    return ch;
}
#endif
/******************************************************************************************/


/* ====================================================================================
 * DMA 接收环形缓冲 + 帧提取
 * ==================================================================================== */
uint8_t  g_usart_dma_rx_buf[USART_DMA_RX_BUF_SIZE];

volatile uint8_t  g_usart_dma_tx_busy    = 0;

static uint16_t s_dma_rx_last_cnt = USART_DMA_RX_BUF_SIZE;

/* DMA TX 源缓冲 */
static uint8_t s_dma_tx_buf[1200];

/* ====================================================================================
 * 静态函数声明
 * ==================================================================================== */
static void dma_rx_init(void);
static void dma_tx_init(void);
static void usart_dma_rx_frame_extract(void);

/* ====================================================================================
 * 公共: 串口初始化 (DMA + IDLE中断)
 * ==================================================================================== */
/**
 * @brief 初始化USART串口通信
 * @param bound 波特率设置值
 * @note 该函数完成GPIO、USART、DMA和中断的初始化配置
 */
void usart_init(uint32_t bound)
{
    /* GPIO + USART 基础 */
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_AF);
    rcu_periph_clock_enable(RCU_USART0);

    gpio_init(GPIOA, GPIO_MODE_AF_PP,      GPIO_OSPEED_50MHZ, GPIO_PIN_9);
    gpio_init(GPIOA, GPIO_MODE_IN_FLOATING, GPIO_OSPEED_50MHZ, GPIO_PIN_10);

    usart_deinit(USART0);
    usart_baudrate_set(USART0, bound);
    usart_stop_bit_set(USART0, USART_STB_1BIT);
    usart_word_length_set(USART0, USART_WL_8BIT);
    usart_parity_config(USART0, USART_PM_NONE);
    usart_receive_config(USART0, USART_RECEIVE_ENABLE);
    usart_transmit_config(USART0, USART_TRANSMIT_ENABLE);

    /* IDLE 中断替代 RBNE */
    usart_interrupt_enable(USART0, USART_INT_IDLE);
    nvic_irq_enable(USART0_IRQn, 3, 3);

    /* DMA */
    dma_rx_init();
    dma_tx_init();

    usart_enable(USART0);
}

/* ====================================================================================
 * DMA0 CH4: USART0_RX → g_usart_dma_rx_buf (环形)
 * ==================================================================================== */
static void dma_rx_init(void)
{
    rcu_periph_clock_enable(RCU_DMA0);

    dma_deinit(DMA0, DMA_CH4);

    dma_parameter_struct cfg;
    dma_struct_para_init(&cfg);
    cfg.periph_addr  = (uint32_t)(&USART_DATA(USART0));
    cfg.memory_addr  = (uint32_t)g_usart_dma_rx_buf;
    cfg.direction    = DMA_PERIPHERAL_TO_MEMORY;
    cfg.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;
    cfg.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;
    cfg.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    cfg.memory_width = DMA_MEMORY_WIDTH_8BIT;
    cfg.number       = USART_DMA_RX_BUF_SIZE;
    cfg.priority     = DMA_PRIORITY_HIGH;
    dma_init(DMA0, DMA_CH4, &cfg);

    dma_circulation_enable(DMA0, DMA_CH4);
    dma_channel_enable(DMA0, DMA_CH4);
    usart_dma_receive_config(USART0, USART_RECEIVE_DMA_ENABLE);

    s_dma_rx_last_cnt = USART_DMA_RX_BUF_SIZE;
}

/* ====================================================================================
 * DMA0 CH3: s_dma_tx_buf → USART0_TX (单次, 非环形)
 * ==================================================================================== */
static void dma_tx_init(void)
{
    dma_deinit(DMA0, DMA_CH3);

    dma_parameter_struct cfg;
    dma_struct_para_init(&cfg);
    cfg.periph_addr  = (uint32_t)(&USART_DATA(USART0));
    cfg.memory_addr  = (uint32_t)s_dma_tx_buf;
    cfg.direction    = DMA_MEMORY_TO_PERIPHERAL;
    cfg.periph_inc   = DMA_PERIPH_INCREASE_DISABLE;
    cfg.memory_inc   = DMA_MEMORY_INCREASE_ENABLE;
    cfg.periph_width = DMA_PERIPHERAL_WIDTH_8BIT;
    cfg.memory_width = DMA_MEMORY_WIDTH_8BIT;
    cfg.number       = 0;
    cfg.priority     = DMA_PRIORITY_MEDIUM;
    dma_init(DMA0, DMA_CH3, &cfg);

    dma_interrupt_enable(DMA0, DMA_CH3, DMA_INT_FTF);
    nvic_irq_enable(DMA0_Channel3_IRQn, 2, 2);

    usart_dma_transmit_config(USART0, USART_TRANSMIT_DMA_ENABLE);
}

/* ====================================================================================
 * DMA0 CH3 传输完成中断
 * ==================================================================================== */
void DMA0_Channel3_IRQHandler(void)
{
    if (dma_interrupt_flag_get(DMA0, DMA_CH3, DMA_INT_FLAG_FTF) != RESET)
    {
        dma_interrupt_flag_clear(DMA0, DMA_CH3, DMA_INT_FLAG_FTF);
        dma_channel_disable(DMA0, DMA_CH3);
        g_usart_dma_tx_busy = 0;
    }
}

/* ====================================================================================
 * 公共: 动态切换波特率 (用于 BR 指令)
 * ==================================================================================== */
void usart_baud_set(uint32_t baud)
{
    /* 等待在发字节完全结束再改波特率, 否则该字节时序被破坏 */
    while (g_usart_dma_tx_busy);
    while (RESET == usart_flag_get(USART0, USART_FLAG_TC));

    usart_baudrate_set(USART0, baud);
}

void usart_parity_set(uint8_t parity)
{
    /* 等待当前发送完全结束:
     * 只等 g_usart_dma_tx_busy 不够 — DMA 完成仅表示最后一个字节
     * 已写入发送数据寄存器, 移位寄存器还需约1个字符时间才发完.
     * 若不等 TC 就改帧格式, 正在发送的最后一个字节会被截断/损坏 */
    while (g_usart_dma_tx_busy);
    while (RESET == usart_flag_get(USART0, USART_FLAG_TC));

    /* 先停 USART: 帧格式位(PCEN/PM/WL)必须在 UEN=0 时修改 */
    usart_disable(USART0);

    /* 重新读取寄存器(此刻 UEN=0), 先清空三个位再按需设置 */
    {
        uint32_t ctl0 = USART_CTL0(USART0);
        ctl0 &= ~(USART_CTL0_PCEN | USART_CTL0_PM | USART_CTL0_WL);

        if (parity == 1)       /* 奇校验 */
        {
            ctl0 |= USART_CTL0_PCEN;   /* PEN=1 */
            ctl0 |= USART_CTL0_PM;     /* PM=1 (奇) */
            ctl0 |= USART_CTL0_WL;     /* WL=1: 9bit = 8数据 + 1校验 */
        }
        else if (parity == 2)  /* 偶校验 */
        {
            ctl0 |= USART_CTL0_PCEN;   /* PEN=1 */
            ctl0 |= USART_CTL0_WL;     /* WL=1: 9bit = 8数据 + 1校验 (PM=0 偶) */
        }
        /* 0 = 无校验: 保持清空, 8bit */

        /* UEN 仍为 0 时一次性写回配置 */
        USART_CTL0(USART0) = ctl0;
    }

    usart_enable(USART0);

    /* 清掉切换窗口内可能置起的接收错误标志 (STAT0 bit0~3: PERR/FERR/NERR/ORERR),
     * 防止残留错误状态影响后续帧的接收判断 */
    USART_STAT0(USART0) &= ~(BIT(0) | BIT(1) | BIT(2) | BIT(3));
}

/* ====================================================================================
 * 公共: 动态切换数据位 (仅无校验时生效)
 *   data_bits: 0=8bit, 1=9bit
 *   校验使能时 WL 由 usart_parity_set 控制, 本函数不操作
 * ==================================================================================== */
void usart_data_bits_set(uint8_t data_bits)
{
    uint32_t ctl0 = USART_CTL0(USART0);

    /* 有校验时 WL 必须为 1 (8数据+1校验), 数据位设置无意义 */
    if (ctl0 & USART_CTL0_PCEN)
        return;

    usart_disable(USART0);

    ctl0 = USART_CTL0(USART0);
    if (data_bits == 1)      /* 9bit */
        ctl0 |= USART_CTL0_WL;
    else                     /* 8bit */
        ctl0 &= ~USART_CTL0_WL;

    USART_CTL0(USART0) = ctl0;
    usart_enable(USART0);
}

/* ====================================================================================
 * 公共: 动态切换停止位
 *   stop_bits: 0=1bit, 1=2bit
 * ==================================================================================== */
void usart_stop_bits_set(uint8_t stop_bits)
{
    /* 等待在发字节完全结束, 避免改帧格式截断发送 */
    while (g_usart_dma_tx_busy);
    while (RESET == usart_flag_get(USART0, USART_FLAG_TC));

    usart_disable(USART0);

    if (stop_bits == 1)
        usart_stop_bit_set(USART0, USART_STB_2BIT);
    else
        usart_stop_bit_set(USART0, USART_STB_1BIT);

    usart_enable(USART0);
}

/* ====================================================================================
 * 公共: DMA发送数据块
 * ==================================================================================== */
void usart_dma_send(uint8_t *buf, uint16_t len)
{
    if (len == 0 || len > 1200) return;

    while (g_usart_dma_tx_busy);   /* 等待上次发送完成 */

    memcpy(s_dma_tx_buf, buf, len);

    dma_channel_disable(DMA0, DMA_CH3);
    dma_memory_address_config(DMA0, DMA_CH3, (uint32_t)s_dma_tx_buf);
    dma_transfer_number_config(DMA0, DMA_CH3, len);

    g_usart_dma_tx_busy = 1;
    dma_channel_enable(DMA0, DMA_CH3);
}

/* ====================================================================================
 * USART0 IDLE 中断: 总线空闲 → 帧边界
 *
 * 原理:
 *   DMA持续将字节写入环形缓冲区.
 *   当RX线空闲超过1字符时间, 硬件置 IDLE 标志.
 *   中断中计算本次收到的字节数, 从环形缓冲区拷贝到线性帧缓冲,
 *   按帧头 '#' 分别路由到新/旧协议处理器.
 * ==================================================================================== */
void USART0_IRQHandler(void)
{
#if SYSTEM_SUPPORT_OS
    OSIntEnter();
#endif

    if (usart_interrupt_flag_get(USART0, USART_INT_FLAG_IDLE) != RESET)
    {
        /* 读STAT0检查错误标志, 再读DATA清IDLE */
        volatile uint32_t stat = USART_STAT0(USART0);
        volatile uint32_t data = USART_DATA(USART0);
        (void)data;

        /* bit0=PERR bit1=FERR bit2=NERR bit3=ORERR */
        if (stat & (BIT(0) | BIT(1) | BIT(2) | BIT(3)))
        {
            /* 有校验/帧/噪声/溢出错误 → 丢弃本帧 */
            s_dma_rx_last_cnt = dma_transfer_number_get(DMA0, DMA_CH4);
        }
        else
        {
            /* 无错误 → 正常提取帧 */
            usart_dma_rx_frame_extract();
            LED1_TOGGLE();
        }
    }

#if SYSTEM_SUPPORT_OS
    OSIntExit();
#endif
}

/* ====================================================================================
 * 静态: 从DMA环形缓冲区提取帧
 *
 * DMA CHCNT向下计数. 本次收到字节数 = (last - curr + SIZE) % SIZE.
 * 读取起始位置 = (SIZE - last) % SIZE.
 *
 * 路由:
 *   首字节 '#' → 拷入 g_proto_rx_buf, 置 g_proto_frame_ready
 *   否则       → 丢弃 (非协议帧)
 * ==================================================================================== */
static void usart_dma_rx_frame_extract(void)
{
    uint16_t curr_cnt = dma_transfer_number_get(DMA0, DMA_CH4);
    uint16_t last_cnt = s_dma_rx_last_cnt;
    uint16_t rx_len;
    uint16_t start;
    uint16_t i;

    if (last_cnt >= curr_cnt)
        rx_len = last_cnt - curr_cnt;
    else
        rx_len = USART_DMA_RX_BUF_SIZE - curr_cnt + last_cnt;

    s_dma_rx_last_cnt = curr_cnt;

    if (rx_len == 0) return;

    start = (USART_DMA_RX_BUF_SIZE - last_cnt) % USART_DMA_RX_BUF_SIZE;

    /* ---- 帧路由 ---- */
    {
        uint8_t first = g_usart_dma_rx_buf[start];

        if (first == '#' || g_proto_rx_idx == 0)
        {
            /* === 新帧: 覆盖旧缓冲 === */
            if (rx_len < PROTO_RX_BUF_SIZE)
            {
                for (i = 0; i < rx_len; i++)
                    g_proto_rx_buf[i] = g_usart_dma_rx_buf[(start + i) % USART_DMA_RX_BUF_SIZE];
                g_proto_rx_idx = rx_len;
            }
        }
        else
        {
            /* === 续帧: 追加到已有帧后面 === */
            uint16_t new_len = g_proto_rx_idx + rx_len;
            if (new_len < PROTO_RX_BUF_SIZE)
            {
                for (i = 0; i < rx_len; i++)
                    g_proto_rx_buf[g_proto_rx_idx + i] = g_usart_dma_rx_buf[(start + i) % USART_DMA_RX_BUF_SIZE];
                g_proto_rx_idx = new_len;
            }
        }
    }

    /* 只有收到完整帧(含\r)才通知主循环处理 */
    {
        uint8_t has_cr = 0;
        for (i = 0; i < g_proto_rx_idx; i++)
        {
            if (g_proto_rx_buf[i] == 0x0D) { has_cr = 1; break; }
        }
        if (has_cr) g_proto_frame_ready = 1;
    }
}
