/* ====================================================================================
 * 文件: main.c
 * 描述: GD32F303频率计主程序
 * ====================================================================================
 *
 * 功能说明:
 *   - 双通道等精度频率测量
 *   - 6点中值滤波 (一处滤波, 全局受益)
 *   - OLED显示双路测量结果
 *   - 串口命令控制（DAC输出、Flash读写）
 *
 * 数据流:
 *   原始频率 → [6点中值窗口] → freq_x1000 → 显示/协议/气压/printf 统一使用
 *
 * 引脚分配:
 *   - PA8:   CH1频率信号输入 (TIMER0_CH0)
 *   - PA0:   CH2频率信号输入 (TIMER1_ETI)
 *   - PB13/15: OLED I2C (软件模拟)
 *   - PA9/10: USART0 串口通信
 *   - PA4:   DAC输出
 *
 * 串口协议: #01XX<CMD>[DATA]\r<CKSUM> (见 protocol.c)
 * ==================================================================================== */

#include "sys.h"
#include "gd32f30x.h"
#include "usart.h"
#include "delay.h"
#include "led.h"
#include "oled.h"
//#include "key.h"
#include "dac.h"
#include "adc.h"
#include "string.h"
#include "stdlib.h"
#include "freq_measure.h"
#include "pressure_calc.h"
#include "protocol.h"

/* ==================== 全局变量定义 ==================== */
extern volatile uint32_t g_delay_comp;     /* 延迟补偿 */
uint32_t g_freq_ch1_x1000 = 0;            /* CH1 频率缓存 (中值, ×1000) */
uint32_t g_freq_ch2_x1000 = 0;            /* CH2 频率缓存 (中值, ×1000) */
uint32_t g_ref_ch1_cached  = 0;           /* CH1 基准计数缓存 */
uint32_t g_ref_ch2_cached  = 0;           /* CH2 基准计数缓存 */

/* ==================== 频率中值滤波 (单点滤波, 全局受益) ==================== */
#define FREQ_MEDIAN_WINDOW  6
static uint32_t s_freq1_win[FREQ_MEDIAN_WINDOW] = {0};
static uint32_t s_freq2_win[FREQ_MEDIAN_WINDOW] = {0};
static uint8_t  s_freq1_cnt = 0, s_freq1_idx = 0;
static uint8_t  s_freq2_cnt = 0, s_freq2_idx = 0;

/* 求中值 (插入排序, n≤6) */
static uint32_t freq_median(uint32_t *buf, uint8_t n)
{
    uint32_t s[6];
    uint8_t i, j;
    if (n == 0) return 0;
    for (i = 0; i < n; i++) s[i] = buf[i];
    for (i = 1; i < n; i++) {
        uint32_t k = s[i];
        for (j = i; j > 0 && s[j - 1] > k; j--) s[j] = s[j - 1];
        s[j] = k;
    }
    return (n & 1) ? s[n / 2] : (s[n / 2 - 1] + s[n / 2]) / 2;
}

/* ====================================================================================
 * 主函数
 * ==================================================================================== */

int main(void)
{
    /* ==================== 变量定义 ==================== */
    uint32_t freq_ch1_x1000 = 0;           // CH1频率×1000 (局部暂存)
    uint32_t freq_ch2_x1000 = 0;           // CH2频率×1000 (局部暂存)
    char disp_ch1[24] = "---";             // CH1显示字符串
    char disp_ch2[24] = "---";             // CH2显示字符串
    char disp_p[24] = "---";              // 气压显示字符串
    char disp_h[24] = "---";              // 高度显示字符串
    char disp_t[16] = "---";
    short temperature = 0;                /* MCU内部温度 ×100 */
    float pressure = 0.0f;                /* 气压值 */

    /* ==================== 系统初始化 ==================== */
    delay_init(120);                       /* 系统时钟120MHz */
    LED_Init();                            /* LED初始化 */

    /* 从内部Flash加载版本号和运行参数 */
    flash_store_init();                    /* 读内部Flash, 版本号 */
    flash_cfg_init();                      /* 读内部Flash, 波特率/站号等 */

    /* UART 直接以 Flash 保存的波特率+校验位+数据位启动 */
    usart_init(flash_cfg_get_baud());
    usart_data_bits_set(flash_cfg_get_data_bits());
    usart_parity_set(flash_cfg_get_parity());
    usart_stop_bits_set(flash_cfg_get_stop_bits());

    OLED_Init();                           /* OLED初始化 */
    Dac_Init();                            /* DAC初始化 */
    freq_measure_init();                   /* 频率测量模块初始化 */
    pressure_calc_init();                  /* 气压计算模块初始化 */
    protocol_init();                       /* 通信协议初始化 */
    adc_temperature_init();

    /* ==================== OLED初始界面 ==================== */
    OLED_Clear();
    OLED_ShowString(0, 0, "Freq+Pressure", 16);
    OLED_ShowString(0, 16, "CH1:PA8 CH2:PA0", 12);
    OLED_ShowString(0, 32, "P: 2D Poly 6pt", 12);
    OLED_Refresh_Gram();

    printf("\r\n=========================================\r\n");
    printf("   GD32F303CCT6 Dual Frequency Meter    \r\n");
    printf("=========================================\r\n");
    {
        const char *parity_str = "N";
        uint8_t p = flash_cfg_get_parity();
        if (p == 1) parity_str = "O";
        else if (p == 2) parity_str = "E";
        printf("System OK!  Baud: %lu bps  Parity: %s\r\n",
               (unsigned long)flash_cfg_get_baud(), parity_str);
    }
    printf("CH1: PA8 (TIMER0), CH2: PA0 (TIMER1)\r\n");
    printf("Method: Equal Precision, Gate: variable (PR/PPI), default 100ms\r\n");
    printf("[Flash] Internal Flash OK (Config @ 0x08038800)\r\n");

    /* ==================== 主循环 - 频率测量 ==================== */
    printf("\r\n[System] Starting measurement...\r\n");

    /* 启动两路独立测量 */
    freq_measure_ch1_start();
    freq_measure_ch2_start();

    uint8_t ch1_new = 0, ch2_new = 0;

    while (1)
    {
        uint8_t need_refresh = 0;

        /* ---- CH1 完成: 推入中值窗口, 滤波后统一下发 ---- */
        if (g_ch1_measure_done == 1)
        {
            uint32_t raw = freq_measure_calculate();
            g_ref_ch1_cached  = g_ch1_ref_count;

            /* 推入中值窗口, freq_ch1_x1000 即为中值, 下游统一使用 */
            s_freq1_win[s_freq1_idx] = raw;
            s_freq1_idx = (s_freq1_idx + 1) % FREQ_MEDIAN_WINDOW;
            if (s_freq1_cnt < FREQ_MEDIAN_WINDOW) s_freq1_cnt++;
            freq_ch1_x1000 = freq_median(s_freq1_win, s_freq1_cnt);
            g_freq_ch1_x1000 = freq_ch1_x1000;   /* 协议也用中值 */

            if (freq_ch1_x1000 >= 1000000000UL)
                sprintf(disp_ch1, "%lu.%04luMHz", (unsigned long)(freq_ch1_x1000 / 1000000000UL), (unsigned long)((freq_ch1_x1000 / 100000UL) % 10000));
            else if (freq_ch1_x1000 >= 1000000UL)
                sprintf(disp_ch1, "%lu.%04lukHz", (unsigned long)(freq_ch1_x1000 / 1000000UL), (unsigned long)((freq_ch1_x1000 / 100UL) % 10000));
            else
                sprintf(disp_ch1, "%lu.%03luHz ", (unsigned long)(freq_ch1_x1000 / 1000), (unsigned long)(freq_ch1_x1000 % 1000));

            freq_measure_ch1_start();
            ch1_new = 1;
        }

        /* ---- CH2 完成: 推入中值窗口, 滤波后统一下发 ---- */
        if (g_ch2_measure_done == 1)
        {
            uint32_t raw = freq_measure_ch2_calculate();
            g_ref_ch2_cached  = g_ch2_ref_count;

            /* 推入中值窗口, freq_ch2_x1000 即为中值, 下游统一使用 */
            s_freq2_win[s_freq2_idx] = raw;
            s_freq2_idx = (s_freq2_idx + 1) % FREQ_MEDIAN_WINDOW;
            if (s_freq2_cnt < FREQ_MEDIAN_WINDOW) s_freq2_cnt++;
            freq_ch2_x1000 = freq_median(s_freq2_win, s_freq2_cnt);
            g_freq_ch2_x1000 = freq_ch2_x1000;   /* 协议也用中值 */

            if (freq_ch2_x1000 >= 1000000000UL)
                sprintf(disp_ch2, "%lu.%04luMHz", (unsigned long)(freq_ch2_x1000 / 1000000000UL), (unsigned long)((freq_ch2_x1000 / 100000UL) % 10000));
            else if (freq_ch2_x1000 >= 1000000UL)
                sprintf(disp_ch2, "%lu.%04lukHz", (unsigned long)(freq_ch2_x1000 / 1000000UL), (unsigned long)((freq_ch2_x1000 / 100UL) % 10000));
            else
                sprintf(disp_ch2, "%lu.%03luHz ", (unsigned long)(freq_ch2_x1000 / 1000), (unsigned long)(freq_ch2_x1000 % 1000));

            freq_measure_ch2_start();
            ch2_new = 1;
        }

        /* ---- 两路都有新数据时推入滑动窗口，每N次计算并输出 ---- */
        if (ch1_new && ch2_new)
        {
            static uint16_t output_cycle = 0;

            pressure_calc_push(freq_ch1_x1000, freq_ch2_x1000);
            ch1_new = 0;
            ch2_new = 0;

            /* 动态输出间隔: 目标 ≈2Hz (500ms), 最慢每测量1次 */
            {
                uint32_t cyc = 60000000UL / g_target_ref_count;
                if (cyc < 1) cyc = 1;
                output_cycle++;
                if (output_cycle >= cyc)
                {
                    output_cycle = 0;
                    pressure = pressure_calc_get() * proto_get_calib_mult() + proto_get_calib_adder();

                    /* 气压显示: xxx.xx */
                    {
                        int32_t p_int = (int32_t)pressure;
                        int32_t p_frac = (int32_t)((pressure - (float)p_int) * 100.0f);
                        if (p_frac < 0) p_frac = -p_frac;
                        sprintf(disp_p, "P:%ld.%02ld",
                                (long)p_int, (long)p_frac);
                    }

                    /* 高度显示: xxxx.x */
                    {
                        float altitude = pressure_to_altitude(pressure);
                        int32_t a_int = (int32_t)altitude;
                        int32_t a_frac = (int32_t)((altitude - (float)a_int) * 10.0f);
                        if (a_frac < 0) a_frac = -a_frac;
                        sprintf(disp_h, "H:%ld.%01ld",
                                (long)a_int, (long)a_frac);
                    }

                    /* 读取MCU内部温度 */
                    temperature = Get_Temprate();

                    {
                        int16_t t_int  = temperature / 100;
                        uint8_t t_frac = (temperature >= 0) ? (temperature % 100) : ((-temperature) % 100);
                        sprintf(disp_t, "T:%c%d.%02dC",
                                (temperature < 0) ? '-' : ' ', t_int, t_frac);
                    }

                    /* 串口输出: 频率+气压+高度+温度 (SC指令控制) */
                    if (proto_get_stream_enable())
                    {
                        float altitude = pressure_to_altitude(pressure);
                        printf("[CH1] %lu.%03lu Hz  [CH2] %lu.%03lu Hz  [Ref1] %lu  [Ref2] %lu  [P] %.2f  [H] %.1f  [T] %d.%02d C\r\n",
                               (unsigned long)(freq_ch1_x1000 / 1000),
                               (unsigned long)(freq_ch1_x1000 % 1000),
                               (unsigned long)(freq_ch2_x1000 / 1000),
                               (unsigned long)(freq_ch2_x1000 % 1000),
                               (unsigned long)g_ref_ch1_cached,
                               (unsigned long)g_ref_ch2_cached,
                               (double)pressure,
                               (double)altitude,
                               temperature / 100, (temperature >= 0) ? (temperature % 100) : ((-temperature) % 100));
                    }

                    need_refresh = 1;
                }
            }
        }

        /* ---- OLED 刷新 ---- */
        if (need_refresh)
        {
            OLED_Clear();
            OLED_ShowString(0, 0, "CH1:", 16);
            OLED_ShowString(32, 0, (const uint8_t *)disp_ch1, 16);
            OLED_ShowString(0, 20, "CH2:", 16);
            OLED_ShowString(32, 20, (const uint8_t *)disp_ch2, 16);
            OLED_ShowString(0, 40, (const uint8_t *)disp_p, 12);
            OLED_ShowString(64, 40, (const uint8_t *)disp_h, 12);
            OLED_ShowString(0, 52, (const uint8_t *)disp_t, 12);
            OLED_Refresh_Gram();
        }

        /* 处理协议帧 */
        if (g_proto_frame_ready)
        {
            protocol_process();
            g_proto_frame_ready = 0;
        }
    }
}
