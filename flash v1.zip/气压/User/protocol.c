/* ====================================================================================
 * 文件: protocol.c
 * 描述: 串口通信协议模块 - ASCII助记符指令解析 + XOR校验 + 响应构建
 * ====================================================================================
 *
 * 帧格式:
 *   请求: #01XX<CMD>[DATA]\r<CKSUM>     (CKSUM=XOR(#..\r前), 2hex)
 *   响应: *01XX<DATA>\r\n<CKSUM>        (CKSUM=XOR(*..\r\n前), 2hex)
 *
 * 指令表: 16 条读指令 + 8 条写指令
 * ==================================================================================== */

#include "protocol.h"
#include "usart.h"
#include "freq_measure.h"
#include "pressure_calc.h"

/* 主循环缓存的频率值 (避免 re-calculate 拿到已清零的数据) */
extern uint32_t g_freq_ch1_x1000;
extern uint32_t g_freq_ch2_x1000;
#include "adc.h"
#include "dac.h"
#include "gd32f30x_fmc.h"
#include "gd32f30x_bkp.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* ====================================================================================
 * 内部Flash读写封装
 *
 * GD32F303CCT6 内部Flash特性:
 *   - 页大小: 1KB (1024字节)
 *   - 写入: 按32位字, 只能 1→0, 不能 0→1 (需先擦除)
 *   - 擦除: 按页, 耗时~2ms, 期间CPU暂停
 *   - 擦写时需关中断保护
 * ==================================================================================== */

/* 内部Flash读取 (直接内存访问, 无需特殊操作) */
static void intflash_read(uint8_t *pbuf, uint32_t addr, uint16_t len)
{
    memcpy(pbuf, (const void *)addr, len);
}

/* 内部Flash页擦除 (1KB, 关中断保护) */
static void intflash_erase_page(uint32_t page_addr)
{
    __disable_irq();
    fmc_unlock();
    fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT);
    fmc_page_erase(page_addr);
    fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT);
    fmc_lock();
    __enable_irq();
    __DSB();
    __ISB();
}

/* 内部Flash写入 (32位字对齐, 关中断保护) */
static void intflash_write(const uint8_t *pbuf, uint32_t addr, uint16_t len)
{
    uint32_t i;
    __disable_irq();
    fmc_unlock();
    for (i = 0; i < len; i += 4)
    {
        uint32_t word = 0xFFFFFFFF;
        uint16_t remaining = len - i;
        if (remaining >= 4)
            memcpy(&word, pbuf + i, 4);
        else
            memcpy(&word, pbuf + i, remaining);
        fmc_word_program(addr + i, word);
        fmc_bank0_ready_wait(FMC_TIMEOUT_COUNT);
    }
    fmc_lock();
    __enable_irq();
    __DSB();
    __ISB();
}

/* ====================================================================================
 * ISR 接口变量定义
 * ==================================================================================== */
volatile uint8_t  g_proto_rx_buf[PROTO_RX_BUF_SIZE];
volatile uint8_t  g_proto_rx_idx        = 0;
volatile uint8_t  g_proto_rx_mode       = 0;
volatile uint8_t  g_proto_rx_need_cksum = 0;
volatile uint8_t  g_proto_frame_ready   = 0;

/* ====================================================================================
 * 模块内部变量
 * ==================================================================================== */
static uint8_t   s_station      = 0;      /* 当前设备站号 */
static char      s_serial[16]   = "XSTK00000000";  /* 序列号 (XSTK + 8位后缀) */
static char      s_tx_buf[PROTO_TX_BUF_SIZE];   /* 发送缓冲 */

/* Flash 版本号存储 */
static char      s_fw_version[24] = PROTO_FW_VERSION;  /* 当前版本号 */

/* Flash 运行参数 */
static uint32_t  s_baud_rate    = 9600;   /* 波特率 (默认9600) */
static uint8_t   s_parity       = PROTO_PARITY_NONE; /* 校验位 (默认无) */
static uint8_t   s_data_bits    = PROTO_DATA_BITS_8;  /* 数据位 (默认8) */
static uint8_t   s_stop_bits    = PROTO_STOP_BITS_1;  /* 停止位 (默认1) */

/* 允许的波特率列表 */
static const uint32_t s_baud_table[] = {2400, 4800, 9600, 19200, 38400, 57600, 115200};
#define BAUD_TABLE_SIZE  (sizeof(s_baud_table) / sizeof(s_baud_table[0]))

/* 写指令存储(暂存,后续可存Flash) */
static float     s_calib_adder  = 0.0f;   /* 加法器校准 PAA */
static float     s_calib_mult   = 1.0f;   /* 乘法器校准 PMB */
static float     s_range_low    = 0.0f;   /* 量程下限 */
static float     s_range_high   = 1000.0f;/* 量程上限 */
/* ---- 分辨率查表 (PR/PPI 指令) ---- */
#define RESOLUTION_IDX_DEFAULT   6           /* 默认索引: "1" (100ms) */
#define RESOLUTION_TABLE_SIZE    10

/* 分辨率字符串 (协议展示) */
static const char *s_resolution_names[RESOLUTION_TABLE_SIZE] = {
    "1/100", "1/50", "1/20", "1/10", "1/5", "1/2", "1", "2", "5", "10"
};

/* 对应闸门参考计数值 (倍数 × 12000000 = 100ms基准) */
static const uint32_t s_resolution_ref_counts[RESOLUTION_TABLE_SIZE] = {
       120000UL,    /* 1/100 → 1ms   */
       240000UL,    /* 1/50  → 2ms   */
       600000UL,    /* 1/20  → 5ms   */
      1200000UL,    /* 1/10  → 10ms  */
      2400000UL,    /* 1/5   → 20ms  */
      6000000UL,    /* 1/2   → 50ms  */
     12000000UL,    /* 1     → 100ms */
     24000000UL,    /* 2     → 200ms */
     60000000UL,    /* 5     → 500ms */
    120000000UL,    /* 10    → 1s    */
};

static uint8_t  s_resolution_idx = RESOLUTION_IDX_DEFAULT;  /* 分辨率索引 */
static float     s_accuracy     = 0.1f;   /* 精度 */
static uint8_t   s_eeprom_en    = 0;      /* EEPROM写使能 */
static uint8_t   s_stream_enable = 0;     /* SC: 串口自动流式输出 (0=关, 1=开) */
static float     s_mult_merged_val = 0.0f; /* 调试: 合并后的乘法器值 */

/* ====================================================================================
 * 静态函数声明(前向)
 * ==================================================================================== */
static void flash_serial_init(void);
static void flash_serial_save(void);
static void flash_calib_save_adder_zone2(float val);
static void flash_calib_save_mult_zone2(float val);
static uint8_t calib_read_zone(uint32_t addr, float *out);
static void handler_st (uint8_t station, const char *data, uint8_t data_len);
static void handler_vg (uint8_t station, const char *data, uint8_t data_len);
static void handler_p3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_h3 (uint8_t station, const char *data, uint8_t data_len);
static void handler_f5 (uint8_t station, const char *data, uint8_t data_len);
static void handler_sn_read (uint8_t station, const char *data, uint8_t data_len);
static void handler_fs (uint8_t station, const char *data, uint8_t data_len);
static void handler_dr (uint8_t station, const char *data, uint8_t data_len);
static void handler_br (uint8_t station, const char *data, uint8_t data_len);
static void handler_pt (uint8_t station, const char *data, uint8_t data_len);
static void handler_bt (uint8_t station, const char *data, uint8_t data_len);
static void handler_sb (uint8_t station, const char *data, uint8_t data_len);
static void handler_p1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_t1 (uint8_t station, const char *data, uint8_t data_len);
static void handler_pr (uint8_t station, const char *data, uint8_t data_len);
static void handler_acc (uint8_t station, const char *data, uint8_t data_len);
static void handler_adr (uint8_t station, const char *data, uint8_t data_len);
static void handler_ewo (uint8_t station, const char *data, uint8_t data_len);
static void handler_ppi (uint8_t station, const char *data, uint8_t data_len);
static void handler_paa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pmb (uint8_t station, const char *data, uint8_t data_len);
static void handler_tpc (uint8_t station, const char *data, uint8_t data_len);
static void handler_wvr (uint8_t station, const char *data, uint8_t data_len);
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len);
static void handler_sc (uint8_t station, const char *data, uint8_t data_len);
static void handler_pa (uint8_t station, const char *data, uint8_t data_len);
static void handler_pm (uint8_t station, const char *data, uint8_t data_len);
static void handler_md (uint8_t station, const char *data, uint8_t data_len);

/* ====================================================================================
 * 指令表 (按长度降序排列: 3字符在前, 2字符在后)
 * ==================================================================================== */
static const proto_cmd_entry_t s_cmd_table[] = {
    /* ---- 3字符写指令 ---- */
    { "ACC", 3, CMD_TYPE_WRITE_3, handler_acc },
    { "ADR", 3, CMD_TYPE_WRITE_3, handler_adr },
    { "EWO", 3, CMD_TYPE_WRITE_3, handler_ewo },
    { "PPI", 3, CMD_TYPE_WRITE_3, handler_ppi },
    { "PAA", 3, CMD_TYPE_WRITE_3, handler_paa },
    { "PMB", 3, CMD_TYPE_WRITE_3, handler_pmb },
    { "TPC", 3, CMD_TYPE_WRITE_3, handler_tpc },
    { "WVR", 3, CMD_TYPE_WRITE_3, handler_wvr },

    /* ---- 2字符读指令 ---- */
    { "ST", 2, CMD_TYPE_READ_2,  handler_st },
    { "VG", 2, CMD_TYPE_READ_2,  handler_vg },
    { "P3", 2, CMD_TYPE_READ_2,  handler_p3 },
    { "T3", 2, CMD_TYPE_READ_2,  handler_t3 },
    { "H3", 2, CMD_TYPE_READ_2,  handler_h3 },
    { "F5", 2, CMD_TYPE_READ_2,  handler_f5 },
    { "SN", 2, CMD_TYPE_READ_2,  handler_sn_read },
    { "FS", 2, CMD_TYPE_READ_2,  handler_fs },
    { "BR", 2, CMD_TYPE_READ_2,  handler_br },
    { "DR", 2, CMD_TYPE_READ_2,  handler_dr },
    { "PT", 2, CMD_TYPE_READ_2,  handler_pt },
    { "BT", 2, CMD_TYPE_READ_2,  handler_bt },
    { "SB", 2, CMD_TYPE_READ_2,  handler_sb },
    { "P1", 2, CMD_TYPE_READ_2,  handler_p1 },
    { "T1", 2, CMD_TYPE_READ_2,  handler_t1 },
    { "PR", 2, CMD_TYPE_READ_2,  handler_pr },
    { "SC", 2, CMD_TYPE_READ_2,  handler_sc },
    { "PA", 2, CMD_TYPE_READ_2,  handler_pa },
    { "PM", 2, CMD_TYPE_READ_2,  handler_pm },
    { "MD", 2, CMD_TYPE_READ_2,  handler_md },

    /* ---- 2字符写指令 (仅 ID) ---- */
    { "ID", 2, CMD_TYPE_WRITE_2, handler_id_write },
};

#define CMD_TABLE_SIZE  (sizeof(s_cmd_table) / sizeof(s_cmd_table[0]))

/* ====================================================================================
 * 公共函数: 模块初始化
 * ==================================================================================== */
void protocol_init(void)
{
    uint8_t i;

    flash_station_init();     /* 独立加载站号 */
    flash_resolution_init(); /* 独立加载分辨率, 同步 g_target_ref_count */
    flash_serial_init();      /* 独立加载序列号 */
    flash_calib_init();        /* 加载校准参数(加法器/乘法器), 合并二区 */

    for (i = 0; i < PROTO_RX_BUF_SIZE; i++)
        g_proto_rx_buf[i] = 0;
    g_proto_rx_idx        = 0;
    g_proto_rx_mode       = 0;
    g_proto_rx_need_cksum = 0;
    g_proto_frame_ready   = 0;
    /* s_station 由 flash_station_init 加载, 不清零 */
}

/* ====================================================================================
 * Flash 版本号存储
 *
 * 存储格式 (内部Flash 0x0803F000):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 版本字符串长度
 *   偏移3~: 版本字符串 (ASCII, 以\0结尾)
 * ==================================================================================== */
void flash_store_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    intflash_read(buf, FLASH_STORE_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_STORE_MAGIC)
    {
        /* Flash 中有有效版本号, 加载 */
        len = buf[2];
        if (len > 23) len = 23;
        for (i = 0; i < len && i < 23; i++)
            s_fw_version[i] = (char)buf[3 + i];
        s_fw_version[len] = '\0';
    }
    else
    {
        /* 首次上电或Flash为空, 写入默认版本号 */
        len = 0;
        while (PROTO_FW_VERSION[len] && len < 23) len++;

        /* 擦除页后写入 */
        intflash_erase_page(FLASH_STORE_ADDR);

        buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);   /* 魔数高位 */
        buf[1] = (uint8_t)(FLASH_STORE_MAGIC);         /* 魔数低位 */
        buf[2] = len;                                   /* 版本长度 */
        for (i = 0; i < len; i++)
            buf[3 + i] = (uint8_t)PROTO_FW_VERSION[i];
        for (; i < 29; i++)
            buf[3 + i] = 0xFF;                          /* 剩余填 0xFF */

        intflash_write(buf, FLASH_STORE_ADDR, 32);
    }
}

const char* flash_store_version(void)
{
    return s_fw_version;
}

/* ====================================================================================
 * Flash 配置区存储 (内部Flash 0x0803F400, 1KB页)
 *
 * 写入策略: 页内顺序追加 (磨损均衡)
 *   1KB ÷ 每条32B = 32条记录
 *   改配置时追加写入, 不擦除; 页满才擦一次
 *   寿命: 100,000 × 32 = 320万次
 *
 * 存储格式 (每条记录 32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: 波特率 uint32_t (little-endian)
 *   偏移  7: 保留 (站号已迁至独立页)
 *   偏移  8: 校验位 uint8_t
 *   偏移  9: 数据位 uint8_t
 *   偏移 10: 停止位 uint8_t
 *   偏移11~31: 填充 0xFF (预留)
 * ==================================================================================== */

/* 前向声明 (usart.c) */
extern void usart_baud_set(uint32_t baud);

static void flash_cfg_save(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];
    uint8_t  i;
    int16_t  last_slot = -1;      /* 最后一条有效记录的槽号 */
    int16_t  next_slot;
    uint16_t magic;
    uint32_t addr;

    /* ---- 打包数据 ---- */
    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);
    buf[2] = 0x01;

    buf[3] = (uint8_t)(s_baud_rate);
    buf[4] = (uint8_t)(s_baud_rate >> 8);
    buf[5] = (uint8_t)(s_baud_rate >> 16);
    buf[6] = (uint8_t)(s_baud_rate >> 24);

    buf[7] = 0xFF;        /* 站号已迁至独立页 */
    buf[8] = s_parity;
    buf[9] = s_data_bits;
    buf[10] = s_stop_bits;

    for (i = 11; i < FLASH_CFG_RECORD_SIZE; i++)
        buf[i] = 0xFF;

    /* ---- 找最后一条有效记录的位置 ---- */
    {
        uint8_t magic_buf[2];
        for (i = 0; i < FLASH_CFG_MAX_RECORDS; i++)
        {
            addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
            intflash_read(magic_buf, addr, 2);  /* 独立 buffer, 不破坏打包数据 */
            magic = ((uint16_t)magic_buf[0] << 8) | magic_buf[1];
            if (magic == FLASH_CFG_MAGIC)
                last_slot = (int16_t)i;
        }
    }

    next_slot = last_slot + 1;

    /* ---- 页满了 → 擦除, 从槽0重新开始 ---- */
    if (next_slot >= (int16_t)FLASH_CFG_MAX_RECORDS)
    {
        intflash_erase_page(FLASH_CFG_ADDR);
        next_slot = 0;
    }

    /* ---- 追加写入 (内部Flash, 目标为0xFF时可直接写) ---- */
    addr = FLASH_CFG_ADDR + (uint32_t)next_slot * FLASH_CFG_RECORD_SIZE;
    intflash_write(buf, addr, FLASH_CFG_RECORD_SIZE);
}

void flash_cfg_init(void)
{
    uint8_t  buf[FLASH_CFG_RECORD_SIZE];
    uint16_t magic;
    uint8_t  need_save = 0;
    int16_t  i;

    /* ---- 从后往前扫, 找最新一条有效记录 ---- */
    for (i = (int16_t)(FLASH_CFG_MAX_RECORDS - 1); i >= 0; i--)
    {
        uint32_t addr = FLASH_CFG_ADDR + (uint32_t)i * FLASH_CFG_RECORD_SIZE;
        intflash_read(buf, addr, FLASH_CFG_RECORD_SIZE);
        magic = ((uint16_t)buf[0] << 8) | buf[1];

        if (magic == FLASH_CFG_MAGIC)
        {
            /* 找到! 加载配置 */
            s_baud_rate = (uint32_t)buf[3]
                        | ((uint32_t)buf[4] << 8)
                        | ((uint32_t)buf[5] << 16)
                        | ((uint32_t)buf[6] << 24);

            /* 合法性检查: 必须在允许列表中 */
            {
                uint8_t j, valid = 0;
                for (j = 0; j < BAUD_TABLE_SIZE; j++)
                {
                    if (s_baud_rate == s_baud_table[j]) { valid = 1; break; }
                }
                if (!valid)
                {
                    s_baud_rate = 9600;
                    need_save = 1;
                }
            }

            /* 加载校验位 */
            s_parity = buf[8];
            if (s_parity > PROTO_PARITY_EVEN)
            {
                s_parity = PROTO_PARITY_NONE;
                need_save = 1;
            }

            /* 加载数据位 */
            s_data_bits = buf[9];
            if (s_data_bits > PROTO_DATA_BITS_9)
            {
                s_data_bits = PROTO_DATA_BITS_8;
                need_save = 1;
            }

            /* 加载停止位 */
            s_stop_bits = buf[10];
            if (s_stop_bits > PROTO_STOP_BITS_2)
            {
                s_stop_bits = PROTO_STOP_BITS_1;
                need_save = 1;
            }

            /* 站号由 flash_station_init() 独立加载, 不从这里读取 */

            if (need_save)
            {
                flash_cfg_save();
            }
            /* UART 尚未初始化 */
            return;
        }
    }

    /* 扇区全空或全无效 → 首次上电 */
    s_baud_rate = 9600;
    s_parity    = PROTO_PARITY_NONE;
    s_data_bits = PROTO_DATA_BITS_8;
    s_stop_bits = PROTO_STOP_BITS_1;
    /* 站号由 flash_station_init() 独立初始化 */
    flash_cfg_save();
}

uint32_t flash_cfg_get_baud(void)
{
    return s_baud_rate;
}

uint8_t flash_cfg_get_parity(void)
{
    return s_parity;
}

uint8_t flash_cfg_get_data_bits(void)
{
    return s_data_bits;
}

uint8_t flash_cfg_get_stop_bits(void)
{
    return s_stop_bits;
}

/* ====================================================================================
 * Flash 站号独立存储 (扇区 2045)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 站号 uint8_t
 *   偏移4~31: 填充 0xFF
 *
 * 站号极少变更, 不使用追加磨损均衡, 每次擦除后单条写入
 * ==================================================================================== */
void flash_station_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_STATION_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_CFG_MAGIC)
    {
        /* 有效记录 → 加载站号 */
        s_station = buf[3];
    }
    else
    {
        /* 首次上电 → 默认站号 0x01, 写入内部Flash */
        s_station = 0x01;
        flash_station_save();
    }
}

void flash_station_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    intflash_erase_page(FLASH_STATION_ADDR);

    buf[0] = (uint8_t)(FLASH_CFG_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_CFG_MAGIC);
    buf[2] = 0x01;
    buf[3] = s_station;

    for (i = 4; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_STATION_ADDR, 32);
}

/* ---- Flash 分辨率存储 (内部Flash 0x0803FC00) ---- */
void flash_resolution_init(void)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, FLASH_RESOLUTION_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_RESOLUTION_MAGIC && buf[2] < RESOLUTION_TABLE_SIZE)
    {
        /* 有效记录 → 加载分辨率 */
        s_resolution_idx = buf[2];
    }
    else
    {
        /* 首次上电 → 默认分辨率 "1" (100ms), 写入内部Flash */
        s_resolution_idx = RESOLUTION_IDX_DEFAULT;
        flash_resolution_save();
    }

    /* 同步到频率测量模块的闸门目标 */
    g_target_ref_count = s_resolution_ref_counts[s_resolution_idx];
    /* 同步信号计数闸门目标: signal = ref × est_freq / 120MHz */
    g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);
    g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);
}

void flash_resolution_save(void)
{
    uint8_t buf[32];
    uint8_t i;

    intflash_erase_page(FLASH_RESOLUTION_ADDR);

    buf[0] = (uint8_t)(FLASH_RESOLUTION_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_RESOLUTION_MAGIC);
    buf[2] = s_resolution_idx;

    for (i = 3; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_RESOLUTION_ADDR, 32);
}

uint8_t flash_resolution_get_idx(void)
{
    return s_resolution_idx;
}

/* ====================================================================================
 * Flash 序列号存储 (内部Flash 0x0803EC00)
 *
 * 存储格式 (32 字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移  3: 序列号字符串长度 (不含\0)
 *   偏移4~15: 序列号字符串 (ASCII, "XSTK" + 8位后缀, 共12字符)
 *   偏移16~31: 填充 0xFF
 * ==================================================================================== */

static void flash_serial_save(void)
{
    uint8_t buf[32];
    uint8_t len, i;

    len = (uint8_t)strlen(s_serial);
    if (len > 12) len = 12;

    intflash_erase_page(FLASH_SERIAL_ADDR);

    buf[0] = (uint8_t)(FLASH_SERIAL_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_SERIAL_MAGIC);
    buf[2] = 0x01;
    buf[3] = len;
    for (i = 0; i < len; i++)
        buf[4 + i] = (uint8_t)s_serial[i];
    for (; i < 12; i++)
        buf[4 + i] = 0xFF;
    for (i = 16; i < 32; i++)
        buf[i] = 0xFF;

    intflash_write(buf, FLASH_SERIAL_ADDR, 32);
}

static void flash_serial_init(void)
{
    uint8_t buf[32];
    uint16_t magic;
    uint8_t len, i;

    intflash_read(buf, FLASH_SERIAL_ADDR, 32);

    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic == FLASH_SERIAL_MAGIC)
    {
        /* 有效记录 → 加载序列号 */
        len = buf[3];
        if (len > 12) len = 12;
        for (i = 0; i < len; i++)
            s_serial[i] = (char)buf[4 + i];
        s_serial[len] = '\0';
    }
    else
    {
        /* 首次上电 → 默认序列号, 写入内部Flash */
        strcpy(s_serial, "XSTK00000000");
        flash_serial_save();
    }
}

/* ====================================================================================
 * Flash 校准参数存储 (加法器/乘法器, 双区机制)
 *
 * 每个参数有两区 (各1KB独立页):
 *   一区: 当前生效值, 上电读取直接用于计算
 *   二区: 待生效值, 串口指令写入, 下次上电合并到一区
 *
 * 合并规则:
 *   加法器: 一区 + 二区 → 一区
 *   乘法器: 一区 × 二区 → 一区
 *
 * 存储格式 (32字节):
 *   偏移0~1: 魔数 0xA5 0xF3
 *   偏移  2: 格式版本 0x01
 *   偏移3~6: float值 (little-endian)
 *   偏移7~31: 填充 0xFF
 * ==================================================================================== */

/* 读取校准区的float值, 返回1=有效, 0=无效(全0xFF或魔数不对) */
static uint8_t calib_read_zone(uint32_t addr, float *out)
{
    uint8_t buf[32];
    uint16_t magic;

    intflash_read(buf, addr, 32);
    magic = ((uint16_t)buf[0] << 8) | buf[1];

    if (magic != FLASH_CALIB_MAGIC)
        return 0;

    /* 拷贝4字节float (避免对齐问题) */
    memcpy(out, &buf[3], 4);
    return 1;
}

/* 写入校准区 (双重擦除+逐字写入+验证), 返回1=成功 0=失败 */
static uint8_t calib_write_zone(uint32_t addr, float val)
{
    uint8_t buf[32];
    uint8_t rbuf[32];
    uint8_t i;
    uint8_t retry;
    float readback;
    volatile uint32_t delay;

    for (retry = 0; retry < 3; retry++)
    {
        /* 擦除 */
        intflash_erase_page(addr);

        /* 擦除后延迟 */
        for (delay = 0; delay < 100000; delay++) {}

        /* 擦除后读回，确认全FF */
        intflash_read(rbuf, addr, 8);
        printf("[Calib] Erase 0x%08X: %02X%02X%02X%02X %02X%02X%02X%02X\r\n",
               (unsigned int)addr, rbuf[0], rbuf[1], rbuf[2], rbuf[3],
               rbuf[4], rbuf[5], rbuf[6], rbuf[7]);

        /* 验证擦除: 前8字节必须全0xFF */
        {
            uint8_t erase_ok = 1;
            uint8_t j;
            for (j = 0; j < 8; j++)
            {
                if (rbuf[j] != 0xFF) { erase_ok = 0; break; }
            }
            if (!erase_ok)
            {
                printf("[Calib] Erase FAIL 0x%08X retry=%d\r\n", (unsigned int)addr, retry);
                continue;  /* 重试 */
            }
        }

        /* 构造数据 */
        buf[0] = (uint8_t)(FLASH_CALIB_MAGIC >> 8);
        buf[1] = (uint8_t)(FLASH_CALIB_MAGIC);
        buf[2] = 0x01;
        memcpy(&buf[3], &val, 4);
        for (i = 7; i < 32; i++)
            buf[i] = 0xFF;

        /* 使用intflash_write写入 */
        intflash_write(buf, addr, 32);

        /* 写入后延迟 */
        for (delay = 0; delay < 100000; delay++) {}

        /* 读回验证 */
        intflash_read(rbuf, addr, 32);
        memcpy(&readback, &rbuf[3], 4);

        printf("[Calib] Write 0x%08X: %02X%02X%02X%02X %02X%02X%02X%02X val=%.4f\r\n",
               (unsigned int)addr, rbuf[0], rbuf[1], rbuf[2], rbuf[3],
               rbuf[4], rbuf[5], rbuf[6], rbuf[7], readback);

        if (rbuf[0] == buf[0] && rbuf[1] == buf[1] && rbuf[2] == buf[2] &&
            memcmp(&rbuf[3], &buf[3], 4) == 0)
        {
            printf("[Calib] OK 0x%08X retry=%d\r\n", (unsigned int)addr, retry);
            return 1;  /* 写入成功 */
        }

        printf("[Calib] FAIL 0x%08X retry=%d\r\n", (unsigned int)addr, retry);
    }

    printf("[Calib] FAILED 0x%08X!\r\n", (unsigned int)addr);
    return 0;  /* 3次重试全部失败 */
}

/* 清零校准区 (擦除整页, 全变0xFF) */
static void calib_clear_zone(uint32_t addr)
{
    intflash_erase_page(addr);
}

void flash_calib_init(void)
{
    float zone1_val, zone2_val;
    float final_val;
    uint8_t need_write = 0;

    /* ---- 加法器 ---- */
    if (calib_read_zone(FLASH_CALIB_ADDER1_ADDR, &zone1_val))
    {
        /* 一区有效 */
        if (calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 合并, 一区写成功才清二区 */
            final_val = zone1_val + zone2_val;
            if (calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_ADDER2_ADDR);
            else
                printf("[Calib] Adder merge FAILED, zone2 preserved\r\n");
        }
        else
        {
            final_val = zone1_val;
        }
    }
    else
    {
        /* 一区无效(首次上电) */
        if (calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 直接用二区值作为一区, 写成功才清二区 */
            final_val = zone2_val;
            if (calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_ADDER2_ADDR);
            else
                printf("[Calib] Adder init FAILED, zone2 preserved\r\n]");
        }
        else
        {
            /* 都空 → 写默认值 */
            final_val = 0.0f;
            calib_write_zone(FLASH_CALIB_ADDER1_ADDR, final_val);
        }
    }
    s_calib_adder = final_val;

    /* ---- 乘法器 ---- */
    printf("[Calib] Mult init: reading zone1=0x%08X, zone2=0x%08X\r\n",
           (unsigned int)FLASH_CALIB_MULT1_ADDR, (unsigned int)FLASH_CALIB_MULT2_ADDR);

    if (calib_read_zone(FLASH_CALIB_MULT1_ADDR, &zone1_val))
    {
        printf("[Calib] Mult zone1 valid: %.4f\r\n", zone1_val);
        /* 一区有效 */
        if (calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 合并, 一区写成功才清二区 */
            final_val = zone1_val * zone2_val;
            s_mult_merged_val = final_val;
            printf("[Calib] Mult merge: %.4f * %.4f = %.4f\r\n", zone1_val, zone2_val, final_val);
            if (calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_MULT2_ADDR);
            else
                printf("[Calib] Mult merge FAILED, zone2 preserved\r\n");
        }
        else
        {
            final_val = zone1_val;
            printf("[Calib] Mult zone2 empty, use zone1: %.4f\r\n", final_val);
        }
    }
    else
    {
        printf("[Calib] Mult zone1 invalid\r\n");
        /* 一区无效(首次上电) */
        if (calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        {
            /* 二区有数据 → 直接用二区值作为一区, 写成功才清二区 */
            final_val = zone2_val;
            printf("[Calib] Mult use zone2 as zone1: %.4f\r\n", final_val);
            if (calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val))
                calib_clear_zone(FLASH_CALIB_MULT2_ADDR);
            else
                printf("[Calib] Mult init FAILED, zone2 preserved\r\n");
        }
        else
        {
            /* 都空 → 写默认值 */
            final_val = 1.0f;
            printf("[Calib] Mult all empty, write default: %.4f\r\n", final_val);
            calib_write_zone(FLASH_CALIB_MULT1_ADDR, final_val);
        }
    }
    s_calib_mult = final_val;
}

float proto_get_calib_adder(void)
{
    return s_calib_adder;
}

float proto_get_calib_mult(void)
{
    return s_calib_mult;
}

/* 串口写入: 只存二区, 本次上电不影响一区 */
static void flash_calib_save_adder_zone2(float val)
{
    calib_write_zone(FLASH_CALIB_ADDER2_ADDR, val);
}

static void flash_calib_save_mult_zone2(float val)
{
    calib_write_zone(FLASH_CALIB_MULT2_ADDR, val);
}

/* ====================================================================================
 * 辅助函数: 计算 XOR 校验和
 *   buf: 待校验数据
 *   len: 字节数
 *   返回: XOR 结果 (0x00~0xFF)
 * ==================================================================================== */
uint8_t proto_xor_checksum(const uint8_t *buf, uint8_t len)
{
    uint8_t ck = 0;
    uint8_t i;
    for (i = 0; i < len; i++)
    {
        ck ^= buf[i];
    }
    return ck;
}

/* ====================================================================================
 * 辅助函数: 构建并发送响应帧
 *   自动计算校验和, 组装为 *01XX<data>\r\n<CK>
 *   data: 响应数据字符串 (不含帧头帧尾校验和)
 * ==================================================================================== */
void proto_send_response(const char *data)
{
    uint8_t  frame[PROTO_TX_BUF_SIZE];
    uint8_t  idx = 0;
    uint8_t  i;
    uint8_t  ck;

    /* ---------- 构建帧 ---------- */
    frame[idx++] = '*';                     /* 帧头 */
    frame[idx++] = '0';                     /* 地址高位 */
    frame[idx++] = '0' + PROTO_DEV_ADDR;    /* 地址低位: '1' */
    frame[idx++] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];  /* 站号高位 */
    frame[idx++] = "0123456789ABCDEF"[s_station & 0x0F];         /* 站号低位 */

    /* 数据部分 (前面加空格, 与帧头分隔) */
    frame[idx++] = ' ';
    if (data != NULL)
    {
        while (*data && idx < PROTO_TX_BUF_SIZE - 6)
        {
            frame[idx++] = (uint8_t)(*data++);
        }
    }

    /* 帧尾 \r\n */
    frame[idx++] = 0x0D;
    frame[idx++] = 0x0A;

    /* 校验和 (范围: 帧头 '*' 到 \r\n 前, 即 idx-2 个字节) */
    ck = proto_xor_checksum(frame, idx - 2);
    frame[idx++] = "0123456789ABCDEF"[(ck >> 4) & 0x0F];
    frame[idx++] = "0123456789ABCDEF"[ck & 0x0F];

    /* ---------- DMA 发送 ---------- */
    usart_dma_send(frame, idx);
}

/* ====================================================================================
 * 辅助函数: 发错误响应
 * ==================================================================================== */
static void proto_send_error(const char *err_msg)
{
    proto_send_response(err_msg);
}

/* ====================================================================================
 * 辅助函数: 2位 hex 字符 → uint8
 *   hex: 指向2个ASCII hex字符的指针
 *   返回: 0x00~0xFF
 * ==================================================================================== */
static uint8_t hex2u8(const char *hex)
{
    uint8_t val = 0;
    uint8_t i;
    for (i = 0; i < 2; i++)
    {
        val <<= 4;
        if (hex[i] >= '0' && hex[i] <= '9')
            val |= hex[i] - '0';
        else if (hex[i] >= 'A' && hex[i] <= 'F')
            val |= hex[i] - 'A' + 10;
        else if (hex[i] >= 'a' && hex[i] <= 'f')
            val |= hex[i] - 'a' + 10;
    }
    return val;
}

/* ====================================================================================
 * 核心函数: 协议帧解析与处理 (主循环中调用)
 * ==================================================================================== */
void protocol_process(void)
{
    uint8_t  frame_len;
    uint8_t  data_end;       /* \r 的位置 (数据部分结束) */
    uint8_t  payload_start;  /* 指令码起始位置 = 5 */
    uint8_t  payload_len;    /* 指令码+数据总长度 */
    uint8_t  ck_calc, ck_recv;
    uint8_t  dev_addr;
    uint8_t  station;
    uint8_t  i;

    /* ---------- 第1步: 找 \r, 定位校验和 ---------- */
    frame_len = g_proto_rx_idx;
    if (frame_len < 10)   /* 最短帧: #01XXCC\rCC = 10字节 */
    {
        proto_send_error("ER1");  /* 帧太短 */
        return;
    }

    /* 找 \r 位置 */
    data_end = 0xFF;
    for (i = 0; i < frame_len; i++)
    {
        if (g_proto_rx_buf[i] == 0x0D)
        {
            data_end = i;
            break;
        }
    }
    if (data_end == 0xFF || data_end + 3 > frame_len)
    {
        /* 无 \r 或 校验和不完整 (\r后需要2字节校验和) */
        proto_send_error("ER2");  /* 帧格式错误 */
        return;
    }
    /* 校验和在 data_end+1 和 data_end+2 */

    /* ---------- 第2步: 校验和验证 ---------- */
    ck_recv = hex2u8((const char *)&g_proto_rx_buf[data_end + 1]);
    ck_calc = proto_xor_checksum((const uint8_t *)g_proto_rx_buf, data_end + 1);  /* 范围: '#'..\r 含\r */
    if (ck_recv != ck_calc)
    {
        proto_send_error("ER3");  /* 校验和错误 */
        return;
    }

    /* ---------- 第3步: 校验帧头 ---------- */
    if (g_proto_rx_buf[0] != '#')
    {
        proto_send_error("ER4");  /* 帧头错误 */
        return;
    }

    /* ---------- 第4步: 校验设备地址 ---------- */
    dev_addr = hex2u8((const char *)&g_proto_rx_buf[1]);
    if (dev_addr != PROTO_DEV_ADDR)
    {
        /* 地址不匹配, 不响应 */
        return;
    }

    /* ---------- 第5步: 解析站号并过滤 ---------- */
    station = hex2u8((const char *)&g_proto_rx_buf[3]);

    /* 00 = 广播 (全体响应), 其他 = 仅匹配自身站号, 不匹配则静默丢弃 */
    if (station != 0x00 && station != s_station)
        return;

    /* ---------- 第6步: 提取指令码+数据 ---------- */
    payload_start = 5;                                        /* 跳过 # + 01 + XX */
    payload_len   = data_end - payload_start;                 /* 指令码+数据总长度 */

    if (payload_len < 2)
    {
        proto_send_error("ER5");  /* 无指令码 */
        return;
    }

    /* ---------- 第7步: 查表匹配指令 ---------- */
    for (i = 0; i < CMD_TABLE_SIZE; i++)
    {
        const proto_cmd_entry_t *cmd = &s_cmd_table[i];

        if (payload_len < cmd->len)
            continue;

        /* 比较指令码 (大小写不敏感 — 接收一律转大写对比) */
        {
            uint8_t match = 1;
            uint8_t j;
            for (j = 0; j < cmd->len; j++)
            {
                char c = (char)g_proto_rx_buf[payload_start + j];
                if (c >= 'a' && c <= 'z') c -= 32;  /* 小写转大写 */
                if (c != cmd->code[j]) { match = 0; break; }
            }
            if (!match) continue;
        }

        /* 命中! 提取数据部分 */
        {
            const char *data_ptr = NULL;
            uint8_t     data_len = 0;

            if (payload_len > cmd->len)
            {
                data_ptr = (const char *)&g_proto_rx_buf[payload_start + cmd->len];
                data_len = payload_len - cmd->len;
            }

            /* 执行处理函数 */
            cmd->handler(station, data_ptr, data_len);
        }
        return;   /* 已处理, 退出 */
    }

    /* 未匹配任何指令 */
    proto_send_error("ER6");  /* 未知指令 */
}

/* ====================================================================================
 * 读指令处理函数
 * ==================================================================================== */

/* ---- ST: 通讯查验 ---- */
static void handler_st(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response("OK");
}

/* ---- VG: 读版本 ---- */
static void handler_vg(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(flash_store_version());
}

/* ---- P3: 读气压 (含加法器/乘法器校准) ---- */
static void handler_p3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    sprintf(buf, "%.2f", (double)pressure);
    proto_send_response(buf);
}

/* ---- P1: 单次采集 (F1频率 + F2频率 + 气压, 含校准) ---- */
static void handler_p1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    float pressure;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)pressure);
    proto_send_response(buf);
}

/* ---- T1: 单次采集 (F1频率 + F2频率 + 温度) ---- */
static void handler_t1(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[80];
    short temp_raw;
    float temp_c;
    (void)data; (void)data_len;
    (void)station;

    temp_raw = Get_Temprate();
    temp_c   = (float)temp_raw / 100.0f;
    sprintf(buf, "%lu.%03lu,%lu.%03lu,%.2f",
            (unsigned long)(g_freq_ch1_x1000 / 1000),
            (unsigned long)(g_freq_ch1_x1000 % 1000),
            (unsigned long)(g_freq_ch2_x1000 / 1000),
            (unsigned long)(g_freq_ch2_x1000 % 1000),
            (double)temp_c);
    proto_send_response(buf);
}

/* ---- T3: 读温度 ---- */
static void handler_t3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    short temp_raw;
    float temp_c;
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */

    temp_raw = Get_Temprate();                    /* ×100 如 3524 = 35.24°C */
    temp_c   = (float)temp_raw / 100.0f;
    sprintf(buf, "%.2f", (double)temp_c);
    proto_send_response(buf);
}

/* ---- H3: 读高度 (气压含校准) ---- */
static void handler_h3(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    float pressure, altitude;
    (void)data; (void)data_len;
    (void)station;

    pressure = pressure_calc_get() * s_calib_mult + s_calib_adder;
    altitude = pressure_to_altitude(pressure);
    sprintf(buf, "%.2f", (double)altitude);
    proto_send_response(buf);
}

/* ---- F5: 读频率组 (5个CH1 + 5个CH2, 窗口原始数据, 最旧→最新) ---- */
static void handler_f5(uint8_t station, const char *data, uint8_t data_len)
{
    char     buf[200];
    uint32_t ch1[PRESSURE_WINDOW_SIZE];
    uint32_t ch2[PRESSURE_WINDOW_SIZE];
    uint8_t  cnt, i, pos = 0;
    (void)data; (void)data_len;
    (void)station;

    cnt = pressure_calc_get_window(ch1, ch2);  /* 时间顺序: [0]=最旧, [cnt-1]=最新 */

    /* F1 标签 */
    pos += sprintf(&buf[pos], "F1:");

    /* 输出5个F1: 取最新5个, 不足则在前面补 0.000 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch1[i] / 1000),
                           (unsigned long)(ch1[i] % 1000));
        }
    }

    /* F2 标签 */
    buf[pos++] = ',';
    pos += sprintf(&buf[pos], "F2:");

    /* 输出5个F2: 同上 */
    if (cnt >= 5)
    {
        for (i = cnt - 5; i < cnt; i++)
        {
            if (i > cnt - 5) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    else
    {
        for (i = 0; i < 5 - cnt; i++)
        {
            if (i > 0) buf[pos++] = ',';
            pos += sprintf(&buf[pos], "0.000");
        }
        for (i = 0; i < cnt; i++)
        {
            buf[pos++] = ',';
            pos += sprintf(&buf[pos], "%lu.%03lu",
                           (unsigned long)(ch2[i] / 1000),
                           (unsigned long)(ch2[i] % 1000));
        }
    }
    buf[pos] = '\0';
    proto_send_response(buf);
}

/* ---- SN: 读序列号 ---- */
static void handler_sn_read(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(s_serial);
}

/* ---- FS: 读量程 ---- */
static void handler_fs(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[32];
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    sprintf(buf, "%.0f-%.0f", (double)s_range_low, (double)s_range_high);
    proto_send_response(buf);
}

/* ---- BR: 读波特率 ---- */
/* ---- DR: 读站号 (返回设备自身站号, 不修改) ---- */
static void handler_dr(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[3];
    (void)station; (void)data; (void)data_len;
    buf[0] = "0123456789ABCDEF"[(s_station >> 4) & 0x0F];
    buf[1] = "0123456789ABCDEF"[s_station & 0x0F];
    buf[2] = '\0';
    proto_send_response(buf);
}

/* ---- BR: 读/写波特率 ---- */
static void handler_br(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[16];
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data != NULL && data_len > 0)
    {
        /* ---- 写模式: 设置新波特率 ---- */
        uint32_t new_baud = 0;
        uint8_t  i;

        for (i = 0; i < data_len; i++)
        {
            if (data[i] >= '0' && data[i] <= '9')
                new_baud = new_baud * 10 + (uint32_t)(data[i] - '0');
            else
                break;
        }

        /* 校验: 必须在允许列表中 */
        {
            uint8_t j, valid = 0;
            for (j = 0; j < BAUD_TABLE_SIZE; j++)
            {
                if (new_baud == s_baud_table[j]) { valid = 1; break; }
            }
            if (!valid)
            {
                proto_send_response("ER8");  /* 无效波特率 */
                return;
            }
        }

        s_baud_rate = new_baud;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧波特率发完响应, 再切硬件 */
        proto_send_response("OK");

        /* 等待 DMA 发送完成, 然后切换到新波特率 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_baud_set(s_baud_rate);
    }
    else
    {
        /* ---- 读模式: 返回当前波特率 ---- */
        sprintf(buf, "%lu", (unsigned long)s_baud_rate);
        proto_send_response(buf);
    }
}

/* ---- PT: 读/写校验位 ---- */
static void handler_pt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data != NULL && data_len > 0)
    {
        /* ---- 写模式: 设置校验位 ---- */
        uint8_t new_parity;
        char    c = data[0];

        /* 大小写不敏感 */
        if (c >= 'a' && c <= 'z') c -= 32;

        if (c == 'N')
            new_parity = PROTO_PARITY_NONE;
        else if (c == 'O')
            new_parity = PROTO_PARITY_ODD;
        else if (c == 'E')
            new_parity = PROTO_PARITY_EVEN;
        else
        {
            proto_send_response("ER8");  /* 无效校验位 */
            return;
        }

        s_parity = new_parity;
        flash_cfg_save();                /* 持久化到 Flash */

        /* 用旧校验位发完响应, 再切硬件 */
        proto_send_response("OK");

        /* 等待 DMA 发送完成, 然后切换到新校验位 */
        {
            extern volatile uint8_t g_usart_dma_tx_busy;
            while (g_usart_dma_tx_busy);
        }
        usart_parity_set(s_parity);
    }
    else
    {
        /* ---- 读模式: 返回当前校验位 ---- */
        const char *p;
        if (s_parity == PROTO_PARITY_ODD)
            p = "O";
        else if (s_parity == PROTO_PARITY_EVEN)
            p = "E";
        else
            p = "N";
        proto_send_response(p);
    }
}

/* ---- BT: 只读数据位 ---- */
static void handler_bt(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;
    (void)data;
    (void)data_len;

    /* 读模式: 返回 "8" 或 "9" */
    if (s_data_bits == PROTO_DATA_BITS_9)
        proto_send_response("9");
    else
        proto_send_response("8");
}

/* ---- SB: 读/写停止位 ---- */
static void handler_sb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;

    if (data != NULL && data_len > 0)
    {
        /* ---- 写模式: 设置停止位 ---- */
        uint8_t new_stop;
        char    c = data[0];

        if (c == '1')
            new_stop = PROTO_STOP_BITS_1;
        else if (c == '2')
            new_stop = PROTO_STOP_BITS_2;
        else
        {
            proto_send_response("ER8");  /* 无效停止位 */
            return;
        }

        s_stop_bits = new_stop;
        flash_cfg_save();                /* 持久化到 Flash */

        proto_send_response("OK");
        usart_stop_bits_set(s_stop_bits);
    }
    else
    {
        /* ---- 读模式: 返回当前停止位 ---- */
        if (s_stop_bits == PROTO_STOP_BITS_2)
            proto_send_response("2");
        else
            proto_send_response("1");
    }
}

/* ---- PR: 读分辨率 ---- */
static void handler_pr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;           /* 只读自身站号, 不覆盖 */
    proto_send_response(s_resolution_names[s_resolution_idx]);
}

/* ---- MD: 调试 - 输出全部校准相关参数 ---- */
static void handler_md(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[200];
    uint16_t flag;
    float m_z1, m_z2, a_z1, a_z2;
    uint8_t m_z1_ok, m_z2_ok, a_z1_ok, a_z2_ok;
    uint8_t m_z1_raw[8], m_z2_raw[8];
    uint8_t pos = 0;
    (void)data; (void)data_len;
    (void)station;

    rcu_periph_clock_enable(RCU_PMU);
    rcu_periph_clock_enable(RCU_BKPI);
    flag = bkp_read_data(BKP_DATA_0);

    /* 读取各区域原始数据 */
    a_z1_ok = calib_read_zone(FLASH_CALIB_ADDER1_ADDR, &a_z1);
    a_z2_ok = calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &a_z2);
    m_z1_ok = calib_read_zone(FLASH_CALIB_MULT1_ADDR, &m_z1);
    m_z2_ok = calib_read_zone(FLASH_CALIB_MULT2_ADDR, &m_z2);

    /* 读各区域原始8字节 (魔数+版本+float) */
    uint8_t a_z1_raw[8], a_z2_raw[8];
    intflash_read(a_z1_raw, FLASH_CALIB_ADDER1_ADDR, 8);
    intflash_read(a_z2_raw, FLASH_CALIB_ADDER2_ADDR, 8);
    intflash_read(m_z1_raw, FLASH_CALIB_MULT1_ADDR, 8);
    intflash_read(m_z2_raw, FLASH_CALIB_MULT2_ADDR, 8);

    pos += sprintf(&buf[pos], "BKP:%04X ", flag);
    pos += sprintf(&buf[pos], "Mrg:%.4f ", (double)s_mult_merged_val);
    pos += sprintf(&buf[pos], "RunM:%.4f ", (double)s_calib_mult);
    pos += sprintf(&buf[pos], "RunA:%.4f ", (double)s_calib_adder);
    pos += sprintf(&buf[pos], "A1:%s%.4f ", a_z1_ok ? "" : "X", (double)a_z1);
    pos += sprintf(&buf[pos], "A2:%s%.4f ", a_z2_ok ? "" : "X", (double)a_z2);
    pos += sprintf(&buf[pos], "M1:%s%.4f ", m_z1_ok ? "" : "X", (double)m_z1);
    pos += sprintf(&buf[pos], "M2:%s%.4f ", m_z2_ok ? "" : "X", (double)m_z2);
    pos += sprintf(&buf[pos], "A1R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   a_z1_raw[0], a_z1_raw[1], a_z1_raw[2], a_z1_raw[3],
                   a_z1_raw[4], a_z1_raw[5], a_z1_raw[6], a_z1_raw[7]);
    pos += sprintf(&buf[pos], " A2R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   a_z2_raw[0], a_z2_raw[1], a_z2_raw[2], a_z2_raw[3],
                   a_z2_raw[4], a_z2_raw[5], a_z2_raw[6], a_z2_raw[7]);
    pos += sprintf(&buf[pos], " M1R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   m_z1_raw[0], m_z1_raw[1], m_z1_raw[2], m_z1_raw[3],
                   m_z1_raw[4], m_z1_raw[5], m_z1_raw[6], m_z1_raw[7]);
    pos += sprintf(&buf[pos], " M2R:%02X%02X%02X%02X%02X%02X%02X%02X",
                   m_z2_raw[0], m_z2_raw[1], m_z2_raw[2], m_z2_raw[3],
                   m_z2_raw[4], m_z2_raw[5], m_z2_raw[6], m_z2_raw[7]);

    /* 测试: 直接写0x0803E800并读回 */
    {
        uint8_t test_buf[8] = {0xA5, 0xF3, 0x01, 0x00, 0x00, 0x00, 0x00, 0x40}; /* 2.0的前8字节 */
        uint8_t test_read[8];
        intflash_erase_page(0x0803D800);
        intflash_write(test_buf, 0x0803D800, 8);
        intflash_read(test_read, 0x0803D800, 8);
        pos += sprintf(&buf[pos], " TST:%02X%02X%02X%02X%02X%02X%02X%02X",
                       test_read[0], test_read[1], test_read[2], test_read[3],
                       test_read[4], test_read[5], test_read[6], test_read[7]);
    }

    proto_send_response(buf);
}

/* ====================================================================================
 * 写指令处理函数
 * ==================================================================================== */

/* ---- SC: 串口流式输出开关 (切换, 返回当前状态) ---- */
static void handler_sc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)data; (void)data_len;
    (void)station;

    s_stream_enable = !s_stream_enable;  /* 切换开关 */
    proto_send_response(s_stream_enable ? "ON" : "OFF");
}

uint8_t proto_get_stream_enable(void)
{
    return s_stream_enable;
}

/* ---- PA: 读加法器 (一区生效值, 二区待生效值) ---- */
static void handler_pa(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    float zone2_val;
    (void)data; (void)data_len;
    (void)station;

    if (!calib_read_zone(FLASH_CALIB_ADDER2_ADDR, &zone2_val))
        zone2_val = 0.0f;
    sprintf(buf, "%.4f,%.4f", (double)s_calib_adder, (double)zone2_val);
    proto_send_response(buf);
}

/* ---- PM: 读乘法器 (一区生效值, 二区待生效值) ---- */
static void handler_pm(uint8_t station, const char *data, uint8_t data_len)
{
    char buf[48];
    float zone2_val;
    (void)data; (void)data_len;
    (void)station;

    if (!calib_read_zone(FLASH_CALIB_MULT2_ADDR, &zone2_val))
        zone2_val = 0.0f;
    sprintf(buf, "%.4f,%.4f", (double)s_calib_mult, (double)zone2_val);
    proto_send_response(buf);
}

/* ---- ACC: 写量程精度 ---- */
static void handler_acc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        s_accuracy = (float)atof(data);
    }
    proto_send_response("OK");
}

/* ---- ADR: 写站号 ---- */
static void handler_adr(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len >= 2)
    {
        uint8_t new_station = hex2u8(data);
        s_station = new_station;
        flash_station_save();       /* 持久化到独立扇区 2045 */
    }
    proto_send_response("OK");
}

/* ---- EWO: 写 EEPROM 使能 ---- */
static void handler_ewo(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    if (data != NULL && data_len > 0)
    {
        s_eeprom_en = (data[0] == '1') ? 1 : 0;
    }
    proto_send_response("OK");
}

/* ---- PPI: 写压力分辨率 ---- */
static void handler_ppi(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");   /* 缺少数据 */
        return;
    }

    /* 遍历查表, 匹配分辨率字符串 */
    for (i = 0; i < RESOLUTION_TABLE_SIZE; i++)
    {
        if (strncmp(data, s_resolution_names[i], data_len) == 0
            && s_resolution_names[i][data_len] == '\0')
        {
            /* 合法值: 更新全局闸门目标 */
            s_resolution_idx = i;
            g_target_ref_count = s_resolution_ref_counts[i];
            /* 同步信号计数闸门目标 */
            g_target_signal_count_ch1 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH1 / RESOLUTION_BASE_REF_COUNT);
            g_target_signal_count_ch2 = (uint32_t)((uint64_t)g_target_ref_count * DEFAULT_SIGNAL_COUNT_CH2 / RESOLUTION_BASE_REF_COUNT);

            /* 持久化到 Flash */
            flash_resolution_save();

            proto_send_response("OK");
            return;
        }
    }

    /* 未匹配 → 无效参数 */
    proto_send_response("ER8");
}

/* ---- PAA: 写加法器校准 (写入二区, 下次上电合并到一区) ---- */
static void handler_paa(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;
    if (data != NULL && data_len > 0)
    {
        float val = (float)atof(data);
        if (!calib_write_zone(FLASH_CALIB_ADDER2_ADDR, val))
        {
            proto_send_response("ER9");  /* Flash写入失败 */
            return;
        }
    }
    proto_send_response("OK");
}

/* ---- PMB: 写乘法器校准 (写入二区, 下次上电合并到一区) ---- */
static void handler_pmb(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;
    if (data != NULL && data_len > 0)
    {
        float val = (float)atof(data);
        if (!calib_write_zone(FLASH_CALIB_MULT2_ADDR, val))
        {
            proto_send_response("ER9");  /* Flash写入失败 */
            return;
        }
    }
    proto_send_response("OK");
}

/* ---- TPC: 写标定系数 (暂存, 后续可更新多项式矩阵) ---- */
static void handler_tpc(uint8_t station, const char *data, uint8_t data_len)
{
    (void)station;           /* 只读自身站号, 不覆盖 */
    /* TPC 系数格式较复杂, 暂只返回 OK, 后续实现具体解析 */
    (void)data; (void)data_len;
    proto_send_response("OK");
}

/* ---- WVR: 写版本号 (3字符写指令) ---- */
static void handler_wvr(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t buf[32];
    uint8_t len, i;

    (void)station;           /* 只读自身站号, 不覆盖 */

    if (data == NULL || data_len == 0)
    {
        proto_send_response("ER7");  /* 缺少版本号 */
        return;
    }

    /* 限制长度 */
    len = (data_len > 23) ? 23 : data_len;

    /* 更新内存 */
    for (i = 0; i < len; i++)
        s_fw_version[i] = data[i];
    s_fw_version[len] = '\0';

    /* 写入内部Flash */
    intflash_erase_page(FLASH_STORE_ADDR);

    buf[0] = (uint8_t)(FLASH_STORE_MAGIC >> 8);
    buf[1] = (uint8_t)(FLASH_STORE_MAGIC);
    buf[2] = len;
    for (i = 0; i < len; i++)
        buf[3 + i] = (uint8_t)s_fw_version[i];
    for (; i < 29; i++)
        buf[3 + i] = 0xFF;

    intflash_write(buf, FLASH_STORE_ADDR, 32);
    proto_send_response("OK");
}

/* ---- ID: 写序列号 (2字符写指令) ----
 *
 * 格式: #01XXID<12位序列号>\r<CK>
 * 序列号: "XSTK" + 8位后缀 (0-9 A-Z a-z, 存储时统一转大写)
 * 示例: #0100IDXSTK24505322\rXX
 * ---- */
static void handler_id_write(uint8_t station, const char *data, uint8_t data_len)
{
    uint8_t i;
    (void)station;

    if (data == NULL || data_len != 12)
    {
        proto_send_response("ER8");  /* 长度必须为12 */
        return;
    }

    /* 验证前缀 "XSTK" (大小写不敏感) */
    for (i = 0; i < 4; i++)
    {
        char c = data[i];
        if (c >= 'a' && c <= 'z') c -= 32;
        if (c != "XSTK"[i])
        {
            proto_send_response("ER8");  /* 前缀错误 */
            return;
        }
    }

    /* 验证后缀8位: 0-9 A-Z a-z, 统一转大写存入 */
    for (i = 4; i < 12; i++)
    {
        char c = data[i];
        if (c >= 'a' && c <= 'z') c -= 32;  /* 小写转大写 */
        if (!((c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z')))
        {
            proto_send_response("ER8");  /* 后缀含非法字符 */
            return;
        }
        s_serial[i] = c;
    }
    s_serial[0] = 'X';
    s_serial[1] = 'S';
    s_serial[2] = 'T';
    s_serial[3] = 'K';
    s_serial[12] = '\0';

    flash_serial_save();  /* 持久化到内部Flash */
    proto_send_response("OK");
}
