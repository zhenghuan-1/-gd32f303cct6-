# GD32F303 双通道频率计 + 气压传感器

## 硬件

| 项 | 规格 |
|---|------|
| MCU | GD32F303CCT6 (Cortex-M4, 120MHz, 256KB Flash, 48KB RAM) |
| 外存 | W25Q64 8MB NOR Flash (SPI0, 30MHz) |
| 显示 | OLED 128×64 (I2C0) |
| CH1 | PA8 — TIMER0 CH0 + TIMER4 等精度测量 |
| CH2 | PA0 — TIMER1 ETI + TIMER5 等精度测量 |
| 气压 | 5阶2D多项式 + 6点滑动窗口 (21 个 float 系数) |
| 串口 | USART0, DMA0 CH4 RX 环形 256B + DMA0 CH3 TX 512B, IDLE 中断帧边界 |

## 引脚

| 引脚 | 功能 |
|------|------|
| PA8 | CH1 频率信号输入 |
| PA0 | CH2 频率信号输入 |
| PA9 | USART0 TX |
| PA10 | USART0 RX |
| PA2 | SPI0 CS (Flash) |
| PA4 | DAC 输出 |
| PB6 | I2C0 SCL (OLED) |
| PB7 | I2C0 SDA (OLED) |

## 编译

```
Keil MDK-ARM V5 + ARM Compiler 6.21
GD32F303.uvprojx
```

```
Program Size: Code=26620  RO-data=4352  RW-data=64  ZI-data=8312
Flash: ~31KB / 256KB  |  RAM: ~6KB / 48KB  |  Error: 0  |  Warning: 5
```

## 协议迁移 (旧→新)

旧协议 (人机交互, `\r\n` 结尾) 已完全删除，功能由新协议覆盖：

| 旧命令 | 功能 | 新协议替代 |
|--------|------|-----------|
| `DAC:mV` | 设置 DAC 输出 | 暂无 (DAC 驱动保留，待加指令) |
| `WRITE:str` | 写入 Flash | `WVR` (写版本号到扇区2047) |
| `READ:addr` | 读 Flash 32字节 | 无需手动读 (Flash 对用户透明) |
| `ERASE:addr` | 擦除 Flash 扇区 | 自动管理 (顺序追加, 扇区满才擦) |
| `ADDR:addr` | 设置写入地址 | 自动管理 |
| `INFO` | 显示 Flash 信息 | 分别查询: `ST` `VG` `SN` `FS` |
| `TEMP` | 读 MCU 温度 | `T3` |
| `?` | 查询全部状态 | 组合发送各读指令 |

---

## 串口协议 (新)

### 帧格式

```
请求:  #01XX<CMD>[DATA]\r<CKSUM>
响应:  *01XX<DATA>\r\n<CKSUM>

CKSUM = XOR(帧头..\r前全部字节), 2位大写 hex
帧头: # (请求)  * (响应)
01:   设备地址 (PROTO_DEV_ADDR)
XX:   站号 (2位 hex)
```

### 指令表

#### 读指令 (2字符)

| 指令 | 功能 | 示例 |
|------|------|------|
| ST | 通讯查验 | `#0100ST\r<CK>` → `*0100OK\r\n<CK>` |
| VG | 固件版本 | `#0100VG\r<CK>` → `*0100XSTK-GQY03-2026.01\r\n<CK>` |
| P3 | 气压值 | `#0100P3\r<CK>` → `*0100-14447.85\r\n<CK>` |
| T3 | MCU温度 | `#0100T3\r<CK>` → `*010035.24\r\n<CK>` |
| H3 | 高度 | `#0100H3\r<CK>` → `*0100N/A\r\n<CK>` (预留) |
| **F5** | 双路频率 | `#0100F5\r<CK>` → `*010012345.678,9876.543\r\n<CK>` |
| SN | 序列号 | `#0100SN\r<CK>` → `*010024505322\r\n<CK>` |
| FS | 量程 | `#0100FS\r<CK>` → `*01000-1000\r\n<CK>` |
| **BR** | 波特率 | `#0100BR\r<CK>` → `*01009600\r\n<CK>` |
| **PT** | 校验位 | `#0100PT\r<CK>` → `*0100N\r\n<CK>` |
| PR | 分辨率 | `#0100PR\r<CK>` → `*01000.01\r\n<CK>` |

#### 写指令 (BR/PT 支持读+写双模)

| 指令 | 功能 | 示例 |
|------|------|------|
| **BR** | 设波特率 | `#0100BR38400\r<CK>` → `*0100OK\r\n<CK>` |
| **PT** | 设校验位 | `#0100PTO\r<CK>` → `*0100OK\r\n<CK>` |
| ID | 写序列号 | `#0100ID12345678\r<CK>` → `*0100OK\r\n<CK>` |
| ADR | 写站号 | `#0100ADR02\r<CK>` → `*0100OK\r\n<CK>` |
| ACC | 写精度 | `#0100ACC0.05\r<CK>` → `*0100OK\r\n<CK>` |
| PPI | 写分辨率 | `#0100PPI0.001\r<CK>` → `*0100OK\r\n<CK>` |
| PAA | 加法器校准 | `#0100PAA1.5\r<CK>` → `*0100OK\r\n<CK>` |
| PMB | 乘法器校准 | `#0100PMB0.98\r<CK>` → `*0100OK\r\n<CK>` |
| TPC | 标定系数 | `#0100TPC...\r<CK>` → `*0100OK\r\n<CK>` (预留) |
| EWO | EEPROM写使能 | `#0100EWO1\r<CK>` → `*0100OK\r\n<CK>` (预留) |
| WVR | 写版本号 | `#0100WVRNewVer\r<CK>` → `*0100OK\r\n<CK>` |

#### 错误码

| 码 | 含义 |
|----|------|
| ER1 | 帧太短 (<10字节) |
| ER2 | 缺少 `\r` 或校验和不完整 |
| ER3 | 校验和错误 |
| ER4 | 帧头错误 (非 `#`) |
| ER5 | 无指令码 |
| ER6 | 未知指令 |
| ER7 | 缺少数据 (WVR) |
| ER8 | 无效参数 (BR/PT) |

#### 固定参数

| 参数 | 值 |
|------|-----|
| 默认波特率 | 9600 |
| 允许波特率 | 2400, 4800, 9600, 19200, 38400, 57600, 115200 |
| 允许校验位 | N (无), O (奇), E (偶) |
| 默认校验位 | N |
| 设备地址 | 0x01 |
| 固件版本 | XSTK-GQY03-2026.01 |

### 校验和计算

```
用法: python checksum.py "#0100ST"
输出: #0100ST\r28

其中 28 为 XOR 校验和 (XOR 从 # 到 \r 每个字节)
```

## Flash 存储 (W25Q64)

```
8MB 全空间:
├── 0x000000 ~ 0x7FDFFF   空白 (2046 扇区, 未使用)
├── 0x7FE000 ~ 0x7FEFFF   配置区  (扇区 2046, 磨损均衡)
└── 0x7FF000 ~ 0x7FFFFF   版本号  (扇区 2047)

配置区 (扇区 2046) — 顺序追加写入:
  每条 32 字节 × 128 槽
  [A5 F3][格式01][波特率 4B][站号 1B][校验位 1B][保留 FF...]
  寿命: 100,000 × 128 = 1280 万次擦写

版本号 (扇区 2047):
  [A5 F3][版本长度][版本字符串 ASCII]
```

### 写入策略

```
改配置 → 不擦除 → 追加到下一空白槽
128 槽写满 → 擦除整扇区 1 次 → 从槽 0 重新开始

读配置: 从槽 127 往槽 0 倒扫，第一个魔数匹配 = 最新
```

## 上电流程

```
1. delay_init(120MHz)
2. LED_Init
3. NORFLASH_Init (SPI0 30MHz) → Flash 检测 (LED 闪烁)
4. flash_store_init()   → 读扇区 2047, 加载版本号
5. flash_cfg_init()     → 读扇区 2046, 倒扫加载最新配置
6. usart_init(保存的波特率)
7. usart_parity_set(保存的校验位)
8. OLED / DAC / ADC / 频率测量 / 气压计算 / 协议 初始化
9. printf 启动信息
10. 主循环
```

## 主循环

```
每 200ms:
  ├── CH1 等精度测量 → 缓存 g_freq_ch1_x1000
  └── CH2 等精度测量 → 缓存 g_freq_ch2_x1000

两路都完成时:
  ├── 推入气压滑动窗口 (6 点)
  └── 累加到5次 (≈1秒):
        ├── 气压 5阶2D多项式计算
        ├── MCU 内部温度 + 延迟补偿自适应
        ├── printf 串口输出
        ├── OLED 刷新
        └── 协议帧处理 (g_proto_frame_ready)

CPU 占用: <1% (200ms 闸门内处理 <3ms)
```

## 文件结构

```
气压/
├── User/
│   ├── main.c              # 主程序 (209行)
│   ├── protocol.c          # 协议解析 + Flash 顺序写入
│   ├── protocol.h          # 协议常量 + Flash 地址/偏移宏
│   ├── stm32f10x_conf.h    # GD32 外设配置
│   └── ...
├── Drivers/
│   ├── SYSTEM/
│   │   ├── usart/usart.c   # DMA RX环形 + DMA TX + IDLE中断帧提取
│   │   ├── delay/          # 微秒/毫秒延时
│   │   └── sys/            # 系统初始化
│   └── BSP/
│       ├── NORFLASH/       # W25Q64 全功能驱动 (SPI0 30MHz)
│       ├── pin/
│       │   ├── freq_measure.c  # 等精度双通道频率测量
│       │   ├── pressure_calc.c # 5阶2D多项式 + 6点滑动窗口
│       │   ├── dac.c           # DAC 输出
│       │   └── adc.c           # MCU 内部温度
│       ├── OLED/           # 128×64 I2C 驱动
│       └── LED/            # 板载 LED
├── checksum.py             # XOR 校验和计算工具
├── build_log.txt           # 编译日志
└── README.md
```

> 旧协议 (DAC/WRITE/READ/ERASE/ADDR/INFO/TEMP/?) 已完全删除。
> usart 模块已清理，仅保留 DMA 驱动 + 协议帧路由 (`#` → `g_proto_rx_buf`)。

## 内存安全

| 检查项 | 状态 |
|--------|:--:|
| malloc/free | ❌ 无调用 |
| 递归 | ❌ 无 |
| 全局缓冲 | ✅ 固定编译时大小 |
| 栈最深 | ~400B (剩余 ~42KB) |
| ISR 时长 | <5μs 总计 |
| printf/DMA 冲突 | ⚠️ 理论存在, 概率极低 |
