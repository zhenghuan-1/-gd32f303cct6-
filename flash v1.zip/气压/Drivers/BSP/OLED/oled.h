/************************************************ 
* WKS Nano GD32������
* OLED ��������	   
* �汾��V1.1							  
************************************************/	

#ifndef __OLED_H
#define __OLED_H
#include "sys.h"

//OLEDģʽ����(��������)
//0: 4��SPIģʽ ��ģ���BS1=0��
//1: IICģʽ    ��ģ���BS1=1��
#define OLED_MODE 	1
		    						  
//-----------------OLED�˿ڶ���----------------  		
#define OLED_CS(x)      do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_6, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_6, RESET); \
                        }while(0)      
#define OLED_DC(x)      do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_7, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_7, RESET); \
                        }while(0) 
#define OLED_BS1(x)      do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_5, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_5, RESET); \
                        }while(0) 
#define OLED_RST(x)     do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_0, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_0, RESET); \
                        }while(0) 	
 

//ʹ��4��SPI�ӿ�ʱʹ�� 
#define OLED_SCLK(x)    do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_13, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_13, RESET); \
                        }while(0) 
#define OLED_SDIN(x)    do{ x ? \
												    gpio_bit_write(GPIOB, GPIO_PIN_15, SET) : \
												    gpio_bit_write(GPIOB, GPIO_PIN_15, RESET); \
                        }while(0) 

#define OLED_CMD  	0		//д����
#define OLED_DATA 	1		//д����

//OLED�����ú���
void OLED_WR_Byte(uint8_t dat,uint8_t cmd);	    
void OLED_Display_On(void);
void OLED_Display_Off(void);
void OLED_Refresh_Gram(void);		   
							   		    
void OLED_Init(void);
void OLED_Clear(void);
void OLED_DrawPoint(uint8_t x,uint8_t y,uint8_t t);
void OLED_Fill(uint8_t x1,uint8_t y1,uint8_t x2,uint8_t y2,uint8_t dot);
void OLED_ShowChar(uint8_t x,uint8_t y,uint8_t chr,uint8_t size,uint8_t mode);
void OLED_ShowNum(uint8_t x,uint8_t y,uint32_t num,uint8_t len,uint8_t size);
void OLED_ShowString(uint8_t x,uint8_t y,const uint8_t *p,uint8_t size);

//中文显示函数
int OLED_FindChineseIndex(const char *chinese);
void OLED_ShowChinese(uint8_t x,uint8_t y,const char *chinese);
void OLED_ShowChineseString(uint8_t x,uint8_t y,const char *str);
void OLED_ShowMixString(uint8_t x,uint8_t y,const char *str);
												
#endif
