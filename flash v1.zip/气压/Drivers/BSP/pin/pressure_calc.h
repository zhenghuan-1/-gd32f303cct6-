/**
 * ====================================================================================
 * @file     pressure_calc.h
 * @brief    气压计算模块 - 基于双通道频率的2D多项式标定
 * ====================================================================================
 *
 * 公式来源: 24505322# 传感器标定参数 (实验参数频率-气压转换公式.xls)
 *
 * 归一化:
 *   x = (f1 - DELTA_PS1) / PS1
 *   y = (f2 - DELTA_PS2) / PS2
 *
 * 气压 = Σ k[i][j] * x^j * y^i   (i=0..5, j=0..5-i)
 *
 * 使用6点滑动窗口，每收到一组新频率就更新，计算气压均值输出。
 * ====================================================================================
 */

#ifndef __PRESSURE_CALC_H__
#define __PRESSURE_CALC_H__

#include "gd32f30x.h"

/* 滑动窗口大小 */
#define PRESSURE_WINDOW_SIZE    6

/* 标定参数 (来自 .xls 文件) */
#define DELTA_PS1   65000.0f
#define PS1         3800.0f
#define DELTA_PS2   59000.0f
#define PS2         3700.0f

/**
 * @brief  模块初始化（清零滑动窗口）
 */
void pressure_calc_init(void);

/**
 * @brief  推入一组新的频率测量值（freq_x1000 格式，即频率×1000）
 * @param  ch1_freq_x1000: CH1 频率×1000
 * @param  ch2_freq_x1000: CH2 频率×1000
 */
void pressure_calc_push(uint32_t ch1_freq_x1000, uint32_t ch2_freq_x1000);

/**
 * @brief  计算当前滑动窗口内所有样本的气压均值
 * @return 气压值 (单位取决于标定系数，通常为 hPa)
 */
float pressure_calc_get(void);

/**
 * @brief  获取当前窗口中的有效样本数 (0~6)
 */
uint8_t pressure_calc_count(void);

/**
 * @brief  读取滑动窗口原始频率数据 (按时间顺序, 最旧→最新)
 * @param  ch1_out: 输出 CH1 频率数组 (至少 PRESSURE_WINDOW_SIZE 长度)
 * @param  ch2_out: 输出 CH2 频率数组
 * @return 有效样本数 (0~6)
 */
uint8_t pressure_calc_get_window(uint32_t *ch1_out, uint32_t *ch2_out);

/**
 * @brief  通过串口打印当前窗口所有样本的气压值
 */
void pressure_calc_debug_print(void);

/**
 * @brief  根据气压计算高度 (三层大气模型, ISA标准)
 * @param  pressure_hpa: 气压值 (hPa)
 * @return 高度值 (m), 范围 -2000 ~ 32000
 */
float pressure_to_altitude(float pressure_hpa);

#endif
