/* ====================================================================================
 * 文件: pressure_calc.c
 * 描述: 气压计算模块 - 6点滑动窗口 + 2D多项式标定
 * ====================================================================================
 *
 * 传感器: 24505322#
 * 公式:   P = Σ k[i][j] * x^j * y^i
 * 其中:   x = (f1/1000 - 65000) / 3800
 *         y = (f2/1000 - 59000) / 3700
 *
 * 优化: 先对6个样本的频率取均值, 再算一次多项式, 精度无损, 计算量降为1/6
 *       频率滤波由 main.c 中值窗口统一处理, 此处仅做均值平均
 * ==================================================================================== */

#include "pressure_calc.h"
#include <math.h>

/* ====================================================================================
 * 标定系数矩阵 k[i][j] — 对应 x^j * y^i
 *
 *  i\j |    0         1         2         3         4         5
 *  ----+----------------------------------------------------------
 *   0  | 661.934   628.384    19.319   -65.338   869.761  4363.372
 *   1  |-538.864   -11.108  -210.361  3472.180  22136.616
 *   2  | -31.062  -225.548  5228.961  45853.375
 *   3  | -80.167  3521.447  45020.692
 *   4  | 894.836  23392.129
 *   5  | 4781.604
 * ==================================================================================== */
static const float k[6][6] = {
    { 661.933891f,   628.383544f,    19.318891f,   -65.337509f,   869.761164f,  4363.371597f},
    {-538.863937f,   -11.107721f,  -210.360991f,  3472.179803f, 22136.615546f,          0.0f},
    { -31.061953f,  -225.548104f,  5228.960876f, 45020.691682f,          0.0f,          0.0f},
    { -80.166787f,  3521.446816f, 45853.375261f,          0.0f,          0.0f,          0.0f},
    { 894.836195f, 23392.128518f,          0.0f,          0.0f,          0.0f,          0.0f},
    {4781.604294f,          0.0f,          0.0f,          0.0f,          0.0f,          0.0f}
};

/* ====================================================================================
 * 滑动窗口
 * ==================================================================================== */
static uint32_t s_ch1_buf[PRESSURE_WINDOW_SIZE];
static uint32_t s_ch2_buf[PRESSURE_WINDOW_SIZE];
static uint8_t  s_count     = 0;
static uint8_t  s_write_idx = 0;

/* ====================================================================================
 * 公共函数实现
 * ==================================================================================== */

void pressure_calc_init(void)
{
    uint8_t i;
    for (i = 0; i < PRESSURE_WINDOW_SIZE; i++)
    {
        s_ch1_buf[i] = 0;
        s_ch2_buf[i] = 0;
    }
    s_count     = 0;
    s_write_idx = 0;
}

void pressure_calc_push(uint32_t ch1_freq_x1000, uint32_t ch2_freq_x1000)
{
    s_ch1_buf[s_write_idx] = ch1_freq_x1000;
    s_ch2_buf[s_write_idx] = ch2_freq_x1000;

    s_write_idx++;
    if (s_write_idx >= PRESSURE_WINDOW_SIZE)
        s_write_idx = 0;

    if (s_count < PRESSURE_WINDOW_SIZE)
        s_count++;
}

float pressure_calc_get(void)
{
    float result = 0.0f;
    uint8_t i, j;
    static float s_last_valid = 0.0f;  /* 上一次有效气压值 */

    if (s_count == 0)
        return 0.0f;

    /* 先求频率均值(整数累加, 无损精度), 再归一化算多项式 */
    {
        uint64_t sum1 = 0, sum2 = 0;
        for (i = 0; i < s_count; i++)
        {
            sum1 += s_ch1_buf[i];
            sum2 += s_ch2_buf[i];
        }

        float f1 = (float)(sum1 / s_count) / 1000.0f;
        float f2 = (float)(sum2 / s_count) / 1000.0f;
        float x  = (f1 - DELTA_PS1) / PS1;
        float y  = (f2 - DELTA_PS2) / PS2;

        /* 输入限幅: x,y超出[-3,3]说明窗口有异常值, 返回上次有效值 */
        if (x > 3.0f || x < -3.0f || y > 3.0f || y < -3.0f)
            return (s_last_valid > 0.0f) ? s_last_valid : 0.0f;

        /* 预计算 x 和 y 的各次幂 */
        float xp[6], yp[6];
        xp[0] = 1.0f;  yp[0] = 1.0f;
        for (i = 1; i < 6; i++)
        {
            xp[i] = xp[i - 1] * x;
            yp[i] = yp[i - 1] * y;
        }

        /* 多项式累加: result += k[i][j] * x^j * y^i */
        for (i = 0; i < 6; i++)
        {
            for (j = 0; j < 6 - i; j++)
            {
                result += k[i][j] * xp[j] * yp[i];
            }
        }
    }

    if (result > 0.0f) s_last_valid = result;
    return result;
}

uint8_t pressure_calc_count(void)
{
    return s_count;
}

/* ====================================================================================
 * 气压→高度转换 (三层大气模型, ISA标准)
 * ====================================================================================
 *
 * 常数:
 *   R  = 287.05287 m²/(K·s²)    干空气气体常数
 *   gn = 9.80665   m/s²          标准重力加速度
 *
 * 第一层 对流层: 226.32 < Ps < 1277.74 hPa, H = -2000 ~ 11000 m
 *   β=-0.0065 K/m, Hb=-2000m, Tb=301.15K, Pb=1277.74 hPa
 *   H = (Tb/β) × [(Ps/Pb)^(-βR/gn) - 1] + Hb
 *
 * 第二层 等温层: 54.75 ≤ Ps ≤ 226.32 hPa, H = 11000 ~ 20000 m
 *   β=0, Hb=11000m, Tb=216.65K, Pb=226.32 hPa
 *   H = (R·Tb/gn) × ln(Pb/Ps) + Hb
 *
 * 第三层 逆温层: Ps < 54.75 hPa, H = 20000 ~ 32000 m
 *   β=0.001 K/m, Hb=20000m, Tb=216.65K, Pb=54.7487 hPa
 *   H = (Tb/β) × [(Ps/Pb)^(-βR/gn) - 1] + Hb
 * ==================================================================================== */

/* 预计算的无量纲指数 */
#define L1_EXPONENT   0.1902631f   /* -βR/gn = 0.0065*287.05287/9.80665 */
#define L3_EXPONENT  -0.02927125f  /* -βR/gn = -0.001*287.05287/9.80665 */

float pressure_to_altitude(float pressure_hpa)
{
    float h;

    if (pressure_hpa <= 0.0f)
        return 0.0f;

    if (pressure_hpa > 226.32f)
    {
        /* 第一层: 对流层, β=-0.0065, Tb/β = -46330.77 */
        float ratio = pressure_hpa / 1277.74f;
        h = -(301.15f / 0.0065f) * (powf(ratio, L1_EXPONENT) - 1.0f) - 2000.0f;
    }
    else if (pressure_hpa >= 54.75f)
    {
        /* 第二层: 等温层 */
        h = (287.05287f * 216.65f / 9.80665f) * logf(226.32f / pressure_hpa) + 11000.0f;
    }
    else
    {
        /* 第三层: 逆温层 */
        float ratio = pressure_hpa / 54.7487f;
        h = (216.65f / 0.001f) * (powf(ratio, L3_EXPONENT) - 1.0f) + 20000.0f;
    }

    return h;
}

uint8_t pressure_calc_get_window(uint32_t *ch1_out, uint32_t *ch2_out)
{
    uint8_t i;
    for (i = 0; i < s_count; i++)
    {
        uint8_t idx = (s_write_idx + PRESSURE_WINDOW_SIZE - s_count + i) % PRESSURE_WINDOW_SIZE;
        ch1_out[i] = s_ch1_buf[idx];
        ch2_out[i] = s_ch2_buf[idx];
    }
    return s_count;
}
