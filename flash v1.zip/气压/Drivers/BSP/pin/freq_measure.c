/* ====================================================================================
 * 文件: freq_measure.c
 * 描述: GD32F303频率测量模块 - 等精度测频法（双通道，独立参考时基）
 * ====================================================================================
 *
 * 测量原理:
 *   �?�?: frequency = (signal_count / ref_count) × ref_clock
 *
 * 定时器配�?:
 *   - TIMER0: 外部时钟模式0，PA8输入，CH1信号计数
 *   - TIMER4: 内部时钟120MHz，CH1�?立参考时�?
 *   - TIMER1: 外部时钟模式0，PA0输入，CH2信号计数
 *   - TIMER5: 内部时钟120MHz，CH2�?立参考时�?
 *
 * 两�?�道完全�?立，各自同�?�启�?，互不干扰�??
 *
 * �?�?:
 *   - TIMER0_UP_IRQn:       TIMER0溢出，CH1信号计数扩展
 *   - TIMER0_Channel_IRQn:  TIMER0捕获，CH1同�?�启�?
 *   - TIMER1_IRQn:          TIMER1统一�?�?，CH2信号计数+同�?�启�?
 *   - TIMER4_IRQn:          TIMER4溢出，CH1参�?��?�数扩展+闸门判断
 *   - TIMER5_IRQn:          TIMER5溢出，CH2参�?��?�数扩展+闸门判断
 * ==================================================================================== */

#include "freq_measure.h"
#include "led.h"
#include <stdio.h>

/* ====================================================================================
 * 通道1 (CH1) 变量
 * ==================================================================================== */
volatile uint8_t  g_ch1_measure_done = 0;
volatile uint32_t g_ch1_signal_count = 0;
volatile uint32_t g_ch1_ref_count = 0;

static volatile uint32_t g_timer0_overflow = 0;
static volatile uint32_t g_timer4_overflow = 0;
static volatile uint8_t  g_ch1_wait_start = 0;

/* ====================================================================================
 * 通道2 (CH2) 变量
 * ==================================================================================== */
volatile uint8_t  g_ch2_measure_done = 0;
volatile uint32_t g_ch2_signal_count = 0;
volatile uint32_t g_ch2_ref_count = 0;
volatile uint32_t g_delay_comp = 7;   /* 校准值, 原来100偏高 */
volatile uint8_t  g_comp_manual = 0;
volatile uint32_t g_target_ref_count = RESOLUTION_BASE_REF_COUNT; /* 默认100ms, 由PR/PPI指令动态调整 */

/* 信号计数闸门目标 — 以信号沿数定义闸门, 消除ref ISR异步抖动 */
volatile uint32_t g_target_signal_count_ch1 = DEFAULT_SIGNAL_COUNT_CH1;  /* 默认 ~100ms @65kHz */
volatile uint32_t g_target_signal_count_ch2 = DEFAULT_SIGNAL_COUNT_CH2;  /* 默认 ~100ms @59kHz */

static volatile uint32_t g_timer1_overflow = 0;
static volatile uint32_t g_timer5_overflow = 0;
static volatile uint8_t  g_ch2_wait_start = 0;

/* ====================================================================================
 * 静�?�函数声�?
 * ==================================================================================== */
static void freq_gpio_init(void);
static void freq_timer0_init(void);     /* CH1 信号计数 */
static void freq_timer4_init(void);     /* CH1 参�?�时�? */
static void freq_timer1_init(void);     /* CH2 信号计数 */
static void freq_timer5_init(void);     /* CH2 参�?�时�? */

/* ====================================================================================
 * �?共函�?
 * ==================================================================================== */

void freq_measure_init(void)
{
    freq_gpio_init();
    freq_timer0_init();
    freq_timer4_init();
    freq_timer1_init();
    freq_timer5_init();
}


void freq_measure_ch1_start(void)
{
    g_ch1_signal_count = 0;
    g_ch1_ref_count = 0;
    g_timer0_overflow = 0;
    g_timer4_overflow = 0;
    g_ch1_measure_done = 0;
    g_ch1_wait_start = 1;
    timer_counter_value_config(TIMER0, 0);
    timer_counter_value_config(TIMER4, 0);
    timer_enable(TIMER0);
}

void freq_measure_ch2_start(void)
{
    g_ch2_signal_count = 0;
    g_ch2_ref_count = 0;
    g_timer1_overflow = 0;
    g_timer5_overflow = 0;
    g_ch2_measure_done = 0;
    g_ch2_wait_start = 1;
    timer_counter_value_config(TIMER1, 0);
    timer_counter_value_config(TIMER5, 0);
    timer_enable(TIMER1);
}

/* ---------- CH1 ---------- */

uint32_t freq_measure_calculate(void)
{
    if (g_ch1_ref_count == 0) return 0;
    return (uint32_t)((uint64_t)g_ch1_signal_count * REF_FREQ_X1000 / g_ch1_ref_count);
}


void freq_measure_print_result(void)
{
    uint32_t freq_x1000 = freq_measure_calculate();
    printf("[CH1] Signal=%u, Ref=%u\r\n", g_ch1_signal_count, g_ch1_ref_count);
    printf("[CH1] Freq=%u.%03u Hz\r\n", freq_x1000 / 1000, freq_x1000 % 1000);
}

/* ---------- CH2 ---------- */

uint32_t freq_measure_ch2_calculate(void)
{
    if (g_ch2_ref_count == 0) return 0;
    return (uint32_t)((uint64_t)g_ch2_signal_count * REF_FREQ_X1000 / g_ch2_ref_count);
}


void freq_measure_ch2_print_result(void)
{
    uint32_t freq_x1000 = freq_measure_ch2_calculate();
    printf("[CH2] Signal=%u, Ref=%u\r\n", g_ch2_signal_count, g_ch2_ref_count);
    printf("[CH2] Freq=%u.%03u Hz\r\n", freq_x1000 / 1000, freq_x1000 % 1000);
}

/* ---------- 便捷 ---------- */



/* ====================================================================================
 * �?�?服务函数
 * ==================================================================================== */

/* ---------- TIMER0 溢出（CH1 信号计数扩展�? ---------- */
void TIMER0_UP_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
        g_timer0_overflow++;
    }
}

/* ---------- TIMER0 捕获（CH1 信号沿同步启停 + 闸门判断） ---------- */
void TIMER0_Channel_IRQHandler(void)
{
    /* 同步启动: 等待第一个上升沿启动 TIMER4 */
    if (g_ch1_wait_start)
    {
        g_ch1_wait_start = 0;
        g_timer0_overflow = 0;
        g_timer4_overflow = 0;
        timer_counter_value_config(TIMER0, 0);
        timer_counter_value_config(TIMER4, 0);
        timer_enable(TIMER4);
        timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);
        return;
    }

    if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_CH0) == SET)
    {
        timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_CH0);

        /* 先读取信号计数 (不需要关中断, 只读 TIMER0 相关) */
        uint32_t t0_ovf = g_timer0_overflow;
        uint16_t t0_cnt = timer_counter_read(TIMER0);
        if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_UP))
        {
            t0_ovf++;
            t0_cnt = timer_counter_read(TIMER0);
            timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
        }
        uint32_t signal_cnt = ((uint32_t)t0_ovf << 16) | t0_cnt;

        /* 闸门判断: signal >= target → 在此信号沿同步停止 */
        if (signal_cnt >= g_target_signal_count_ch1)
        {
            uint32_t t4_ovf;
            uint16_t t4_cnt;

            __disable_irq();

            /* 原子读取参考计数器 */
            t4_ovf = g_timer4_overflow;
            t4_cnt = timer_counter_read(TIMER4);

            timer_disable(TIMER0);

            /* 二次检查溢出标志 (TIMER0 可能刚溢出) */
            if (timer_interrupt_flag_get(TIMER0, TIMER_INT_FLAG_UP))
            {
                t0_ovf++;
                t0_cnt = timer_counter_read(TIMER0);
                timer_interrupt_flag_clear(TIMER0, TIMER_INT_FLAG_UP);
            }
            if (timer_interrupt_flag_get(TIMER4, TIMER_INT_FLAG_UP))
            {
                t4_ovf++;
                t4_cnt = timer_counter_read(TIMER4);
                timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_UP);
            }

            __enable_irq();

            g_ch1_signal_count = ((uint32_t)t0_ovf << 16) | t0_cnt;
            g_ch1_ref_count = t4_ovf * REF_TIMER_PERIOD + t4_cnt - g_delay_comp;
            g_ch1_measure_done = 1;

            timer_disable(TIMER4);
        }
    }
}

/* ---------- TIMER4 溢出（CH1 参�?��?�数 + 闸门�? ---------- */
void TIMER4_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER4, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER4, TIMER_INT_FLAG_UP);
        g_timer4_overflow++;
        /* 闸门判断已移至 TIMER0_Channel_IRQHandler (信号沿同步检查 signal count) */
    }
}

/* ---------- TIMER1 统一（CH2 信号计数 + 同步启停 + 闸门判断） ---------- */
void TIMER1_IRQHandler(void)
{
    /* 溢出 */
    if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
        g_timer1_overflow++;
    }

    /* 捕获 */
    if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_CH0) == SET)
    {
        /* 同步启动: 等待第一个上升沿启动 TIMER5 */
        if (g_ch2_wait_start)
        {
            g_ch2_wait_start = 0;
            g_timer1_overflow = 0;
            g_timer5_overflow = 0;
            timer_counter_value_config(TIMER1, 0);
            timer_counter_value_config(TIMER5, 0);
            timer_enable(TIMER5);
            timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);
            return;
        }

        timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_CH0);

        /* 先读取信号计数 */
        uint32_t t1_ovf = g_timer1_overflow;
        uint16_t t1_cnt = timer_counter_read(TIMER1);
        if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP))
        {
            t1_ovf++;
            t1_cnt = timer_counter_read(TIMER1);
            timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
        }
        uint32_t signal_cnt = ((uint32_t)t1_ovf << 16) | t1_cnt;

        /* 闸门判断: signal >= target → 在此信号沿同步停止 */
        if (signal_cnt >= g_target_signal_count_ch2)
        {
            uint32_t t5_ovf;
            uint16_t t5_cnt;

            __disable_irq();

            /* 原子读取参考计数器 */
            t5_ovf = g_timer5_overflow;
            t5_cnt = timer_counter_read(TIMER5);

            timer_disable(TIMER1);

            /* 二次检查溢出标志 */
            if (timer_interrupt_flag_get(TIMER1, TIMER_INT_FLAG_UP))
            {
                t1_ovf++;
                t1_cnt = timer_counter_read(TIMER1);
                timer_interrupt_flag_clear(TIMER1, TIMER_INT_FLAG_UP);
            }
            if (timer_interrupt_flag_get(TIMER5, TIMER_INT_FLAG_UP))
            {
                t5_ovf++;
                t5_cnt = timer_counter_read(TIMER5);
                timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_UP);
            }

            __enable_irq();

            g_ch2_signal_count = ((uint32_t)t1_ovf << 16) | t1_cnt;
            g_ch2_ref_count = t5_ovf * REF_TIMER_PERIOD + t5_cnt - g_delay_comp;
            g_ch2_measure_done = 1;

            timer_disable(TIMER5);
        }
    }
}

/* ---------- TIMER5 溢出（CH2 参�?��?�数 + 闸门�? ---------- */
void TIMER5_IRQHandler(void)
{
    if (timer_interrupt_flag_get(TIMER5, TIMER_INT_FLAG_UP) == SET)
    {
        timer_interrupt_flag_clear(TIMER5, TIMER_INT_FLAG_UP);
        g_timer5_overflow++;
        /* 闸门判断已移至 TIMER1_IRQHandler (信号沿同步检查 signal count) */
    }
}

/* ====================================================================================
 * 静�?�函数实�?
 * ==================================================================================== */

static void freq_gpio_init(void)
{
    rcu_periph_clock_enable(RCU_GPIOA);
    rcu_periph_clock_enable(RCU_AF);
    gpio_init(FREQ_CH1_INPUT_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, FREQ_CH1_INPUT_PIN);
    gpio_init(FREQ_CH2_INPUT_PORT, GPIO_MODE_IPU, GPIO_OSPEED_50MHZ, FREQ_CH2_INPUT_PIN);
}

/* ---- TIMER0: CH1 信号计数，�?�部时钟模式0，PA8 ---- */
static void freq_timer0_init(void)
{
    timer_parameter_struct timer_initpara;
    timer_ic_parameter_struct icpara;

    rcu_periph_clock_enable(RCU_TIMER0);
    timer_deinit(TIMER0);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = 0xFFFF;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER0, &timer_initpara);

    timer_channel_input_struct_para_init(&icpara);
    icpara.icpolarity  = TIMER_IC_POLARITY_RISING;
    icpara.icselection = TIMER_IC_SELECTION_DIRECTTI;
    icpara.icprescaler = TIMER_IC_PSC_DIV1;
    icpara.icfilter    = 4;
    timer_input_capture_config(TIMER0, TIMER_CH_0, &icpara);

    timer_input_trigger_source_select(TIMER0, TIMER_SMCFG_TRGSEL_CI0FE0);
    timer_slave_mode_select(TIMER0, TIMER_SLAVE_MODE_EXTERNAL0);

    timer_interrupt_enable(TIMER0, TIMER_INT_UP);
    timer_interrupt_enable(TIMER0, TIMER_INT_CH0);
    nvic_irq_enable(TIMER0_UP_IRQn, 0, 0);
    nvic_irq_enable(TIMER0_Channel_IRQn, 0, 0);
}

/* ---- TIMER4: CH1 参�?�时基，内部120MHz ---- */
static void freq_timer4_init(void)
{
    timer_parameter_struct timer_initpara;

    rcu_periph_clock_enable(RCU_TIMER4);
    timer_deinit(TIMER4);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = REF_TIMER_PERIOD - 1;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER4, &timer_initpara);

    timer_interrupt_enable(TIMER4, TIMER_INT_UP);
    nvic_irq_enable(TIMER4_IRQn, 0, 1);  /* 最高抢占优先级0, 闸门定时不能等 */
}

/* ---- TIMER1: CH2 信号计数，�?�部时钟模式0，PA0 ---- */
static void freq_timer1_init(void)
{
    timer_parameter_struct timer_initpara;
    timer_ic_parameter_struct icpara;

    rcu_periph_clock_enable(RCU_TIMER1);
    timer_deinit(TIMER1);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = 0xFFFF;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER1, &timer_initpara);

    timer_channel_input_struct_para_init(&icpara);
    icpara.icpolarity  = TIMER_IC_POLARITY_RISING;
    icpara.icselection = TIMER_IC_SELECTION_DIRECTTI;
    icpara.icprescaler = TIMER_IC_PSC_DIV1;
    icpara.icfilter    = 4;
    timer_input_capture_config(TIMER1, TIMER_CH_0, &icpara);

    timer_input_trigger_source_select(TIMER1, TIMER_SMCFG_TRGSEL_CI0FE0);
    timer_slave_mode_select(TIMER1, TIMER_SLAVE_MODE_EXTERNAL0);

    timer_interrupt_enable(TIMER1, TIMER_INT_UP);
    timer_interrupt_enable(TIMER1, TIMER_INT_CH0);
    nvic_irq_enable(TIMER1_IRQn, 0, 1);
}

/* ---- TIMER5: CH2 参�?�时基，内部120MHz ---- */
static void freq_timer5_init(void)
{
    timer_parameter_struct timer_initpara;

    rcu_periph_clock_enable(RCU_TIMER5);
    timer_deinit(TIMER5);

    timer_struct_para_init(&timer_initpara);
    timer_initpara.prescaler       = 0;
    timer_initpara.alignedmode     = TIMER_COUNTER_EDGE;
    timer_initpara.counterdirection = TIMER_COUNTER_UP;
    timer_initpara.period          = REF_TIMER_PERIOD - 1;
    timer_initpara.clockdivision   = TIMER_CKDIV_DIV1;
    timer_init(TIMER5, &timer_initpara);

    timer_interrupt_enable(TIMER5, TIMER_INT_UP);
    nvic_irq_enable(TIMER5_IRQn, 0, 1);  /* 最高抢占优先级0, 闸门定时不能等 */
}
