/************************************************
* WKS Nano GD32板级支持包
* LED驱动程序
* 版本：V1.1
************************************************/

#ifndef _LED_H
#define _LED_H
#include "sys.h"

/* LED端口定义 */
#define LED1(x)   do{ x ? \
                      gpio_bit_write(GPIOD, GPIO_PIN_2, SET) : \
                      gpio_bit_write(GPIOD, GPIO_PIN_2, RESET); \
                  }while(0)

/* LED取反定义 */
#define LED1_TOGGLE()   do{ gpio_togglepin(GPIOD, GPIO_PIN_2); }while(0)        /* 反转LED1 */

void LED_Init(void);                                      //初始化LED
void gpio_togglepin(uint32_t gpio_periph, uint32_t pin);  //反转IO口状态
#endif
